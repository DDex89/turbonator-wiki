;mpver 2.00
;mpassmfile t-sbec_v3.asm
.org DataOrg
;mpinjsize 34.9
;mpbar 2.0

;mprevisionstart
; ***********************************************************************
; T-SBEC_22_MTX_A415_Daytona-VNT.tpl
; 2.2 VNT Cal Data (Daytona VNT)
;
; Revision History
;
; 04/13/10 - 1st release and test of VNT-based T-SBEC (re-written).
;
; 05/19/11 - Updated template to MP Tuner 2 format.
;
; 11/01/11 - Added PumpShot Subgroup
;          - Added calculated tables group
;
; ***********************************************************************
;mprevisionend

;mpgroupstart Boost_Control\VNT_Control\
;VNT Boost Control System - Select using the cal configuration opions.
;mpgroupend
;mpgroupstart Fuel_-_Adaptive_Memory_Timer\
;Fuel - Adaptive memory\Fuel - Adaptive Memory Timer\
;mpgroupend
;mpgroupstart Fuel_-_Individual_Cylinder_Trim\
;Fuel - Adaptive memory\Fuel - Individual Cylinder Trim\
;mpgroupend
;mpgroupstart Fuel_-_Modifiers\
;Fuel - Adaptive memory\Fuel - Modifiers\
;mpgroupend
;mpgroupstart Fuel_-_O2_Controller\
;Fuel - Adaptive memory\Fuel - O2 Controller\
;mpgroupend
;mpgroupstart Fuel_-_O2_Controller_Ramps\
;Fuel - Adaptive memory\Fuel - O2 Controller Ramps\
;mpgroupend
;mpgroupstart Fuel_-_Running\
;Fuel - Adaptive memory\Fuel - Running\
;mpgroupend
;mpgroupstart Fuel_-_Starting\
;Fuel - Adaptive memory\Fuel - Starting\
;mpgroupend
;mpgroupstart Fuel_-_Transient_Enrichment\
;Fuel - Adaptive memory\Fuel - Transient Enrichment\
;mpgroupend
;mpgroupstart Fuel_-_Transient_Enrichment\PumpShot_Calculation\
;Fuel - Adaptive memory\Fuel - Transient Enrichment\PumpShot Calculation\
;mpgroupend
;mpgroupstart Idle_-_AIS_Decel\
;Idle - AIS Control\Idle - AIS Decel\
;mpgroupend
;mpgroupstart Idle_-_Special_setup\
;Idle - AIS Control\Idle - Special setup\
;mpgroupend
;mpgroupstart Utility\On-Board_Diagnostics\Alternator_Diagnostics\
;Setup - Cal Configuration\Setup - Alternator Diagnostics\
;mpgroupend
;mpgroupstart Setup\DRB_Datalogging\
;Setup - Cal Configuration\Setup - DRB Datalogging\
;mpgroupend
;mpgroupstart Utility\On-Board_Diagnostics\O2_Sensor_Diagnostics\
;Setup - Cal Configuration\Setup - O2 Sensor Diagnostics\
;mpgroupend
;mpgroupstart Utility\On-Board_Diagnostics\
;Setup - Cal Configuration\Setup - On-Board Diagnostics\
;mpgroupend
;mpgroupstart Setup\Transfer_Functions\
;Setup - Cal Configuration\Setup - Transfer Functions\
;mpgroupend
;mpgroupstart Setup\
;Purge Control\Setup - Cal Configuration\
;mpgroupend
;mpgroupstart Setup_-_T-Stat_Diagnostics\
;Setup - Cal Configuration\Setup - T-Stat Diagnostics\
;mpgroupend
;mpgroupstart Spark_-_Anti-Lag_Retard\
;Spark - Adaptive Retard\Spark - Anti-Lag Retard\
;mpgroupend
;mpgroupstart Spark_-_Dwell_Control\
;Spark - Adaptive Retard\Spark - Dwell Control\
;mpgroupend
;mpgroupstart Spark_-_Knock_Retard\
;Spark - Adaptive Retard\Spark - Knock Retard\
;mpgroupend
;mpgroupstart Spark_-_Normal_Advance\
;Spark - Adaptive Retard\Spark - Normal Advance\
;mpgroupend
;mpgroupstart Spark_-_Scatter_Control\
;Spark - Adaptive Retard\Spark - Scatter Control\
;mpgroupend
;mpgroupstart Spark_-_Start_to_Run_Transfer\
;Spark - Adaptive Retard\Spark - Start to Run Transfer\
;mpgroupend
;mpgroupstart Turbonator_-_Shift_Light\
;Turbonator - CEL Knock Indicator\Turbonator - Shift Light\
;mpgroupend
;mpgroupstart Turbonator_-_Staging_Limiter\
;Turbonator - CEL Knock Indicator\Turbonator - Staging Limiter\
;mpgroupend
;mpgroupstart Turbonator_-_Voltage_Regulator\
;Turbonator - CEL Knock Indicator\Turbonator - Voltage Regulator\
;mpgroupend
;mpgroupstart Boost_Control\WG_Control\
;WG Control - select using the cal configuration options.
;mpgroupend
;mpgroupstart Boost_Control\Target_Lookup\
;Boost Target Lookup Tables
;mpgroupend
;mpgroupstart Boost_-_Target_Lookup\
;Boost Control
;mpgroupend
;mpgroupstart Utility\Baro_Read\
;AC Control\Baro Read\
;mpgroupend
;mpgroupstart Utility\Cruise_Control\
;Utility\Cruise Control\
;mpgroupend
;mpgroupstart Utility\EGR\
;Utility\EGR\
;mpgroupend
;mpgroupstart Utility\PTU_Control\
;Utility\PTU Control\
;mpgroupend
;mpgroupstart Utility\Purge_Control\
;Utility\Purge Control\
;mpgroupend
;mpgroupstart Utility\
;Utility\
;mpgroupend
;mpgroupstart Idle_-_AIS_Control\
;Idle\
;mpgroupend
;mpgroupstart Spark\Scatter_Control\
;Spark\Spark - Scatter Control\
;mpgroupend
;mpgroupstart Spark\Start_to_Run_Transfer\
;Spark\Spark - Start to Run Transfer\
;mpgroupend
;mpgroupstart Utility\On-Board_Diagnostics\T-Stat_Diagnostics\
;Setup\Setup - T-Stat Diagnostics\
;mpgroupend
;mpgroupstart Spark_-_Adaptive_Retard\
;Spark\
;mpgroupend
;mpgroupstart Spark\Anti-Lag_Retard\
;Spark\Spark - Anti-Lag Retard\
;mpgroupend
;mpgroupstart Spark\Dwell_Control\
;Spark\Spark - Dwell Control\
;mpgroupend
;mpgroupstart Spark\Knock_Retard\
;Spark\Spark - Knock Retard\
;mpgroupend
;mpgroupstart Spark\Normal_Advance\
;Spark\Spark - Normal Advance\
;mpgroupend
;mpgroupstart Fuel_-_Adaptive_memory\
;Fuel\
;mpgroupend
;mpgroupstart Fuel\O2_Feedback_Control\Adaptive_Memory_Timer\
;Fuel\Fuel - Adaptive Memory Timer\
;mpgroupend
;mpgroupstart Fuel\Individual_Cylinder_Trim\
;Fuel\Fuel - Individual Cylinder Trim\
;mpgroupend
;mpgroupstart Fuel\Modifiers\
;Fuel\Fuel - Modifiers\
;mpgroupend
;mpgroupstart Fuel\O2_Feedback_Control\O2_Controller\
;Fuel\Fuel - O2 Controller\
;mpgroupend
;mpgroupstart Fuel\O2_Feedback_Control\O2_Controller_Ramps\
;Fuel\Fuel - O2 Controller Ramps\
;mpgroupend
;mpgroupstart Fuel\Running\
;Fuel\Fuel - Running\
;mpgroupend
;mpgroupstart Fuel\Starting\
;Fuel\Fuel - Starting\
;mpgroupend
;mpgroupstart Fuel\Transient_Enrichment\
;Fuel\Fuel - Transient Enrichment\
;mpgroupend
;mpgroupstart Fuel\Transient_Enrichment\PumpShot_Calculation\
;Fuel\Fuel - Transient Enrichment\PumpShot Calculation\
;mpgroupend
;mpgroupstart Fuel\Transient_Enrichment\PumpShot_Calculation\MAP_PumpShot\
;Fuel\Fuel - Transient Enrichment\PumpShot Calculation\MAP PumpShot\
;mpgroupend
;mpgroupstart Fuel\Transient_Enrichment\PumpShot_Calculation\TPS_PumpShot\
;Fuel\Fuel - Transient Enrichment\PumpShot Calculation\TPS PumpShot\
;mpgroupend
;mpgroupstart Idle\AIS_Decel\
;Idle\Idle - AIS Decel\
;mpgroupend
;mpgroupstart Idle\Special_setup\
;Idle\Idle - Special setup\
;mpgroupend
;mpgroupstart Turbonator_-_CEL_Knock_Indicator\
;Turbonator\
;mpgroupend
;mpgroupstart Turbonator\Shift_Light\
;Turbonator\Turbonator - Shift Light\
;mpgroupend
;mpgroupstart Turbonator\Staging_Limiter\
;Turbonator\Turbonator - Staging Limiter\
;mpgroupend
;mpgroupstart Turbonator\Voltage_Regulator\
;Turbonator\Turbonator - Voltage Regulator\
;mpgroupend
;mpgroupstart Decel_Fuel_Shutoff\
;Fuel\Decel Fuel Shutoff\
;mpgroupend
;mpgroupstart Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_MAP_LO\
;Fuel\Transient Enrichment\Decel Lean-out\New 634618868995332187\Decreasing MAP L
;  O\
;mpgroupend
;mpgroupstart Boost\
;Boost Control\
;mpgroupend
;mpgroupstart Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_TPS_LO\
;Fuel\Transient Enrichment\Decel Lean-out\Decreasing TPS LO\
;mpgroupend


.msg "Assembling Data Structures..." ; these are just messages to display during assemble to let you know what's going on...


;mpfuelparms 6000,60,55,3.793,.740_Regular,2.2
;mpfuelnone1 14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7
;mpfuelnone2 14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7
;mpfuelpart1 14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7
;mpfuelpart2 14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7
;mpfuelfull1 14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7
;mpfuelfull2 14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7,14.7


	;.org	0x8000
ENDIT1_PNPrefix:
    ;mpgrp Setup\Cal_ID\
    ;mptbladdr 0x00F5
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname PNPrefix
    ;mptblcname ENDIT1
    ;mpxaxis X 0 255 scale
    ;mpyaxis Y 0 255 out
    ;mptbldesc Part_Number_prefix._The_1st_4_digits_of_the_Mopar_PN_for_this_ECU.
    .word 0x5276                     ;Point 1

	;.org	0x8002
ENDITM_ECUID:
    ;mpgrp Setup\Cal_ID\
    ;mptbladdr 0x0102
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname ECU_ID
    ;mptblcname ENDITM
    ;mpxaxis X 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc ECU_ID._This_portion_of_the_PN_is_used_by_scan_tools_to_automatically_ID_the_ECU._This_number_is_different_for_every_computer/cal._The_1st_digit_is_possibly_a_revision_code_of_some_type._Or,_it_may_have_no_meaning_at_all.
    .word 0xA415                     ;Point 1

	;.org	0x8004
HunstvilleTesterCodeBits:
    ;mpgrp Setup\Cal_ID\
    ;mptbladdr 0x010F
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname Huntsville_Code
    ;mptblcname HUNTSV
    ;mpxaxis X 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Special_code_for_factory_testing.
    .word 0xC9E5                     ;Point 1

	;.org	0x8006
MDLCDE_ModelTypeCode:
    ;mpgrp Setup\Cal_ID\
    ;mptbladdr 0x011C
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname ModelTypeCode
    ;mptblcname MDLCDE
    ;mpxaxis X 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc The_1st_2_digits_are_the_model_year,_2nd_2_digits_are_the_engine_and_trans_type.
    .word 0x4040                     ;Point 1
    ;mp******************************
    ;mpmodelyr 99 1989
    ;mpmodelyr 00 1990
    ;mpmodelyr 01 1991
    ;mpmodelyr 02 1992
    ;mpmodelyr 03 1993
    ;mpmodelyr 11 1991_MP
    ;mpmodelyr 50 1990_Shadow
    ;mpmodelyr 40 1989_Daytona_VNT
    ;mpmodelyr 79 1989_3.0_Van
    ;mpmodelyr 70 1990_3.0_Van
    ;mpmodelyr 21 1991_3.0_Van
    ;mpengtran 10 2.2_TIV
    ;mpengtran 40 2.2_VNT_Manual
    ;mpengtran 01 2.5_T1
    ;mpengtran 11 2.5_Turbo
    ;mpengtran 21 2.5_T1_Van_Auto
    ;mpengtran 41 2.5_T1/T3_Manual
    ;mpengtran 12 3.0_MFI
    ;mpengtran 22 3.0_Auto
    ;mpengtran 13 3.3_MFI
    ;mpengtran 14 3.9_Truck
    ;mpengtran 15 5.2/5.9_TBI_VIN_Y
    ;mpengtran 16 5.2/5.9_TBI_VIN_X
    ;mpengtran 51 3.0_Van_A604
    ;mp******************************

; $8006 controls the year.
; 99=1989
; 00=1990
; 01=1991
; 02=1992
; 03=1993

; 11=1991 MP
; 50=1990 (Shadow)
; 40=1989 (Daytona VNT)
; 79=1989 (on 3.0 Minivan)
; 70=1990 (on 3.0 Minivan)
; 21=1991 (on 3.0 Minivan)


; $8007 controls engine type.
; 10=2.2 turbo IV
; 40=2.2 VNT Manual

; 01=2.5 T1
; 11=2.5 turbo
; 21=2.5 T1 (Minivan) Auto Trans
; 41=2.5 T1 Manual Trans

; 41=2.2 T3 Manual Trans (Also?)

; 12=3.0 MFI
; 22=3.0 Auto

; 13=3.3 MFI 
; 14=3.9 truck
; 15=5.2/5.9 TBI VIN Y
; 16=5.2/5.9 TBI VIN X

; 51=? 3.0 Minivan A604?

	;.org	0x8008
SpecialBytes:
    ;mpgrp Setup\Cal_ID\
    ;mptbladdr 0x0167
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname Setup_bytes
    ;mptblcname SETUP
    ;mpxaxis X 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Desc
    .word 0x55AA                     ;Point 1

	;.org	0x800a
SpecialBytes2:
    ;mpgrp Setup\Cal_ID\
    ;mptbladdr 0x0174
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname Setup_bytes_2
    ;mptblcname SETUP2
    ;mpxaxis X 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Desc
    .word 0x0012                     ;Point 1

	;.org	0x800c
CONFIG_ConfigurationFlags:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x0181
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname ConfigurationFlags
    ;mptblcname CONFIG
    ;mpxaxis IN 0 255 X
    ;mpyaxis OUT 0 255 Y
    ;mptbldesc These_are_the_factory_configuration_options.
    ;mpchoices VNT_BoostCtrl  TransFuelTPS  VNTOB_Fuel_Shut  O2_SensorWhat  Cold_Start_Enrich  Auto_Trans_Bit  EGR_Installed  A/C_Installed
    .byte 0x8F                       ;Point 1

    cfg_AC	                = $%10000000	; A/C Installed
    cfg_EGR		        = $%01000000	; EGR installed
    cfg_ATX		        = $%00100000	; Auto trans (if set)
    cfg_CSEnrich		= $%00010000	;
    cfg_O2		        = $%00001000	;
    cfg_VNTOBFuelShut		= $%00000100	; Use fuel shut with VNT OB control
    cfg_UseTPSTransFuelEarly	= $%00000010	;
    cfg_VNT		        = $%00000001	; Use VNT Boost Control

OPTN1_CalCustomOptionConfigFlags1:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x0197
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname CalCustomOptionConfigFlags1
    ;mptblcname OPTN1
    ;mpxaxis IN 0 255 X
    ;mpyaxis OUT 0 255 Y
    ;mptbldesc These_are_options_available_to_enable_in_this_custom_codebase.
    ;mpchoices Switchable_boost_enable  Boost_switch_polarity  Staging_limiter_Enable  Staging_Limiter_sw_polarity  FlashCE_On_Knock_Enable  Hi-Speed_Logger_Enable  Anti-Lag_Enable  Shift_Light_Enable
    .byte 0x00                       ;Point 1
    opt_ShiftLight		 = $%10000000	 ; Shift light enabled
    opt_AntiLag			 = $%01000000	 ; Use the Anti-Lag retard routine
    opt_HiSpdLog         	 = $%00100000	 ; Use the hi-speed logger interrupt routine
    opt_FlashCE 		 = $%00010000	 ; Flash the CE light when knock is indicated
    opt_StagePol         	 = $%00001000	 ; Staging Limiter switch polarity
    opt_StageLim		 = $%00000100	 ; Staging limiter (2-step) enable
    opt_SwBstPol		 = $%00000010	 ; Switchable boost switch polarity
    opt_SwBoost 		 = $%00000001	 ; Switchable boost enable

OPTN2_CalCustomOptionConfigFlags2:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x01AC
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname CalCustomOptionConfigFlags2
    ;mptblcname OPTN2
    ;mpxaxis IN 0 255 X
    ;mpyaxis OUT 0 255 Y
    ;mptbldesc These_are_options_available_to_enable_in_this_custom_codebase.
    ;mpchoices Spark-based_Rev_Limiter(Not_Working)  Fuel-based_Rev_Limiter  Suppress_EMR  Not_Used  Not_Used  Not_Used  Not_Used  Charge_Temp_Sens
    .byte 0x82                       ;Point 1
    opt_CTS  		         = $%10000000	 ; Charge Temp Sens
    opt_Bit6			 = $%01000000	 ;
    opt_Bit5         	         = $%00100000	 ;
    opt_Bit4 		         = $%00010000	 ;
    opt_Bit3         	         = $%00001000	 ;
    opt_SupressEMR		 = $%00000100	 ; Suppress the EMR (Emiss Maint Reminder) Code
    opt_FuelRevLim		 = $%00000010	 ; Use the fuel-based rev limiter
    opt_SprkRevLim 		 = $%00000001	 ; Use the spark-based rev limiter

	;.org	0x800e
CCDCFG_CCDConfigConstant:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x01C2
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname CCDConfigConstant
    ;mptblcname CCDCFG
    ;mpxaxis X 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc CCD_Bus_configuration_constant._Not_sure_of_usage.
    ;mpchoices Bit7  Bit6  Bit5  Bit4  Bit3  Bit2  Bit1  Bit0
    .byte 0xA1                       ;Point 1

	;.org	0x800f
CCDCF2_CCDConfigConstant2:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x01D0
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname CCDConfigConstant2
    ;mptblcname CCDCF2
    ;mpxaxis X 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc CCD_Bus_configuration_constant._Not_sure_of_usage.
    ;mpchoices Bit7  Bit6  Bit5  Bit4  Bit3  Bit2  Bit1  Bit0
    .byte 0x00                       ;Point 1

	;.org	0x8010
CLDMAP_AdvanceFromMAPCold:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x01DE
    ;mptbltype 2
    ;mpsubtype 1
    ;mptbllname AdvanceFromMAPCold
    ;mptblcname CLDMAP
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Spark_Advance -64 64 Degrees
    ;mptbldesc Curve_for_Spark_Advance_from_MAP_when_Engine_Temp_is_below_TMPSWP
    ;mpmapaxis x
    .byte 0x04                       ;Number of points in table
    .byte 0x55, 0x00, 0x00, 0x00     ;Point 1
    .byte 0x77, 0x00, 0x00, 0x00     ;Point 2
    .byte 0x99, 0x00, 0xFF, 0xCE     ;Point 3
    .byte 0xFF, 0xEC                 ;Point 4

	;.org	0x8023
CLDLMT_LimitForColdMapAtClosedThrottle:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x01F0
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LimitForColdMapAtClosedThrottle
    ;mptblcname CLDLMT
    ;mpxaxis X 0 255 in
    ;mpyaxis Y -200 260 out
    ;mptbldesc Coldest_input_allowed_for_Cold_MAP
    .byte 0x14                       ;Point 1

	;.org	0x8024
HOTMAP_AdvanceFromMAPWarmPart:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x01FD
    ;mptbltype 2
    ;mpsubtype 1
    ;mptbllname AdvanceFromMAPWarmPart
    ;mptblcname HOTMAP
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Spark_Advance -64 64 Degrees
    ;mptbldesc Curve_for_Spark_Advance_from_MAP_when_Engine_Temp_is_above_TMPSWP_and_not_at_Full_Throttle
    ;mpmapaxis x
    .byte 0x06                       ;Number of points in table
    .byte 0x44, 0x18, 0xFF, 0x1C     ;Point 1
    .byte 0x4D, 0x10, 0x00, 0x00     ;Point 2
    .byte 0x54, 0x10, 0xFF, 0xC9     ;Point 3
    .byte 0x70, 0x0A, 0xFF, 0x80     ;Point 4
    .byte 0x9C, 0xF4, 0xFF, 0xC2     ;Point 5
    .byte 0xFF, 0xDC                 ;Point 6

	;.org	0x8043
TMPSWP_EngTempSwitchPointForSparkAdvance:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x0211
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EngTempSwitchPointForSparkAdvance
    ;mptblcname TMPSWP
    ;mpxaxis IN 0 255 X
    ;mpyaxis Coolant_Temperature -200 260 F
    ;mptbldesc Engine_temperature_switch_point_for_hot_and_cold_map_spark
    .byte 0xB1                       ;Point 1

	;.org	0x8044
ADVCLS_AdvanceAddedForClosedLoopFromTimer:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x021E
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname AdvanceAddedForClosedLoopFromTimer
    ;mptblcname ADVCLS
    ;mpxaxis Timer 0 255 F
    ;mpyaxis Spark_Advance -64 64 Degrees
    ;mptbldesc Advance_from_coolant_temp_when_throttle_is_closed
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x00                 ;Point 1

PartThrottleTiming:
    ;mpgrp Calculated_Tables\
    ;mptbladdr 0x022B
    ;mptbltype 16
    ;mpsubtype n
    ;mptbllname PartThrottleTotalTiming
    ;mptblcname PTTIME
    ;mpxaxis GOVNER 0 8192 rpm
    ;mpyaxis HOTMAP -15 15 Degrees
    ;mptbldesc Part_throttle_total_timing.
    ;mp3dxtable GOVNER 
    ;mpxintv 500
    ;mp3dytable HOTMAP 
    ;mpyintv 1
    ;mp3dmaxtable SPKLMT
    ;mp3dmapmul MAPMUL
    .byte 0x1F                       ;Number of rows in table
    .byte 0x11                       ;Number of cols in table
    .byte 0x00                       ;00 = unsigned, FF = signed
	
FullThrottleTiming:
    ;mpgrp Calculated_Tables\
    ;mptbladdr 0x023F
    ;mptbltype 16
    ;mpsubtype n
    ;mptbllname FullThrottleTotalTiming
    ;mptblcname FTTIME
    ;mpxaxis GOVNER 0 8192 rpm
    ;mpyaxis WOTMAP -15 15 Degrees
    ;mptbldesc Full_throttle_total_timing.
    ;mp3dxtable GOVNER 
    ;mpxintv 500
    ;mp3dytable WOTMAP 
    ;mpyintv 1
    ;mp3dmaxtable SPKLMT
    ;mp3dmapmul MAPMUL
    .byte 0x1F                       ;Number of rows in table
    .byte 0x11                       ;Number of cols in table
    .byte 0x00                       ;00 = unsigned, FF = signed

	;.org	0x805b
WOTMAP_AdvanceFromMAPWarmFull:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x0254
    ;mptbltype 2
    ;mpsubtype 1
    ;mptbllname AdvanceFromMAPWarmFull
    ;mptblcname WOTMAP
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Spark_Advance -64 64 Degrees
    ;mptbldesc Curve_for_Spark_Advance_from_MAP_when_Engine_Temp_is_above_TMPSWP_and_at_Full_Throttle
    ;mpmapaxis x
    .byte 0x05                       ;Number of points in table
    .byte 0x66, 0x0A, 0xFF, 0x00     ;Point 1
    .byte 0x70, 0x00, 0xFF, 0x88     ;Point 2
    .byte 0x81, 0xF8, 0xFF, 0xDA     ;Point 3
    .byte 0x9C, 0xF4, 0xFF, 0xBD     ;Point 4
    .byte 0xFF, 0xDA                 ;Point 5

	;.org	0x806e
MAPMUL_MultiplierOnMapAdvanceWhenRetarding_FromRpm:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x0267
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname MultiplierOnMapAdvanceWhenRetarding_FromRpm
    ;mptblcname MAPMUL
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis Spark_Advance_Scale 0 4 out
    ;mptbldesc Multiplier_on_Map_based_spark_advance_-_used_when_spark_advance_is_below_zero._Output_is_a_multiplier.
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x40                 ;Point 1

	;.org	0x8085
RPMLMT_LimitForHotMAPAdvance:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x0275
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname LimitForHotMAPAdvance
    ;mptblcname RPMLMT
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis Spark_Advance -64 64 Degrees
    ;mptbldesc RPM_vs_Advance_when_engine_above_161F_and_throttle_(used_to_limit_max_MAP_advance_from_above_when_there_is_some_to_full_throttle)
    .byte 0x03                       ;Number of points in table
    .byte 0x20, 0x08, 0x00, 0x8E     ;Point 1
    .byte 0x32, 0x12, 0x00, 0x8F     ;Point 2
    .byte 0x4B, 0x20                 ;Point 3

	;.org	0x8090
PNIDLE_AdvanceRemovedIdleParkNeutral:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x0285
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname AdvanceRemovedIdleParkNeutral
    ;mptblcname PNIDLE
    ;mpxaxis Coolant_Temperature -200 260 F
    ;mpyaxis Spark_Advance -64 64 Degrees
    ;mptbldesc Not_used
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x00                 ;Point 1

	;.org	0x8097
PNRPM_EngineSpeedBelowWhich_PNIDLE_Enabled:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x0293
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EngineSpeedBelowWhich_PNIDLE_Enabled
    ;mptblcname PNRPM
    ;mpxaxis X 0 255 in
    ;mpyaxis RPM 0 8192 RPM
    ;mptbldesc Engine_speed_below_which_PNIDLE_is_Enabled_-_for_Automatics
    .byte 0x01                       ;Point 1

	;.org	0x8098
GOVNER_AdvanceFromRPM:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x02A0
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AdvanceFromRPM2
    ;mptblcname GOVNER
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis Spark_Advance 0 128 Degrees
    ;mptbldesc Simulates_the_mechanical_advance_function._Spark_Advance_is_added_from_this_table_from_RPMs_at_all_engine_temperatures._Added_to_MAP_based_advance
    .byte 0x05                       ;Number of points in table
    .byte 0x20, 0x14, 0x01, 0x55     ;Point 1
    .byte 0x32, 0x2C, 0x00, 0x00     ;Point 2
    .byte 0x8B, 0x2C, 0x00, 0x95     ;Point 3
    .byte 0xA3, 0x3A, 0x00, 0x72     ;Point 4
    .byte 0xC7, 0x4A                 ;Point 5

	;.org	0x80b3
SPKLMT_TotalAdvanceAllowed:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x02B2
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname AdvanceFromRpmMAX
    ;mptblcname SPKLMT
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis Spark_Advance -64 64 Degrees
    ;mptbldesc Description
    .byte 0x03                       ;Number of points in table
    .byte 0x64, 0x64, 0xFE, 0x76     ;Point 1
    .byte 0x71, 0x50, 0xFF, 0xE8     ;Point 2
    .byte 0xDB, 0x46                 ;Point 3

	;.org	0x80be
ADVDFT_DefaultSparkAdvance1:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x02C2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DefaultSparkAdvance1
    ;mptblcname ADVDFT
    ;mpxaxis X 0 255 in
    ;mpyaxis Spark_Advance 0 128 Degrees
    ;mptbldesc Description
    .byte 0x14                       ;Point 1

	;.org	0x80bf
ADO2CL_AdvanceAddedFromO2FeedbackCounterLimitLow:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x02CF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdvanceAddedFromO2FeedbackCounterLimitLow
    ;mptblcname ADO2CL
    ;mpxaxis X 0 255 in
    ;mpyaxis Counter 0 255 Cnt
    ;mptbldesc Description
    .byte 0x1A                       ;Point 1

	;.org	0x80c0
ADO2CH_AdvanceAddedFromO2FeedbackCounterLimitHi:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x02DC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdvanceAddedFromO2FeedbackCounterLimitHi
    ;mptblcname ADO2CH
    ;mpxaxis X 0 255 in
    ;mpyaxis Counter 0 255 Cnt
    ;mptbldesc Description
    .byte 0xE6                       ;Point 1

	;.org	0x80c1
ADO2C1_AdvanceAddedFromO2FeedbackCounter1:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x02E9
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname AdvanceAddedFromO2FeedbackCounter1
    ;mptblcname ADO2C1
    ;mpxaxis Counter 0 255 Cnt
    ;mpyaxis Spark_Advance 0 128 Degrees
    ;mptbldesc Description
    .byte 0x03                       ;Number of points in table
    .byte 0x70, 0x04, 0xFF, 0xC0     ;Point 1
    .byte 0x80, 0x00, 0xFF, 0xC0     ;Point 2
    .byte 0x90, 0xFC                 ;Point 3

	;.org	0x80d8
ADO2C2_AdvanceAddedFromO2FeedbackCounter2:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x02F9
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname AdvanceAddedFromO2FeedbackCounter2
    ;mptblcname ADO2C2
    ;mpxaxis Counter 0 255 Cnt
    ;mpyaxis Spark_Advance 0 128 Degrees
    ;mptbldesc Description
    .byte 0x03                       ;Number of points in table
    .byte 0x70, 0x06, 0xFF, 0xA0     ;Point 1
    .byte 0x80, 0x00, 0xFF, 0xA0     ;Point 2
    .byte 0x90, 0xFA                 ;Point 3

	;.org	0x80ef
KNKRPM_MinRpmforKnockRetard:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x0309
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinRpmforKnockRetard
    ;mptblcname KNKRPM
    ;mpxaxis X 0 255 in
    ;mpyaxis RPM 0 8192 RPM
    ;mptbldesc Minimum_RPM_for_Knock_Retard
    .byte 0x20                       ;Point 1

	;.org	0x80f0
KNKOFS_DeltaAboveBaroFor_RTRDRT_and_KNKCNT_and_KNKCOR_incremented:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x0316
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DeltaAboveBaroFor_RTRDRT_and_KNKCNT_and_KNKCOR_incremented
    ;mptblcname KNKOFS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP 0 29.4 psi
    ;mptbldesc Delta_above_Baro_up_to_which_RTRDRT_(Retard_Rate)_is_used_and_KNKCNT_and_KNKCOR_are_incremented._Stock_is_5.4_psi.
    ;mpmapaxis y
    .byte 0x2F                       ;Point 1

	;.org	0x80f1
RTRDRT_KnockRetardRateNoBoost:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x0324
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname KnockRetardRateNoBoost
    ;mptblcname RTRDRT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Deg 0 128 Degrees
    ;mptbldesc Retard_rate_from_Knock,_no_boost._In_half_degreesn
    .byte 0x06                       ;Point 1

	;.org	0x80f2
RTRDRT2_KnockRetardRateInBoost:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x0331
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname KnockRetardRateInBoost
    ;mptblcname RTRDRT2
    ;mpxaxis IN 0 255 X
    ;mpyaxis Retard 0 128 deg
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

	;.org	0x80f3
INCSRT_KnockRetardIncreaseRate:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x033E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname KnockRetardIncreaseRate
    ;mptblcname INCSRT
    ;mpxaxis in_desc 0 255 retard
    ;mpyaxis Y 0 128 deg
    ;mptbldesc Increase_Rate._Recovery_from_Knock_Retard._Rate_is_1/2_engine_degree_every_INCSRT+1_*_11ms._Use_ONLY_0,1,3,7,f,1f,3f,7f_or_ff
    .byte 0x1F                       ;Point 1

	;.org	0x80f4
RETMAX_MaxKnockRetardFromMap:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x034B
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname MaxKnockRetardFromMap
    ;mptblcname RETMAX
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Max_Retard 0 128 degrees
    ;mptbldesc Maximum_Knock_Retard_from_Map
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x56, 0x06, 0x00, 0xE2     ;Point 1
    .byte 0x70, 0x1D                 ;Point 2

	;.org	0x80ff
KNKLIM_MaxKnockRetard:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x035B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MaxKnockRetard
    ;mptblcname KNKLIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Retard 0 128 Degrees
    ;mptbldesc Knock_Limit_in_1/2_degrees._MaxRetard_=_KNKLIM_if_throttle_is_above_THRKNK_and_RPM_is_below_KLMRPM
    .byte 0x06                       ;Point 1

	;.org	0x8100
THRKNK_DeltaAbove_MINTHR:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x0368
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaAbove_MINTHR
    ;mptblcname THRKNK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis TPS 0 5 Volts
    ;mptbldesc Delta_above_MINTHR_for_knock_detect
    .byte 0x53                       ;Point 1

	;.org	0x8101
KLMRPM_MinKnockDetectRpm:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x0375
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinKnockDetectRpm
    ;mptblcname KLMRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 RPM
    ;mptbldesc RPMS_for_Knock
    .byte 0x20                       ;Point 1

	;.org	0x8102
DLTKNK_KnockFromRpms:
    ;mpgrp Spark\Knock_Retard\
    ;mptbladdr 0x0382
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname KnockSensorVoltageForKnock_FromRpm
    ;mptblcname DLTKNK
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis A2D 0 5 volts
    ;mptbldesc Input_from_the_knock_sensor_that_is_above_this_voltage_is_considered_Knock.
    .byte 0x05                       ;Number of points in table
    .byte 0x3F, 0x20, 0x00, 0x42     ;Point 1
    .byte 0x5E, 0x28, 0x01, 0x4A     ;Point 2
    .byte 0x9C, 0x78, 0x01, 0xD1     ;Point 3
    .byte 0xB2, 0xA0, 0x05, 0xF0     ;Point 4
    .byte 0xC2, 0xFF                 ;Point 5

	;.org	0x8119
ARRPM_AdaptiveRetardFromRPM:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x0394
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AdaptiveRetardFromRPM
    ;mptblcname ARRPM
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis Spark_Retard 0 128 Degrees
    ;mptbldesc The_result_of_this_table_is_multiplied_by_#002b_(0,_1/4,_1/2,_3/4,_or_1)_and_subtracted_from_the_table_at_#8098
    .byte 0x05                       ;Number of points in table
    .byte 0x3F, 0x00, 0x00, 0x42     ;Point 1
    .byte 0x5E, 0x08, 0x00, 0x00     ;Point 2
    .byte 0x71, 0x08, 0xFF, 0xC3     ;Point 3
    .byte 0x8A, 0x02, 0xFF, 0xEC     ;Point 4
    .byte 0xA3, 0x00                 ;Point 5

	;.org	0x8134
ARMAP_AdaptiveRetardFromMAP:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x03A6
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AdaptiveRetardFromMAP
    ;mptblcname ARMAP
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Spark_Retard 0 128 Degrees
    ;mptbldesc This_table_is_reduced_by_the_value_in_#002b_(0,_1/4,_1/2,_3/4,_or_1)_depending_on_the_boost_control_routine._And_the_result_is_subtracted_from_the_advance_calculated_by_8010_or_805b
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x85, 0x00, 0x00, 0x55     ;Point 1
    .byte 0x91, 0x04                 ;Point 2

	;.org	0x814f
ARMPIC_AdaptiveRetard_MinMAPForAdjustment:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x03B6
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AdaptiveRetard_MinMAPForAdjustment
    ;mptblcname ARMPIC
    ;mpxaxis IN 0 255 X
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc ff_disables_the_Adaptive_Knock_Retard
    ;mpmapaxis y
    .byte 0x79                       ;Point 1

	;.org	0x8150
ARINDX_AdaptiveRetardIndexBase_80:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x03C4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveRetardIndexBase_80
    ;mptblcname ARINDX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x80                       ;Point 1

	;.org	0x8151
ARSUBC_AdaptiveRetardFactorSubtract:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x03D1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveRetardFactorSubtract
    ;mptblcname ARSUBC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x40                       ;Point 1

	;.org	0x8152
ARCMSK_AdaptiveRetardCounterMask:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x03DE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveRetardCounterMask
    ;mptblcname ARCMSK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x3F                       ;Point 1

	;.org	0x8153
ARTM5P_AdaptiveRetardTimeOver5psiBoost:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x03EB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveRetardTimeOver5psiBoost
    ;mptblcname ARTM5P
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0C                       ;Point 1

	;.org	0x8154
ARMINT_AdaptiveRetardMinimumTemp:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x03F8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveRetardMinimumTemp
    ;mptblcname ARMINT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 degrees
    ;mptbldesc Detailed_Description
    .byte 0xB1                       ;Point 1

	;.org	0x8155
ARCMS2_AdaptiveRetardCounterMask2_00:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x0405
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveRetardCounterMask2_00
    ;mptblcname ARCMS2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x8156
ARCMS3_AdaptiveRetardCounterMask3_FF:
    ;mpgrp Spark\Adaptive_Retard\
    ;mptbladdr 0x0412
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveRetardCounterMask3_FF
    ;mptblcname ARCMS3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

DWELL_DwellTimeFromBatteryVoltsComp:
    ;mpgrp Spark\Dwell_Control\
    ;mptbladdr 0x041E
    ;mptbltype 10
    ;mpsubtype n
    ;mptbllname DwellTimeFromBatteryVolts
    ;mptblcname DWELL
    ;mpxaxis BatV 0 16.2 V
    ;mpyaxis DwellTime 0 65535 uSec
    ;mptbldesc Complement_of_dwell_time_from_battery_volts.
    .byte 0x82                   ;Point 1
    .word 0xE609, 0x4059
    .byte 0xAA                   ;Point 2
    .word 0xF017, 0x2908
    .byte 0xC8                   ;Point 3
    .word 0xF4E6, 0x138C
    .byte 0xDC                   ;Point 4
    .word 0xF66D, 0x1100
    .byte 0xF0                   ;Point 5
    .word 0xF7C1, 0x0C55
    .byte 0xFF

MINADW_MinAntiDwellPeriod:
    ;mpgrp Spark\Dwell_Control\
    ;mptbladdr 0x0434
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname MinAntiDwellPeriod
    ;mptblcname MINADW
    ;mpxaxis in 0 255 out
    ;mpyaxis AntiDwellTime 0 65535 uSec
    ;mptbldesc Minimum_anti-dwell_period._Use_caution_adjusting_this_constant_as_it_is_hardware_dependant.
    .word 0x0190                     ;Point 1

	;.org	0x8157
SSTEMP_TempAboveWhichSparkScatterIsActive:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x0441
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TempAboveWhichSparkScatterIsActive
    ;mptblcname SSTEMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 Degrees
    ;mptbldesc Temperature_above_which_spark_scatter_is_active._For_road_racing,_the_MP_cal_has_this_set_to_0xfe._This_keeps_the_revs_higher_during_shifts.
    .byte 0x58                       ;Point 1

	;.org	0x8158
FTUNPW_FineTuneStepForAis:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x044E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FineTuneStepForAis
    ;mptblcname FTUNPW
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Fine_Tune_Step_for_AIS_for_spark_scatter
    .byte 0x01                       ;Point 1

	;.org	0x8159
SSITIM_ScatterInhibitTime:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x045B
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname ScatterInhibitTime
    ;mptblcname SSITIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Spark_Scatter_Inhibit_Time_in_11ms_per_bit
    .word 0x0088                     ;Point 1

	;.org	0x815b
SSIPRD_ScatterInhibitBelowThisSpeed:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x0468
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname ScatterInhibitBelowThisSpeed
    ;mptblcname SSIPRD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Spark_Scatter_inhibited_below_this_speed._The_MP_MTX_cal_has_this_value_set_to_0xfe33_to_keep_the_revs_high_during_shifts.
    .word 0x0066                     ;Point 1

	;.org	0x815d
RPMFRT_SparkAdvanceRPMFilterRatio:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x0475
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SparkAdvanceRPMFilterRatio
    ;mptblcname RPMFRT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Factor 0 1 factor
    ;mptbldesc Detailed_Description
    .byte 0x7F                       ;Point 1

	;.org	0x815e
RPMFPS_SparkAdvanceRPMFilterLimitPos:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x0482
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname SparkAdvanceRPMFilterLimitPos
    ;mptblcname RPMFPS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Description
    .word 0x0190                     ;Point 1

	;.org	0x8160
RPMFNG_SparkAdvanceRPMFilterLimitNeg:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x048F
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname SparkAdvanceRPMFilterLimitNeg
    ;mptblcname RPMFNG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Description
    .word 0x0190                     ;Point 1

	;.org	0x8162
SPKADD_SparkAdvanceAddedWhenRpmBelowControl_FromDeltaRpm:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x049C
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname SparkAdvanceAddedWhenRpmBelowControl_FromDeltaRpm
    ;mptblcname SPKADD
    ;mpxaxis DeltaRPM 0 512 RPM
    ;mpyaxis Advance 0 128 degrees
    ;mptbldesc This_is_how_much_advance_is_added_to_increase_engine_speed.
    .byte 0x02                       ;Number of points in table
    .byte 0x00, 0x00, 0x00, 0xCD     ;Point 1
    .byte 0x14, 0x10                 ;Point 2

	;.org	0x816d
SPKAD2_SparkAdvanceAddedWhenRpmBelowControl2_FromDeltaRpm:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x04AB
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname SparkAdvanceAddedWhenRpmBelowControl2_FromDeltaRpm
    ;mptblcname SPKAD2
    ;mpxaxis DeltaRPM 0 512 RPM
    ;mpyaxis Advance 0 128 degrees
    ;mptbldesc This_is_how_much_advance_is_added_to_increase_engine_speed.
    .byte 0x02                       ;Number of points in table
    .byte 0x00, 0x00, 0x00, 0xCD     ;Point 1
    .byte 0x14, 0x10                 ;Point 2

	;.org	0x8178
SPKRET_SparkAdvanceRetardedWhenRpmAboveControl_FromDeltaRpm:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x04BA
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname SparkAdvanceRetardedWhenRpmAboveControl_FromDeltaRpm
    ;mptblcname SPKRET
    ;mpxaxis DeltaRPM 0 512 rpm
    ;mpyaxis Advance 0 128 degrees
    ;mptbldesc This_is_how_much_advance_is_removed_to_decrease_engine_speed
    .byte 0x03                       ;Number of points in table
    .byte 0x0A, 0x00, 0xFF, 0x9A     ;Point 1
    .byte 0x1E, 0xF8, 0xFF, 0xD0     ;Point 2
    .byte 0x64, 0xEB                 ;Point 3

	;.org	0x8183
SPKRT2_SparkAdvanceRetardedWhenRpmAboveControl2_FromDeltaRpm:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x04CA
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname SparkAdvanceRetardedWhenRpmAboveControl2_FromDeltaRpm
    ;mptblcname SPKRT2
    ;mpxaxis DeltaRPM 0 512 rpm
    ;mpyaxis Advance 0 128 degrees
    ;mptbldesc This_is_how_much_advance_is_removed_to_decrease_engine_speed
    .byte 0x03                       ;Number of points in table
    .byte 0x0A, 0x00, 0xFF, 0x9A     ;Point 1
    .byte 0x1E, 0xF8, 0xFF, 0xD0     ;Point 2
    .byte 0x64, 0xEB                 ;Point 3

	;.org	0x818e
IDLADD_FuelStabilization_FromDeltaRPM:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x04DA
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelStabilization_FromDeltaRPM
    ;mptblcname IDLADD
    ;mpxaxis DeltaRPM 0 512 rpm
    ;mpyaxis Pulsewidth 0 1024 uSec
    ;mptbldesc This_is_how_much_fuel_is_added_or_subtracted_to_increase_or_decrease_speed
    ;mpinjscale scale
    .byte 0x03                       ;Number of points in table
    .byte 0x03, 0x00, 0x03, 0x79     ;Point 1
    .byte 0x16, 0x42, 0x01, 0x00     ;Point 2
    .byte 0x4B, 0x77                 ;Point 3

	;.org	0x8199
IDLTMP_Use_IDLADD_AboveThisTemp:
    ;mpgrp Spark\Scatter_Control\
    ;mptbladdr 0x04EB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Use_IDLADD_AboveThisTemp
    ;mptblcname IDLTMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 degF
    ;mptbldesc IDLADD_enabled_when_engine_temp_is_above_IDLTMP
    .byte 0x6E                       ;Point 1

	;.org	0x819a
STRNTR_SparkStartRunTransferPointRpm:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x04F8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SparkStartRunTransferPointRpm
    ;mptblcname STRNTR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DistPW 0 2.55 mSec
    ;mptbldesc Start_to_Run_transfer_point
    .byte 0x62                       ;Point 1

	;.org	0x819b
RNSTTR_SparkRunStartTransferPointRpm:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x0505
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SparkRunStartTransferPointRpm
    ;mptblcname RNSTTR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DistPW 0 2.55 mSec
    ;mptbldesc Run_to_Start_transfer_point
    .byte 0x8E                       ;Point 1

	;.org	0x819c
SKAPRD_SparkImmediateSwitchToRunAboveThisRpm:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x0512
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SparkImmediateSwitchToRunAboveThisRpm
    ;mptblcname SKAPRD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Immediate_switch_to_Spark_RUN_mode_when_above_this_RPM
    .byte 0x48                       ;Point 1

	;.org	0x819d
SRTIME_SparkEPPsNeededToBeAboveSR_Hot:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x051F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SparkEPPsNeededToBeAboveSR_Hot
    ;mptblcname SRTIME
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Number_of_consecutive_EPPs_needed_to_be_above_Start_Run_when_hot
    .byte 0x04                       ;Point 1

	;.org	0x819e
SRTIME2_SparkEPPsNeededToBeAboveSR_Cold:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x052C
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SparkEPPsNeededToBeAboveSR_Cold
    ;mptblcname SRTIME2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Number_of_consecutive_EPPs_needed_to_be_above_Start_Run_when_cold
    .byte 0x04                       ;Point 1

	;.org	0x819f
SRTMTP_SparkTempSwitchPointFor_SRTIME:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x0539
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SparkTempSwitchPointFor_SRTIME
    ;mptblcname SRTMTP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 Degrees
    ;mptbldesc Engine_Temperature_switch_point_for_SRTIME
    .byte 0xB0                       ;Point 1

	;.org	0x81a0
CSFERT_MinTempForColdStartFuelEnrichment:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x0546
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinTempForColdStartFuelEnrichment
    ;mptblcname CSFERT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis CoolantTemp -200 260 DegF
    ;mptbldesc Min_Engine_Temperature_for_cold_start_enrichment
    .byte 0x58                       ;Point 1

	;.org	0x81a1
RNFPRD_FuelStartRunTransferPointRpm:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x0553
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FuelStartRunTransferPointRpm
    ;mptblcname RNFPRD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Start_to_Run_transfer_point_for_fuel
    .byte 0x60                       ;Point 1

	;.org	0x81a2
STFPRD_FuelRunStartTransferPointRpm:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x0560
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FuelRunStartTransferPointRpm
    ;mptblcname STFPRD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Run_to_Start_transfer_point_for_spark
    .byte 0x82                       ;Point 1

	;.org	0x81a3
CSFERX_NumLoopsForColdStartFuelEnrich:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x056D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NumLoopsForColdStartFuelEnrich
    ;mptblcname CSFERX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Count 0 255 cnt
    ;mptbldesc Num_Loops_for_cold_start_reduction
    .byte 0x04                       ;Point 1

	;.org	0x81a4
PCCSFE_PercentForColdStartFuelEnrichment:
    ;mpgrp Spark\Start_to_Run_Transfer\
    ;mptbladdr 0x057A
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname PercentForColdStartFuelEnrichment
    ;mptblcname PCCSFE
    ;mpxaxis Coolant_Temp -200 260 Degrees
    ;mpyaxis Factor 0 1 factor
    ;mptbldesc Description
    .byte 0x03                       ;Number of points in table
    .byte 0x16, 0x01, 0x4C, 0x80     ;Point 1
    .byte 0x18, 0x9A, 0x00, 0xA4     ;Point 2
    .byte 0x3F, 0xB3                 ;Point 3

	;.org	0x81b3
STRTFL_FuelStartFromCoolantTemp:
    ;mpgrp Fuel\Starting\
    ;mptbladdr 0x058A
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname StartFuel_FromTemp
    ;mptblcname STRTFL
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis sqrtPW 0 222 uSec
    ;mptbldesc Start_fuel_uSec_=_[_STRTFL_*_STRTFL_*_(1_-_STFBAR_-_STFTMP)_*_EPPMUL_+_(BATOFF_*_4)_]_*_4
    ;mpinjscale sqrt
    .byte 0x09                       ;Number of points in table
    .byte 0x58, 0x5C, 0x00, 0x00     ;Point 1
    .byte 0x63, 0x5C, 0xFF, 0xA3     ;Point 2
    .byte 0x6E, 0x58, 0xFE, 0xBA     ;Point 3
    .byte 0x79, 0x4A, 0xFF, 0x2F     ;Point 4
    .byte 0x84, 0x41, 0xFF, 0x00     ;Point 5
    .byte 0x90, 0x35, 0xFF, 0x17     ;Point 6
    .byte 0x9B, 0x2B, 0xFF, 0x69     ;Point 7
    .byte 0xB1, 0x1E, 0xFF, 0x98     ;Point 8
    .byte 0xCC, 0x13                 ;Point 9

	;.org	0x81da
STRLMT_ColdestTempAllowedAtClosedThrottle:
    ;mpgrp Fuel\Starting\
    ;mptbladdr 0x05A1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ColdestTempAllowedAtClosedThrottle
    ;mptblcname STRLMT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 Degrees
    ;mptbldesc Coldest_temperature_accepted_as_input_to_STRTFL_table_-_anything_below_this_value_will_be_replaced_with_this_value
    .byte 0x69                       ;Point 1

	;.org	0x81db
STFTMP_FuelStartFuelFromCoolant:
    ;mpgrp Fuel\Starting\
    ;mptbladdr 0x05AE
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelStartFuelFromCoolant
    ;mptblcname STFTMP
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Inverse 0 1 factor
    ;mptbldesc Start_fuel_uSec_=_[_STRTFL_*_STRTFL_*_(1_-_STFBAR_-_STFTMP)_*_EPPMUL_+_(BATOFF_*_4)_]_*_4
    .byte 0x02                       ;Number of points in table
    .byte 0x63, 0xFF, 0xEB, 0x2F     ;Point 1
    .byte 0x6E, 0x1A                 ;Point 2

	;.org	0x81ea
EPPMUL_FuelStartFuelPerEPP:
    ;mpgrp Fuel\Starting\
    ;mptbladdr 0x05BD
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelStartFuelPerEPP
    ;mptblcname EPPMUL
    ;mpxaxis EPPs 0 255 count
    ;mpyaxis Multiplier 0 1 factor
    ;mptbldesc Start_fuel_uSec_=_[_STRTFL_*_STRTFL_*_(1_-_STFBAR_-_STFTMP)_*_EPPMUL_+_(BATOFF_*_4)_]_*_4._This_table_decreases_fuel_for_each_engine_rotation_while_starting
    .byte 0x02                       ;Number of points in table
    .byte 0x0F, 0x00, 0x0B, 0x11     ;Point 1
    .byte 0x1E, 0xA6                 ;Point 2

	;.org	0x81f5
STFTM2_FuelStartFuelFromCoolant2:
    ;mpgrp Fuel\Starting\
    ;mptbladdr 0x05CC
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelStartFuelFromCoolant2
    ;mptblcname STFTM2
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Inverse 0 1 factor
    ;mptbldesc Start_fuel_uSec_=_[_STRTFL_*_STRTFL_*_(1_-_STFBAR_-_STFTMP)_*_EPPMUL_+_(BATOFF_*_4)_]_*_4
    .byte 0x02                       ;Number of points in table
    .byte 0x6E, 0xFF, 0xFB, 0x74     ;Point 1
    .byte 0x79, 0xCD                 ;Point 2

	;.org	0x81fc
STFBAR_FuelStartReductionFromBaro:
    ;mpgrp Fuel\Starting\
    ;mptbladdr 0x05DB
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname FuelStartReductionFromBaro
    ;mptblcname STFBAR
    ;mpxaxis Baro -14.7 14.7 psi
    ;mpyaxis Inverse 0 1 factor
    ;mptbldesc Start_fuel_uSec_=_[_STRTFL_*_STRTFL_*_(1_-_STFBAR_-_STFTMP)_*_EPPMUL_+_(BATOFF_*_4)_]_*_4._This_decreases_fuel_slightly_at_higher_altitudes_to_account_for_thinner_air.
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x58, 0xA1, 0xFB, 0x44     ;Point 1
    .byte 0x7A, 0x00                 ;Point 2

	;.org	0x8207
SFDCAY_FuelStartDecayIntoRun:
    ;mpgrp Fuel\Starting\
    ;mptbladdr 0x05EB
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelStartDecayIntoRun
    ;mptblcname SFDCAY
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Subtracted 0 255 ms/rev
    ;mptbldesc Start_fuel_uSec_=_[_STRTFL_*_STRTFL_*_(1_-_STFBAR_-_STFTMP)_*_EPPMUL_+_(BATOFF_*_4)_]_*_4._This_allows_fuel_to_decay_gradually_after_the_start-run_transition.
    ;mpinjscale scale
    .byte 0x03                       ;Number of points in table
    .byte 0x63, 0x1A, 0xFF, 0x9A     ;Point 1
    .byte 0x90, 0x08, 0xFF, 0xEF     ;Point 2
    .byte 0xCC, 0x04                 ;Point 3

	;.org	0x8216
PRSHOT_KeyOnPrimePW:
    ;mpgrp Fuel\Starting\
    ;mptbladdr 0x05FC
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname KeyOnPrimePW
    ;mptblcname PRSHOT
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Pulsewidth 0 255 mSec
    ;mptbldesc Prime_Fuel_Shot_before_cranking
    ;mpinjscale scale
    .byte 0x04                       ;Number of points in table
    .byte 0x6E, 0x3C, 0xFE, 0x17     ;Point 1
    .byte 0x84, 0x12, 0xFF, 0xDF     ;Point 2
    .byte 0x9B, 0x0F, 0xFF, 0xD5     ;Point 3
    .byte 0xDD, 0x04                 ;Point 4

	;.org	0x8225
MAPIDL_FuelBaselineFromMap:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x060E
    ;mptbltype 1
    ;mpsubtype 1
    ;mptbllname FuelBaselineFromMap
    ;mptblcname MAPIDL
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Pulsewidth 0 65535 uSec
    ;mptbldesc Base_Map_Fuel_Pulsewidth.
    ;mpmapaxis x
    ;mpinjscale scale
    .byte 0x00                   ;Point 1
    .word 0x0000, 0x1069
    .byte 0x11                   ;Point 2
    .word 0x0117, 0x0000
    .byte 0x1A                   ;Point 3
    .word 0x0117, 0x0E2B
    .byte 0x32                   ;Point 4
    .word 0x026B, 0x1780
    .byte 0x3C                   ;Point 5
    .word 0x0356, 0x2260
    .byte 0x44                   ;Point 6
    .word 0x0469, 0x0EAC
    .byte 0x90                   ;Point 7
    .word 0x08C4, 0x1765
    .byte 0xBB                   ;Point 8
    .word 0x0CB2, 0x1F40
    .byte 0xFF

	;.org	0x8253
MAPTBL_FuelPartThrottle:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x062D
    ;mptbltype 1
    ;mpsubtype 1
    ;mptbllname FuelPartThrottle
    ;mptblcname MAPTBL
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Pulsewidth 0 65535 uSec
    ;mptbldesc Fuel_at_Part_Throttle._Other_tweaks_will_be_added_to_this_amount,_to_a_MAXIMUM_of_the_Full_Throttle_table_value.
    ;mpmapaxis x
    ;mpinjscale scale
    .byte 0x0D                   ;Point 1
    .word 0x0000, 0x138C
    .byte 0x18                   ;Point 2
    .word 0x00D7, 0x2700
    .byte 0x19                   ;Point 3
    .word 0x00FE, 0x10F6
    .byte 0x33                   ;Point 4
    .word 0x02B7, 0x0F00
    .byte 0x44                   ;Point 5
    .word 0x03B6, 0x102D
    .byte 0x66                   ;Point 6
    .word 0x05DC, 0x1051
    .byte 0x79                   ;Point 7
    .word 0x0712, 0x12E1
    .byte 0x90                   ;Point 8
    .word 0x08C4, 0x1764
    .byte 0xBB                   ;Point 9
    .word 0x0CB2, 0x1F40
    .byte 0xFF

	;.org	0x828b
WOTTBL_FuelFullThrottle:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x064E
    ;mptbltype 1
    ;mpsubtype 1
    ;mptbllname FuelFullThrottle
    ;mptblcname WOTTBL
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Pulsewidth 0 65535 uSec
    ;mptbldesc Fuel_at_Full_Throttle._This_is_also_a_maximum_for_the_Part_Throttle_value_after_other_tweaks_are_added.
    ;mpmapaxis x
    ;mpinjscale scale
    .byte 0x00                   ;Point 1
    .word 0x0000, 0x1477
    .byte 0x81                   ;Point 2
    .word 0x0A50, 0x1BDC
    .byte 0xB3                   ;Point 3
    .word 0x0FC1, 0x1A71
    .byte 0xEE                   ;Point 4
    .word 0x15D9, 0x1AE2
    .byte 0xFF

	;.org	0x82aa
BATOFF_FuelBatteryOffset:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x0665
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelBatteryOffset
    ;mptblcname BATOFF
    ;mpxaxis Battery 0 16.2 Volts
    ;mpyaxis Pulsewidth 0 4096 uSec
    ;mptbldesc Compensates_for_slower_opening_times_of_injectors_with_lower_voltage.
    .byte 0x04                       ;Number of points in table
    .byte 0x59, 0x6A, 0xFE, 0xDB     ;Point 1
    .byte 0x82, 0x3B, 0xFF, 0x90     ;Point 2
    .byte 0xC2, 0x1F, 0xFF, 0xCA     ;Point 3
    .byte 0xFB, 0x13                 ;Point 4

; *****************************************************************************
; Cold Enrichment Factor Calculation (CNRICH)
;
; 1 + ((CURVEA * ACVDCY/255 + CURVEC * ACVDCY/255 + CURVEB * FCRCVB/255) * 2 +
;     (HMPMUL * HIGHMP)/32) * BAROCP/255
;
; CURVEA, CURVEB, CURVEC Factors:
; X == Engine Temp DegC + 128 ( Engine Temp is scaled between -128C and +128C
;							      -198F and +262F
; Y == (Factor - 1) * 128 where the factor is between 1.00 and 2.99
;
; *****************************************************************************

	;.org	0x82bd
CURVEA_FuelColdEnrichmentCurveA:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x0683
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelColdEnrichmentCurveA
    ;mptblcname CURVEA
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Factor 1 2 factor
    ;mptbldesc Coldenrichment_factor_=_1_+_(_(CurveA_*_ADVDCY/255_+_CurveC_*_ADVDCY/255_+_CurveB_*_FCRCVB/255_)_/_32_)_*_BAROCP/255
    .byte 0x07                       ;Number of points in table
    .byte 0x58, 0x6D, 0xFE, 0x8C     ;Point 1
    .byte 0x6E, 0x4D, 0xFE, 0xD5     ;Point 2
    .byte 0x74, 0x46, 0xFF, 0xE0     ;Point 3
    .byte 0x84, 0x44, 0xFD, 0x6E     ;Point 4
    .byte 0x92, 0x20, 0x00, 0x00     ;Point 5
    .byte 0xA6, 0x20, 0xFF, 0xC9     ;Point 6
    .byte 0xE3, 0x13                 ;Point 7

	;.org	0x82e0
CURVEB_FuelColdEnrichmentCurveB:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x0697
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelColdEnrichmentCurveB
    ;mptblcname CURVEB
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Factor 0 2 factor
    ;mptbldesc Coldenrichment_factor_=_1_+_(_(CurveA_*_ADVDCY/255_+_CurveC_*_ADVDCY/255_+_CurveB_*_FCRCVB/255_)_/_32_)_*_BAROCP/255
    .byte 0x08                       ;Number of points in table
    .byte 0x58, 0x6F, 0xFE, 0x37     ;Point 1
    .byte 0x74, 0x3D, 0xFE, 0xD5     ;Point 2
    .byte 0x92, 0x1A, 0xFF, 0xD3     ;Point 3
    .byte 0xA3, 0x17, 0xFF, 0x84     ;Point 4
    .byte 0xC4, 0x07, 0xFF, 0x5D     ;Point 5
    .byte 0xCF, 0x00, 0x00, 0x00     ;Point 6
    .byte 0xEE, 0x00, 0x00, 0xE9     ;Point 7
    .byte 0xF9, 0x0A                 ;Point 8

	;.org	0x8303
CURVEC_FuelColdEnrichmentCurveC:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x06AC
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelColdEnrichmentCurveC
    ;mptblcname CURVEC
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Factor 1 3 factor
    ;mptbldesc Coldenrichment_factor_=_1_+_(_(CurveA_*_ADVDCY/255_+_CurveC_*_ADVDCY/255_+_CurveB_*_FCRCVB/255_)_/_32_)_*_BAROCP/255
    .byte 0x06                       ;Number of points in table
    .byte 0x79, 0x3A, 0xFF, 0x74     ;Point 1
    .byte 0x84, 0x34, 0xFF, 0x92     ;Point 2
    .byte 0x92, 0x2E, 0xFF, 0x4F     ;Point 3
    .byte 0xBC, 0x11, 0xFF, 0xE9     ;Point 4
    .byte 0xE9, 0x0D, 0x05, 0x66     ;Point 5
    .byte 0xEE, 0x28                 ;Point 6

	;.org	0x831a
FCRCVB_FuelWOTScaleEnrichBFromRpm:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x06BF
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelWOTScaleEnrichBFromRpm
    ;mptblcname FCRCVB
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis factor 0 1 scale
    ;mptbldesc B_Curve_Multiplier_is_used_at_Full_Throttle_only
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x33                 ;Point 1

	;.org	0x832d
TMPHLD_TempSwitchPointForCurveAHoldDecay:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x06CD
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TempSwitchPointForCurveAHoldDecay
    ;mptblcname TMPHLD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 Degrees
    ;mptbldesc Temperature_switch_point_for_Curve_A_Hold_and_Decay_times
    .byte 0x92                       ;Point 1

	;.org	0x832e
CLDHLD_CurveAColdHoldTime:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x06DA
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CurveAColdHoldTime
    ;mptblcname CLDHLD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 180 out
    ;mptbldesc Curve_A_Cold_Hold_time_-_value_=_this_number_times_.704_sec
    .byte 0x1D                       ;Point 1

	;.org	0x832f
HOTHLD_CurveAHotHoldTime:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x06E7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CurveAHotHoldTime
    ;mptblcname HOTHLD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Curve_A_Hot_Hold_Time_-_value_=_this_number_times_.704_sec
    .byte 0x0F                       ;Point 1

	;.org	0x8330
DCYTMC_CurveAColdDecayTime:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x06F4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CurveAColdDecayTime
    ;mptblcname DCYTMC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Curve_A_Cold_Decay_Time_-_value_=_89.76_divided_by_this_number
    .byte 0x04                       ;Point 1

	;.org	0x8331
DCYTMH_CurveAHotDecayTime:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x0701
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CurveAHotDecayTime
    ;mptblcname DCYTMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Curve_A_Hot_Decay_Time_-_value_=_89.76_divided_by_this_number
    .byte 0x09                       ;Point 1

	;.org	0x8332
CCURV_HoldTimeForCurveC:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x070E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname HoldTimeForCurveC
    ;mptblcname CCURV
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 180 out
    ;mptbldesc Hold_Time_for_Curve_C_-_value_=_this_number_times_.704_sec
    .byte 0x07                       ;Point 1

	;.org	0x8333
DCYCC_DecayRateForCurveC:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x071B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DecayRateForCurveC
    ;mptblcname DCYCC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Decay_Rate_for_Curve_C_-_value_=_89.76_divided_by_this_number
    .byte 0x12                       ;Point 1

; *****************************************************************************
; Load Enrichment:
; Cold Load Factor == HIGHMP * HMPMUL/32
;
; HIGHMP Factors:
; X - Engine Temp
; Y - (% enrichment per Torr/100) * 32 * 5.88 * 255
;
; HMPMUL Factors:
; X - MAP in Torr * 0.17
; Y - MAP in Torr * 0.17
;
; *****************************************************************************

	;.org	0x8334
HIGHMP_ColdLoadFromCoolantTemp:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x0736
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname ColdLoadFromCoolantTemp
    ;mptblcname HIGHMP
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis enrichment 0 100 Percent
    ;mptbldesc Cold_Load_Enrichment_Factor
    .byte 0x05                       ;Number of points in table
    .byte 0x8D, 0xA5, 0xFA, 0xF6     ;Point 1
    .byte 0xA6, 0x27, 0xFF, 0x00     ;Point 2
    .byte 0xCD, 0x00, 0x00, 0x00     ;Point 3
    .byte 0xE9, 0x00, 0x1B, 0x33     ;Point 4
    .byte 0xEE, 0x88                 ;Point 5

	;.org	0x834f
HMPMUL_ColdLoadFromMAP:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x0748
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname ColdLoadFromMAP
    ;mptblcname HMPMUL
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Facto 0 100 percent
    ;mptbldesc Cold_Load_Enrichment_Multiplier
    ;mpmapaxis x
    .byte 0x04                       ;Number of points in table
    .byte 0x24, 0x00, 0x00, 0xAB     ;Point 1
    .byte 0x2D, 0x06, 0x00, 0x13     ;Point 2
    .byte 0x55, 0x09, 0x00, 0x19     ;Point 3
    .byte 0x88, 0x0E                 ;Point 4

	;.org	0x8366
HIGHM2_ColdLoadFromCoolantTemp2:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x075A
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname ColdLoadFromCoolantTemp2
    ;mptblcname HIGHM2
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis enrichment 0 100 Percent
    ;mptbldesc Cold_Load_Enrichment_Factor
    .byte 0x02                       ;Number of points in table
    .byte 0xAB, 0x22, 0xFE, 0xC9     ;Point 1
    .byte 0xC7, 0x00                 ;Point 2

	;.org	0x8379
HMPMU2_ColdLoadFromMAP2:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x0769
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname ColdLoadFromMAP2
    ;mptblcname HMPMU2
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis Factor 0 100 percent
    ;mptbldesc Cold_Load_Enrichment_Multiplier
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x63, 0x00, 0x00, 0xDA     ;Point 1
    .byte 0x77, 0x11                 ;Point 2

	;.org	0x8390
BAROCP_BaroCompensationOfWarmupFactor_FromBaro:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x0779
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname BaroCompensationOfWarmupFactor_FromBaro
    ;mptblcname BAROCP
    ;mpxaxis Baro -14.7 14.7 psi
    ;mpyaxis Factor 0 100 Percent
    ;mptbldesc Baro_compensation_of_Warmup_Factor
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x55, 0x9A, 0xFF, 0x3C     ;Point 1
    .byte 0x77, 0x80                 ;Point 2

	;.org	0x839b
RUNTMP_ModifierOf_ENGTMP_FromStalltime:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x0789
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname ModifierOf_ENGTMP_FromStalltime
    ;mptblcname RUNTMP
    ;mpxaxis time_after_stall 0 720 sec
    ;mpyaxis delta 0 720 temp
    ;mptbldesc Delta_modifier_added_to_engine_temp_after_a_stall_before_key_on._This_is_to_approximate_heat_soak
    .byte 0x03                       ;Number of points in table
    .byte 0x00, 0x00, 0x03, 0xAB     ;Point 1
    .byte 0x06, 0x16, 0x09, 0x00     ;Point 2
    .byte 0x0B, 0x43                 ;Point 3

	;.org	0x83a6
RUNLMT_MaxAllowableTempFor_RUNTMP:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x0799
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MaxAllowableTempFor_RUNTMP
    ;mptblcname RUNLMT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 Degrees
    ;mptbldesc Max_allowable_temp_for_RUNTMP_(heat_soak_approximation)
    .byte 0xA3                       ;Point 1

	;.org	0x83a7
PEFTBL_PumpingEfficiency:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x07A6
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname PumpingEfficiency_FromRpm
    ;mptblcname PEFTBL
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis PumpEff 0 100 Percent
    ;mptbldesc Pumping_Efficiency
    .byte 0x08                       ;Number of points in table
    .byte 0x10, 0xFF, 0xFC, 0x74     ;Point 1
    .byte 0x1B, 0xD8, 0x00, 0x00     ;Point 2
    .byte 0x3F, 0xD8, 0x00, 0x4C     ;Point 3
    .byte 0x64, 0xE3, 0x00, 0x33     ;Point 4
    .byte 0x7D, 0xE8, 0xFF, 0xEC     ;Point 5
    .byte 0x8A, 0xE7, 0xFF, 0xCD     ;Point 6
    .byte 0x9E, 0xE3, 0xFF, 0x00     ;Point 7
    .byte 0xCE, 0xB3                 ;Point 8

	;.org	0x83ce
AIRTMP_FuelEnrichmentFromChargeTemp:
    ;mpgrp Fuel\Modifiers\
    ;mptbladdr 0x07BB
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname FuelEnrichmentFromChargeTemp
    ;mptblcname AIRTMP
    ;mpxaxis charge_temp -200 260 degrees
    ;mpyaxis Factor 1 2 factor
    ;mptbldesc Charge_Temp_Factor._Note_that_this_is_an_unfiltered_charge_temp_voltage,_so_higher_numbers_are_lower_temps
    .byte 0x04                       ;Number of points in table
    .byte 0x58, 0x40, 0xFF, 0x66     ;Point 1
    .byte 0xA1, 0x14, 0xFF, 0x86     ;Point 2
    .byte 0xB6, 0x0A, 0xFF, 0xCB     ;Point 3
    .byte 0xE6, 0x00                 ;Point 4

	;.org	0x83dd
PWADD_FuelPWModifierFromBaro:
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x07CC
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AdditiveBaroFuelCompensation_FromBaro
    ;mptblcname PWADD
    ;mpxaxis Baro -14.7 14.7 psi
    ;mpyaxis Pulsewidth 0 768 uSec
    ;mptbldesc Additive_Baro_Fuel_Compensation_-_fuel_added_based_on_altitude
    ;mpmapaxis x
    ;mpinjscale scale
    .byte 0x03                       ;Number of points in table
    .byte 0x55, 0x0B, 0xFF, 0xB7     ;Point 1
    .byte 0x6A, 0x05, 0xFF, 0xC6     ;Point 2
    .byte 0x80, 0x00                 ;Point 3

	;.org	0x83ec
POSTRG_PositiveTransientTriggerLevel:
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\TPS_PumpShot\
    ;mptbladdr 0x07DE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PositiveTransientTriggerLevel
    ;mptblcname POSTRG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Positive_Transient_Enrich_Trigger_Level_in_volts_times_0.02
    .byte 0x03                       ;Point 1

	;.org	0x83ed
THRMAX_MaxDeltaTHR:
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\TPS_PumpShot\
    ;mptbladdr 0x07EB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MaxDeltaTHR
    ;mptblcname THRMAX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Max_Delta_THR_(THR-AVTHR-POSTRG)_-_value_of_$26_is_.51_volts
    .byte 0x26                       ;Point 1

	;.org	0x83ee
POSSLP_DeltaTPSEnrichment_FromTemp:
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\TPS_PumpShot\
    ;mptbladdr 0x07F8
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname Enrichment_FromTemp
    ;mptblcname POSSLP
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis pw 0 60 ms/volt
    ;mptbldesc Throttle_Transient_Enrich_PW_Addition
    ;mpinjscale scale
    .byte 0x03                       ;Number of points in table
    .byte 0x74, 0x2F, 0xFE, 0xDB     ;Point 1
    .byte 0x90, 0x0F, 0xFF, 0xAB     ;Point 2
    .byte 0xB1, 0x04                 ;Point 3

	;.org	0x83fd
MAPTRG_DeltaMapTriggerLevel:
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\MAP_PumpShot\
    ;mptbladdr 0x0809
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DeltaMapTriggerLevel
    ;mptblcname MAPTRG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP 0 29.4 psi
    ;mptbldesc MAP_Delta_required_to_trigger_transient_enrichment
    ;mpmapaxis y
    .byte 0x07                       ;Point 1

	;.org	0x83fe
MAPMAX_MaxDeltaMapAllowed:
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\MAP_PumpShot\
    ;mptbladdr 0x0817
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname MaxDeltaMapAllowed
    ;mptblcname MAPMAX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP 0 29.4 psi
    ;mptbldesc Maximum_Delta_MAP_allowed
    ;mpmapaxis y
    .byte 0xFF                       ;Point 1

	;.org	0x83ff
AESLOP_DeltaMAPEnrichmentPT:
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\MAP_PumpShot\
    ;mptbladdr 0x0825
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname DeltaMAPEnrichmentPT
    ;mptblcname AESLOP
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis pwEnrich 0 255 uS/torr
    ;mptbldesc Transient_Enrichment_PW_Addition
    ;mpmapaxis -y
    ;mpinjscale scale
    .byte 0x04                       ;Number of points in table
    .byte 0x6E, 0x42, 0xFE, 0x8C     ;Point 1
    .byte 0x79, 0x32, 0xFF, 0x77     ;Point 2
    .byte 0x95, 0x23, 0xFF, 0x69     ;Point 3
    .byte 0xCD, 0x02                 ;Point 4

	;.org	0x840e
OCTAE_FakeDeltaMapIncrease:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x0838
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname FakeDeltaMapIncrease
    ;mptblcname OCTAE
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc Fake_Delta_Map_Increase._AVMAP_is_set_to_(MAP-OCTAE)_any_time_throttle_is_just_opened.
    ;mpmapaxis y
    .byte 0x00                       ;Point 1

	;.org	0x840f
LOTTHR_DecelLeanoutFactor_FromTemp:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_TPS_LO\
    ;mptbladdr 0x0846
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname DecelLeanoutFactor_FromTemp
    ;mptblcname LOTTHR
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis out_desc 0 1 scale
    ;mptbldesc Decel_leanout_factor_-_THR_based._When_Y_is_zero,_factor_is_1.00
    .byte 0x02                       ;Number of points in table
    .byte 0xB1, 0x00, 0xF9, 0x9A     ;Point 1
    .byte 0xB6, 0xE0                 ;Point 2

	;.org	0x841e
LOTTRG_DeltaTriggerForDecelLeanout:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_TPS_LO\
    ;mptbladdr 0x0855
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaTriggerForDecelLeanout
    ;mptblcname LOTTRG
    ;mpxaxis in_desc -200 260 degrees
    ;mpyaxis factor 0 1 factor
    ;mptbldesc Main_trigger_(Delta_trigger_level_for_THR_leanout)_-_Delta_THR
    .byte 0x0B                       ;Point 1

	;.org	0x841f
LOTRG2_SecondDecelLeanoutTrigger:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_TPS_LO\
    ;mptbladdr 0x0862
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SecondDecelLeanoutTrigger
    ;mptblcname LOTRG2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Second_trigger_-_leanout_inc_toward_1_when_between_triggers
    .byte 0x0B                       ;Point 1

	;.org	0x8420
LOTHYS_LeanoutDeltaThrottleHysteresis:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_TPS_LO\
    ;mptbladdr 0x086F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LeanoutDeltaThrottleHysteresis
    ;mptblcname LOTHYS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc hysteresis_about_delta_THR_trigger_levels
    .byte 0x01                       ;Point 1

	;.org	0x8421
DECEL_DecelLeanoutFactorMAP:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_MAP_LO\
    ;mptbladdr 0x087C
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname DecelLeanoutFactorMAP_FromTemp
    ;mptblcname DECEL
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis out_desc 0 100 percent
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0xB1, 0x00, 0xF8, 0x66     ;Point 1
    .byte 0xB6, 0xDA                 ;Point 2

	;.org	0x8430
DECTRG_DeltaMapTriggerForNoIncrementalLeanout:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_MAP_LO\
    ;mptbladdr 0x088B
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DeltaMapTriggerForNoIncrementalLeanout
    ;mptblcname DECTRG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc delta_map_trigger_level_for_no_incremental_leanout
    ;mpmapaxis y
    .byte 0x13                       ;Point 1

	;.org	0x8431
DTRG2_DeltaMapTriggerForMaxLeanout:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_MAP_LO\
    ;mptbladdr 0x0899
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DeltaMapTriggerForMaxLeanout
    ;mptblcname DTRG2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc delta_map_trigger_level_for_max_leanout_on_decel
    ;mpmapaxis y
    .byte 0x13                       ;Point 1

	;.org	0x8432
DECHYS_DeltaMapHysteresisonTriggerLevels:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_MAP_LO\
    ;mptbladdr 0x08A7
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DeltaMapHysteresisonTriggerLevels
    ;mptblcname DECHYS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc delta_map_hysteresis_on_trigger_levels
    ;mpmapaxis y
    .byte 0x01                       ;Point 1

	;.org	0x8433
DLTRPM2_RPMDeltaForRPMFilter:
    ;mpgrp Setup\Transfer_Functions\
    ;mptbladdr 0x08B5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RPMDeltaForRPMFilter
    ;mptblcname DLTRPM2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Delta_RPM_at_RPM_Boundaries
    .byte 0xFF                       ;Point 1

	;.org	0x8434
LOTRPM_MinRpmForMapLeanout:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_MAP_LO\
    ;mptbladdr 0x08C2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinRpmForMapLeanout
    ;mptblcname LOTRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc No_map_leanout_if_below_this_RPM
    .byte 0x35                       ;Point 1

	;.org	0x8435
DCELTM_O2CNTRInhibitAfterLeanoutDone:
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_MAP_LO\
    ;mptbladdr 0x08CF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname O2CNTRInhibitAfterLeanoutDone
    ;mptblcname DCELTM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc O2CNTR_inhibit_after_MAP/THR_leanout_is_done_(times_11_ms)
    .byte 0x01                       ;Point 1

	;.org	0x8436
POSTIG_MinAisPulseRequireToTriggerEnrichment:
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\AIS_Enrichment\
    ;mptbladdr 0x08DC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinAisPulseRequireToTriggerEnrichment
    ;mptblcname POSTIG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Min_AIS_pulse_required_to_trigger_enrichment_(steps)
    .byte 0x09                       ;Point 1

	;.org	0x8437
POSFUL_AisEnrichmentFuelPulse:
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\AIS_Enrichment\
    ;mptbladdr 0x08E9
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname AisEnrichmentFuelPulse
    ;mptblcname POSFUL
    ;mpxaxis in_desc 0 255 scale
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc AIS_enrichment_fuel_pulse_in_uSec
    ;mpinjscale word
    .word 0x00A0                     ;Point 1

	;.org	0x8439
MINPTE_MinPWForPartThorttleEnrich:
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x08F7
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname MinPWForPartThorttleEnrich
    ;mptblcname MINPTE
    ;mpxaxis X 0 255 scale
    ;mpyaxis Y 0 255 out
    ;mptbldesc MinPWForPartThorttleEnrich
    ;mpinjscale word
    .word 0x0004                     ;Point 1

	;.org	0x843b
AETIME_EnrichmentTime_FromTemp:
; this is actually one of the 2 MAP averaging factor tables
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\MAP_PumpShot\
    ;mptbladdr 0x0906
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname EnrichmentTime_FromTemp_MAP
    ;mptblcname AETIME
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis time_const 0 100 percent
    ;mptbldesc MAP_Transient_Enrich_Time_Constant_when_MAP_gt_AVMAP
    .byte 0x03                       ;Number of points in table
    .byte 0x84, 0x14, 0xFF, 0x6B     ;Point 1
    .byte 0x90, 0x0D, 0x00, 0x29     ;Point 2
    .byte 0xBC, 0x14                 ;Point 3

	;.org	0x8446
LMAPTC_TimeConstant:
; this is actually one of the 2 MAP averaging factor tables
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_MAP_LO\
    ;mptbladdr 0x0917
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname TimeConstant
    ;mptblcname LMAPTC
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis time_const 0 100 percent
    ;mptbldesc lean_out_time_constant_based_on_MAP
    .byte 0x02                       ;Number of points in table
    .byte 0xBC, 0xE6, 0xF4, 0xB7     ;Point 1
    .byte 0xCA, 0x48                 ;Point 2

	;.org	0x844d
THRTCN_EnrichmentTime_FromTemp:
; this is actually one of the 2 TPS averaging factor tables
    ;mpgrp Fuel\Transient_Enrichment\PumpShot_Calculation\TPS_PumpShot\
    ;mptbladdr 0x0927
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname EnrichmentTime_FromTemp_TPS
    ;mptblcname THRTCN
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis time_const 0 100 percent
    ;mptbldesc Throttle_Transient_Enrich_Time_Constant
    .byte 0x02                       ;Number of points in table
    .byte 0x74, 0x18, 0x00, 0x17     ;Point 1
    .byte 0xCD, 0x20                 ;Point 2

	;.org	0x8458
LOTIME_DecelLeanoutTimeConstant_FromTemp:
; this is actually one of the 2 TPS averaging factor tables
    ;mpgrp Fuel\Transient_Enrichment\Decel_Lean-out\Decreasing_TPS_LO\
    ;mptbladdr 0x0937
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname DecelLeanoutTimeConstant_FromTemp
    ;mptblcname LOTIME
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis time_const 0 100 percent
    ;mptbldesc Leanout_Time_Constant_based_on_Delta_THR_-_uses_average_throttle
    .byte 0x02                       ;Number of points in table
    .byte 0xB1, 0xE6, 0xFB, 0x00     ;Point 1
    .byte 0xCD, 0x5A                 ;Point 2

	;.org	0x845f
RPMMAP_SwitchPointForDownUp_FromRpm :
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x0946
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname SwitchPointForDownUp_FromRpm
    ;mptblcname RPMMAP
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc EPP_Control_toggle
    ;mpmapaxis y
    .byte 0x04                       ;Number of points in table
    .byte 0x3F, 0xA6, 0xFF, 0x7B     ;Point 1
    .byte 0x71, 0x8C, 0xFE, 0x29     ;Point 2
    .byte 0x8A, 0x5E, 0xFF, 0x9F     ;Point 3
    .byte 0xAF, 0x50                 ;Point 4

	;.org	0x8476
PTELMT_MultiplierMaxLimitFromRpm:
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x0958
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname MultiplierMaxLimitFromRpm
    ;mptblcname PTELMT
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis factor 0 100 factor
    ;mptbldesc PTE_Multiplier_limit
    .byte 0x05                       ;Number of points in table
    .byte 0x3F, 0x2D, 0x00, 0x32     ;Point 1
    .byte 0x5E, 0x33, 0x01, 0x2F     ;Point 2
    .byte 0x74, 0x4D, 0x00, 0x00     ;Point 3
    .byte 0x8A, 0x4D, 0x00, 0x8A     ;Point 4
    .byte 0xAF, 0x61                 ;Point 5

	;.org	0x848d
PTEADJ_EnrichAdjust_FromMap:
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x096A
    ;mptbltype 2
    ;mpsubtype 1
    ;mptbllname EnrichAdjust_FromMap
    ;mptblcname PTEADJ
    ;mpxaxis MAP -14.7 14.7 psi
    ;mpyaxis factor 0.5 1.5 factor
    ;mptbldesc Part_Throttle_Enrichment_-_multiplier_from_MAP_-_NOTE:_zero_is_1.00
    ;mpmapaxis x
    .byte 0x04                       ;Number of points in table
    .byte 0x6F, 0xB3, 0x01, 0x5E     ;Point 1
    .byte 0x8D, 0xDC, 0x00, 0x00     ;Point 2
    .byte 0x99, 0xDC, 0xFF, 0x35     ;Point 3
    .byte 0xD3, 0xAE                 ;Point 4

	;.org	0x84a8
PTENR_EppPerAmountForIncreasing:
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x097C
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname EppPerAmountForIncreasing
    ;mptblcname PTENR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc EPP_per_amount_for_increasing_multiplier
    .word 0x3D01                     ;Point 1

	;.org	0x84aa
PTENR2_EppPerAmountForDecreasingMultiplier:
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x0989
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EppPerAmountForDecreasingMultiplier
    ;mptblcname PTENR2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc EPP_per_amount_for_decreasing_multiplier
    .byte 0x2D                       ;Point 1

	;.org	0x84ab
PTENRD_AmountForDecreasingMultiplier_Negative:
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x0996
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AmountForDecreasingMultiplier_Negative
    ;mptblcname PTENRD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Amount_for_decreasing_multiplier_(neg_number)
    .byte 0xFF                       ;Point 1

	;.org	0x84ac
PTENUM_NumberToReturnToHOTMAP:
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x09A3
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NumberToReturnToHOTMAP
    ;mptblcname PTENUM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc No_of_PTENRD_below_PTELMT_that_PT_enrich_must_be_to_return_to_HOTMAP_spark_advance_after_maxed_out
    .byte 0x02                       ;Point 1

	;.org	0x84ad
BOOSTP_AdjustO2ResponseForPTEWhenMapAboveThis:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x09B0
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AdjustO2ResponseForPTEWhenMapAboveThis
    ;mptblcname BOOSTP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP 0 29.4 psi
    ;mptbldesc Zero_percent_limit_on_lean_O2CNTR_if_MAP_gt_BOOSTP_and_no_PTE
    ;mpmapaxis y
    .byte 0xFF                       ;Point 1

	;.org	0x84ae
O2ITIM_TimeO2InhibitedSwitchingRichIdleToClosedLoop:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x09BE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TimeO2InhibitedSwitchingRichIdleToClosedLoop
    ;mptblcname O2ITIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc O2_is_inhibited_for_this_time_when_switching_from_rich_idle_to_closed_loop_idle
    .byte 0xFF                       ;Point 1

	;.org	0x84af
RICHSA_OpenLoopEnrichFactorWhenSettingBasicTiming:
    ;mpgrp Idle\Special_setup\
    ;mptbladdr 0x09CB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname OpenLoopEnrichFactorWhenSettingBasicTiming
    ;mptblcname RICHSA
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Open_loop_enrich_factor_when_setting_mechanical_basic_timing
    .byte 0x00                       ;Point 1

	;.org	0x84b0
SPKSET_ConstantSparkAdvanceWhenSettingBasicTiming:
    ;mpgrp Idle\Special_setup\
    ;mptbladdr 0x09D8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ConstantSparkAdvanceWhenSettingBasicTiming
    ;mptblcname SPKSET
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Advance 0 128 degrees
    ;mptbldesc Constant_spark_advance_setting_when_setting_basic_timing_(stock_12_degrees)
    .byte 0x0C                       ;Point 1

	;.org	0x84b1
IDLDEF_TargetIdleSpeed_HBDefault:
    ;mpgrp Idle\Special_setup\
    ;mptbladdr 0x09E5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TargetIdleSpeed_HBDefault
    ;mptblcname IDLDEF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x7D                       ;Point 1

	;.org	0x84b2
RIDLST_OpenLoopEnrichFactorWhenSettingMinThrottleOpening:
    ;mpgrp Idle\Special_setup\
    ;mptbladdr 0x09F2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname OpenLoopEnrichFactorWhenSettingMinThrottleOpening
    ;mptblcname RIDLST
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Open_loop_enrich_factor_when_setting_min_throttle_blade_opening_(actuator_test_#70)
    .byte 0x08                       ;Point 1

	;.org	0x84b3
IDLSET_ConstantSparkAdvanceWhenSettingMinThrottleOpening:
    ;mpgrp Idle\Special_setup\
    ;mptbladdr 0x09FF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ConstantSparkAdvanceWhenSettingMinThrottleOpening
    ;mptblcname IDLSET
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Advance 0 128 degrees
    ;mptbldesc Constant_spark_advance_setting_when_setting_min_throttle_blade_opening_(actuator_test_#70)
    .byte 0x0C                       ;Point 1

	;.org	0x84b4
AMTEMP_StartTempToSelectHotOrColdAMTimer:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_Memory_Timer\
    ;mptbladdr 0x0A0C
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname StartTempToSelectHotOrColdAMTimer
    ;mptblcname AMTEMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 deg
    ;mptbldesc Starting_Temp_to_select_hot_or_cold_AM_timer
    .byte 0xCF                       ;Point 1

	;.org	0x84b5
AMTPSW_TempPointToEnableSelectedAMTimer:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_Memory_Timer\
    ;mptbladdr 0x0A19
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname TempPointToEnableSelectedAMTimer
    ;mptblcname AMTPSW
    ;mpxaxis Coolant_Temp -200 260 deg
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc AM_temp_inhibit_time_from_coolant_temp
    .byte 0x02                       ;Number of points in table
    .byte 0xBD, 0x0C, 0x03, 0x50     ;Point 1
    .byte 0xCD, 0x41                 ;Point 2

	;.org	0x84c4
CLTIME_ClosedLoopTimeFromEngTempAtStartup_FromTemp:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_Memory_Timer\
    ;mptbladdr 0x0A28
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname ClosedLoopTimeFromEngTempAtStartup_FromTemp
    ;mptblcname CLTIME
    ;mpxaxis Coolant_Temp -200 260 degrees
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Leave_at_one_-_2.8_sec
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x03                 ;Point 1

	;.org	0x84cb
CLTEMP_TempToStartCLTIMETimer:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_Memory_Timer\
    ;mptbladdr 0x0A36
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TempToStartCLTIMETimer
    ;mptblcname CLTEMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 degrees
    ;mptbldesc Temperature_to_start_CLTIME_Timer_-_$94_=_70degreesF
    .byte 0x90                       ;Point 1

; *****************************************
; Auto Cal Factors Table
; *****************************************
;
;  closed throttle = cell 12, otherwise:
;  $ff
;	 +-----+-----+-----+-----+-----+-----+
;	 |  1  |  3  |	5  |  7  |  9  |  11 |
;    R1  +-----+-----+-----+-----+-----+-----+
;	 |  0  |  2  |	4  |  6  |  8  |  10 |
;  rpm^  +-----+-----+-----+-----+-----+-----+
;  map>       MP1   MP2   MP3	MP4   MP5     $ff
;
; *****************************************
; mp1-mp5 should be scaled for 3-bar

	;.org	0x84cc
MP1_AutoCalMapCellBoundary1:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0A53
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AutoCalMapCellBoundary1
    ;mptblcname MP1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc AutoCalMapCellBoundary1
    ;mpmapaxis y
    .byte 0x28                       ;Point 1

	;.org	0x84cd
MP2_AutoCalMapCellBoundary2:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0A61
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AutoCalMapCellBoundary2
    ;mptblcname MP2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc AutoCalMapCellBoundary1
    ;mpmapaxis y
    .byte 0x37                       ;Point 1

	;.org	0x84ce
MP3_AutoCalMapCellBoundary3:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0A6F
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AutoCalMapCellBoundary3
    ;mptblcname MP3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc AutoCalMapCellBoundary1
    ;mpmapaxis y
    .byte 0x4B                       ;Point 1

	;.org	0x84cf
MP4_AutoCalMapCellBoundary4:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0A7D
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AutoCalMapCellBoundary4
    ;mptblcname MP4
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc AutoCalMapCellBoundary1
    ;mpmapaxis y
    .byte 0x61                       ;Point 1

	;.org	0x84d0
MP5_AutoCalMapCellBoundary5:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0A8B
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AutoCalMapCellBoundary5
    ;mptblcname MP5
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc AutoCalMapCellBoundary1
    ;mpmapaxis y
    .byte 0x78                       ;Point 1

	;.org	0x84d1
DLTMAP_MapHysteresisAtMapCellBoundaries:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0A99
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname MapHysteresisAtMapCellBoundaries
    ;mptblcname DLTMAP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc Map_Hysteresis_At_Map_Cell_Boundaries
    ;mpmapaxis y
    .byte 0x01                       ;Point 1

	;.org	0x84d2
R1_RPMCellBoundaryInRPMover32:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0AA7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RPMCellBoundaryInRPMover32
    ;mptblcname R1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc RPM_Cell_Boundary
    .byte 0x3A                       ;Point 1

	;.org	0x84d3
DLTRPM_DeltaRPMAtRPMBoundariesInRPMOver32:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0AB4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaRPMAtRPMBoundariesInRPMOver32
    ;mptblcname DLTRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Delta_RPM_at_RPM_Boundaries
    .byte 0x02                       ;Point 1

	;.org	0x84d4
IDLOFS_DeltaForIdleRPMForClosedThrottleCell:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0AC1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaForIdleRPMForClosedThrottleCell
    ;mptblcname IDLOFS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc RPM_Delta_for_Idle_RPM_For_Closed_Throttle_Cell
    .byte 0x03                       ;Point 1

	;.org	0x84d5
HYTRPM_HysteresisFor_IDLOFS:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0ACE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname HysteresisFor_IDLOFS
    ;mptblcname HYTRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Hysteresis_for_IDLOFS
    .byte 0x02                       ;Point 1

	;.org	0x84d6
CELCHG_BitsChangePerUpdateWithinACell:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0ADB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BitsChangePerUpdateWithinACell
    ;mptblcname CELCHG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Number_of_Bits_Change_Per_Update_Within_A_Cell
    .byte 0x01                       ;Point 1

	;.org	0x84d7
AMUPDT_EPPsBetweenCalChangeUpdateOpenThrottle:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0AE8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EPPsBetweenCalChangeUpdateOpenThrottle
    ;mptblcname AMUPDT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc EPPs_Between_Cal_Change_Update_(Open_Throttle)
    .byte 0x1A                       ;Point 1

	;.org	0x84d8
AMUPDI_EPPsBetweenCalChangeUpdateClosedThrottle:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0AF5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EPPsBetweenCalChangeUpdateClosedThrottle
    ;mptblcname AMUPDI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc EPPs_Between_Cal_Change_Update_(Closed_Throttle)
    .byte 0x1A                       ;Point 1

	;.org	0x84d9
CALTH1_O2ControllerDeadbandLimitForUpdatingCells1:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0B02
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname O2ControllerDeadbandLimitForUpdatingCells1
    ;mptblcname CALTH1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc O2_Controller_Deadband_Limit_For_Updating_Cells
    .byte 0x09                       ;Point 1

	;.org	0x84da
CALTH2_O2ControllerDeadbandLimitForUpdatingCells2:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0B0F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname O2ControllerDeadbandLimitForUpdatingCells2
    ;mptblcname CALTH2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc O2_Controller_Deadband_Limit_For_Updating_Cells
    .byte 0x09                       ;Point 1

	;.org	0x84db
MAPLIM_NoCellUpdateAboveThisMAP:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0B1C
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname NoCellUpdateAboveThisMAP
    ;mptblcname MAPLIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc No_Cell_Update_Above_This_MAP
    ;mpmapaxis y
    .byte 0x8A                       ;Point 1

	;.org	0x84dc
MAPDEC_NoCellUpdateAndO2CNTRHeldBelowThisMap:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0B2A
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname NoCellUpdateAndO2CNTRHeldBelowThisMap
    ;mptblcname MAPDEC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc No_Cell_Update_And_O2CNTR_Held_Below_This_Map._Set_to_0xff_to_disable_O2_feedback.
    ;mpmapaxis y
    .byte 0x1A                       ;Point 1

	;.org	0x84dd
RPMLIM_NoCellUpdateAboveThisRPMInRPMOver32:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0B38
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NoCellUpdateAboveThisRPMInRPMOver32
    ;mptblcname RPMLIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc No_Cell_Update_Above_This_RPM_-_in_rpms/32
    .byte 0x56                       ;Point 1

	;.org	0x84de
PWMIN_NoCellUpdateBelow_PWMIN_Pulsewidth:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0B45
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname NoCellUpdateBelow_PWMIN_Pulsewidth
    ;mptblcname PWMIN
    ;mpxaxis in_desc 0 255 scale
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc No_Cell_Update_below_PWMIN_-_this_value_times_4_uSec
    ;mpinjscale word
    .word 0x012C                     ;Point 1

MNPWDS_MinimumInjPWForDistSync:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x0B52
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname MinimumInjPWForDistSync
    ;mptblcname MNPWDS
    ;mpxaxis in_desc 0 255 scale
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc No_Dist_Sync_below_MNPWDS
    .word 0x007D                     ;Point 1
;       .inj word scale

	;.org	0x84e0
AMLIMH_MaxMultiplierCannotBeAbove7F:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0B60
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MaxMultiplierCannotBeAbove7F
    ;mptblcname AMLIMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc AutoCal_Range_Of_Authority_where_MaxMultiplier=1+AMLIMH/512_(cannot_exceed_$7f)
    .byte 0x7F                       ;Point 1

	;.org	0x84e1
AMLIML_MinMultiplierCannotBeBelow80:
    ;mpgrp Fuel\O2_Feedback_Control\Adaptive_memory\
    ;mptbladdr 0x0B6D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinMultiplierCannotBeBelow80
    ;mptblcname AMLIML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc AutoCal_Range_Of_Authority_where_MinMultiplier=.5+AMLIML/512_(cannot_be_below_$80)
    .byte 0x80                       ;Point 1

        .msg "..." ; these are just messages to display during assemble to let you know what's going on...


; *****************************************
;      O2 Controller Ramp Calibration
; *****************************************
; How it works:
;   The O2 sensor is monitored but ONLY for "rich/lean". Even though
;   the O2 sensor value is from 0 to 15, the only thing that counts
;   for this system is whether it is "rich" or "lean". A change from one
;   to the other is a "toggle". The system constantly toggles between
;   rich and lean so that the overall average is around stoichiometric.
;
; Background information (from the net:)
;     An "ideal" fuel/air mixture in which both the fuel and the oxygen in the air are
;     completely consumed is called the "stoichiometric" mixture. The stoichiometric mixture
;     is usually specified as the ratio of the mass of air to the mass of a particular fuel.
;     For example, if a fuel required 10 kg of air to precisely burn 1 kg of the fuel (that is,
;     all the fuel burned and there was no oxygen left in the air afterwards) then the
;     stoichiometric ratio for that fuel would be 10:1.
;
;     Chevron give the stoichiometric ratio of air mass to fuel mass for gasoline as 14.7:1,
;     but don't specify the composition of this hypothetical gasoline.
;
;     From http://www.faqs;;.org/faqs/autos/gasoline-faq/part2/ comes the following table
;     of typical stoichiometric air-fuel ratios:
;
;	     Fuel   | Stoichiometric air-fuel ratio
;	 -----------+------------------------------
;	   methanol | 6.4
;	    ethanol | 9.0
;	       MTBE | 11.7
;	 ETBE, TAME | 12.1
;	   gasoline | 14.6
;
;     An oxygenated gasoline with 89% gasoline and 11% MTBE would then have a stoichiometric
;     ratio of 14.281 (note that this would require a Wide Band O2 sensor to adjust, since the
;     O2 sensor in our cars is designed for gasoline only, and is a very narrow range. In case
;     you were wondering, this is one reason some people are interested in Wide Band O2 sensors.)
;
; *****************************************
; This system divides a range of RPMs and MAP readings into "cells". The number of
; "kicks", or increases/decreases in fuel required to toggle the O2 reading, is different
; for each of these cells. This allows some fairly powerful flexibility in tuning. The
; only time you might want to adjust these values is for different injector flow rates,
; or to speed or slow the adjustment being performed.
; *****************************************
; Note to tuners: DO NOT AIM FOR STOICHIOMETRY! Although it might be fine for idle or
; low speed operation, at higher RPMs and under boost you DEFINITELY want a RICH mixture.
; This is because stoichiometric combustion generates the most heat. No current engine
; would survive very long with the temperatures this would generate, hot enough to melt
; the engine.
; *****************************************
; Each cell has a kick value. This is the amount of change applied to the running fuel
; every eleven millisec until a rich/lean toggle occurs. The net result is the
; familiar rich/lean flashing that your O2 sensor gauge shows you.
; *****************************************
;
; (one kick per 11ms)
; Fudge factor: if an O2 toggle occurs before the primary ramp
; finishes, then the "first" step in the new direction is limited
; to the accumulated steps before the toggle.
;
;		Cells:
;
; HIRPM  +-----+-----+-----+
;	 |  2  |  5  |	8  |
; RPM#2  +-----+-----+-----+
;	 |  1  |  4  |	7  |
; RPM#1  +-----+-----+-----+
;	 |  0  |  3  |	6  |	    Idle Cell: 9
;	 +-----+-----+-----+
;	  Map#1 MAP#2 HIMAP
;
; *****************************************
;  PrimaryO2Ramp:
; *****************************************

	;.org	0x84e2
PRIRMP_PrimaryRamp:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller_Ramps\
    ;mptbladdr 0x0BC8
    ;mptbltype 11
    ;mpsubtype 1
    ;mptbllname PrimaryRamp
    ;mptblcname PRIRMP
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Lower_RPM_Boundary_-_RPM/32
    ;mpmapaxis y
    .word 0x2632                  ;Rpm Low / High Boundary
    .word 0x3355                  ;Map Low / High Boundary
    .word 0x1A04                  ;Cell 0 Ramp Rich/Lean
    .word 0x1A05                  ;Cell 1 Ramp Rich/Lean
    .word 0x1A05                  ;Cell 2 Ramp Rich/Lean
    .word 0x1A04                  ;Cell 3 Ramp Rich/Lean
    .word 0x1A05                  ;Cell 4 Ramp Rich/Lean
    .word 0x1A05                  ;Cell 5 Ramp Rich/Lean
    .word 0x1A04                  ;Cell 6 Ramp Rich/Lean
    .word 0x1A05                  ;Cell 7 Ramp Rich/Lean
    .word 0x1A05                  ;Cell 8 Ramp Rich/Lean
    .word 0x0101                  ;Ramp Idle Cell Rich/Lean
    .word 0x0F0F                  ;Cell 0 Limits/Rates Rich/Lean
    .word 0x1515                  ;Cell 1 Limits/Rates Rich/Lean
    .word 0x1515                  ;Cell 2 Limits/Rates Rich/Lean
    .word 0x0F0F                  ;Cell 3 Limits/Rates Rich/Lean
    .word 0x1515                  ;Cell 4 Limits/Rates Rich/Lean
    .word 0x1515                  ;Cell 5 Limits/Rates Rich/Lean
    .word 0x0F0F                  ;Cell 6 Limits/Rates Rich/Lean
    .word 0x1515                  ;Cell 7 Limits/Rates Rich/Lean
    .word 0x1515                  ;Cell 8 Limits/Rates Rich/Lean
    .word 0x0101                  ;Limit/Rates Idle Cell Rich/Lean

; *****************************************
; For each cell, the first number is "rich", the second is "lean".
; If the O2 sensor is returning a lean value, "rich" kicks are added.
; If the O2 sensor is returning a rich value, "lean" kicks are added.
;
;     KICK - (factor * 512) - 512  (unsigned number)
; eg: $19  -   1.05  * 512  - 512 - 5%
; *****************************************
; *****************************************
; The Limits are the maximum number of kicks that may be applied to each
; cell. If the O2 sensor fails to toggle after reaching the limit for more
; than a few sec, the AutoCal cell gets changed.
; *****************************************

	;.org	0x850e
O2LIMH_O2RangeLimitHigh:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0BF9
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname O2RangeLimitHigh
    ;mptblcname O2LIMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc O2_Range_Of_Authority_MaxMultiplier=1+O2LIMH/512_(cannot_be_above_$7f)
    .byte 0x7F                       ;Point 1

	;.org	0x850f
O2LIML_O2RangeLimitLow:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C06
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname O2RangeLimitLow
    ;mptblcname O2LIML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc O2_Range_Of_Authority_MinMultiplier=.5+O2LIML/512_(cannot_be_below_$80)
    .byte 0xB3                       ;Point 1

	;.org	0x8510
O2HIGH_HighLimitForImmediateSwitchToClosedLoop:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C13
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname HighLimitForImmediateSwitchToClosedLoop
    ;mptblcname O2HIGH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc HighLimitForImmediateSwitchToClosedLoop_$26_=_0.73v
    .byte 0x26                       ;Point 1

	;.org	0x8511
O2TLMH_HighLimitForDelayedSwitchToClosedLoop:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C20
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname HighLimitForDelayedSwitchToClosedLoop
    ;mptblcname O2TLMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc HighLimitForDelayedSwitchToClosedLoop
    .byte 0x1F                       ;Point 1

	;.org	0x8512
O2MIDH_HighLimitForInMiddleDetermination:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C2D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname HighLimitForInMiddleDetermination
    ;mptblcname O2MIDH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc HighLimitForInMiddleDetermination
    .byte 0x1C                       ;Point 1

	;.org	0x8513
O2HSWP_HighLimitForO2RampSwitching:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C3A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname HighLimitForO2RampSwitching
    ;mptblcname O2HSWP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc HighLimitForO2RampSwitching
    .byte 0x17                       ;Point 1

	;.org	0x8514
O2LSWP_LowLimitForO2RampSwitching:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C47
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LowLimitForO2RampSwitching
    ;mptblcname O2LSWP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc LowLimitForO2RampSwitching
    .byte 0x16                       ;Point 1

	;.org	0x8515
O2MIDL_LowLimitForInMiddleDetermination:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C54
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LowLimitForInMiddleDetermination
    ;mptblcname O2MIDL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc LowLimitForInMiddleDetermination._Used_for_Reverting_to_openLoop,_Setting_fault21,_outputting_O2_level_to_miller_tool
    .byte 0x12                       ;Point 1

	;.org	0x8516
O2TLML_LowLimitForDelayedSwitchToClosedLoop:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C61
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LowLimitForDelayedSwitchToClosedLoop
    ;mptblcname O2TLML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc LowLimitForDelayedSwitchToClosedLoop
    .byte 0x0F                       ;Point 1

	;.org	0x8517
O2LOW_LowLimitForImmediateSwitchToClosedLoop:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C6E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LowLimitForImmediateSwitchToClosedLoop
    ;mptblcname O2LOW
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc LowLimitForImmediateSwitchToClosedLoop
    .byte 0x0F                       ;Point 1

	;.org	0x8518
O2TIME_DelayTimeToClosedLoop:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C7B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DelayTimeToClosedLoop
    ;mptblcname O2TIME
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Delay_Time 0 720 Sec
    ;mptbldesc DelayTimeWhenGoingClosedLoop._o2_voltage_must_trigger_timer,_ie_must_gt_O2TLMH_or_lt_O2TLML.Each_1_is_2.8_sec,_cannot_exceed_$7f
    .byte 0x07                       ;Point 1

	;.org	0x8519
LTHTIM_IfNoO2SwitchForThisTimeThrowFault51or52:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller\
    ;mptbladdr 0x0C88
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname IfNoO2SwitchForThisTimeThrowFault51or52
    ;mptblcname LTHTIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc If_no_O2_sensor_state_change_for_this_time(*2.8sec)_then_fault_51_or_52
    .byte 0x2C                       ;Point 1

	;.org	0x851a
SECRMP_SecondaryRamp:
    ;mpgrp Fuel\O2_Feedback_Control\O2_Controller_Ramps\
    ;mptbladdr 0x0C95
    ;mptbltype 11
    ;mpsubtype 1
    ;mptbllname SecondaryRamp
    ;mptblcname SECRMP
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Lower_RPM_Boundary_-_RPM/32
    ;mpmapaxis y
    .word 0x2649                  ;Rpm Low / High Boundary
    .word 0x2B50                  ;Map Low / High Boundary
    .word 0x03FD                  ;Cell 0 Ramp Rich/Lean
    .word 0x04FC                  ;Cell 1 Ramp Rich/Lean
    .word 0x01FF                  ;Cell 2 Ramp Rich/Lean
    .word 0x04FC                  ;Cell 3 Ramp Rich/Lean
    .word 0x03FD                  ;Cell 4 Ramp Rich/Lean
    .word 0x03FD                  ;Cell 5 Ramp Rich/Lean
    .word 0x03FD                  ;Cell 6 Ramp Rich/Lean
    .word 0x03FD                  ;Cell 7 Ramp Rich/Lean
    .word 0x03FD                  ;Cell 8 Ramp Rich/Lean
    .word 0x01FF                  ;Ramp Idle Cell Rich/Lean
    .word 0x0608                  ;Cell 0 Limits/Rates Rich/Lean
    .word 0x0608                  ;Cell 1 Limits/Rates Rich/Lean
    .word 0x0608                  ;Cell 2 Limits/Rates Rich/Lean
    .word 0x0606                  ;Cell 3 Limits/Rates Rich/Lean
    .word 0x0208                  ;Cell 4 Limits/Rates Rich/Lean
    .word 0x0508                  ;Cell 5 Limits/Rates Rich/Lean
    .word 0x0708                  ;Cell 6 Limits/Rates Rich/Lean
    .word 0x0308                  ;Cell 7 Limits/Rates Rich/Lean
    .word 0x0708                  ;Cell 8 Limits/Rates Rich/Lean
    .word 0x0608                  ;Limit/Rates Idle Cell Rich/Lean

; *****************************************
; For each cell, the first number is "rich", the second is "lean".
; If the O2 sensor is returning a lean value, "rich" kicks are added.
; If the O2 sensor is returning a rich value, "lean" kicks are added.
;
;     STEP - (factor * 512) - 512  (signed number)
; eg: %0.4  ->	(1.004	* 512) - 512 = 2.048 (dec) = 0x02
; each bit is ~ 0.2%
; *****************************************

        .msg "..." ; these are just messages to display during assemble to let you know what's going on...


	;.org	0x8546
MPSHFT_OverboostFuelShutoffEnablePointFromMap_Timer:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Overboost\
    ;mptbladdr 0x0CC5
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname OverboostFuelShutoffEnablePointFromMap_Timer
    ;mptblcname MPSHFT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc If_MAP_+_BARO_exceeds_MPSHOF,_wait_SHFDLT,_then_kill_engine_for_TRNTM._Overboost_-_$ff_to_disable
    ;mpmapaxis y
    .byte 0x95                       ;Point 1

	;.org	0x8547
MPSHFA_OverboostFuelShutoffEnablePointFromMap_Absolute:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Overboost\
    ;mptbladdr 0x0CD3
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname OverboostFuelShutoffEnablePointFromMap_Absolute
    ;mptblcname MPSHFA
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc If_MAP_+_BARO_exceeds_MPSHOF,_wait_SHFDLT,_then_kill_engine_for_TRNTM._Overboost_-_$ff_to_disable
    ;mpmapaxis y
    .byte 0x35                       ;Point 1

	;.org	0x8548
TRNTIM_OverboostFuelShutoffDuration:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Overboost\
    ;mptbladdr 0x0CE1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname OverboostFuelShutoffDuration
    ;mptblcname TRNTIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 2.8 Sec
    ;mptbldesc Overboost_shutoff_duration_-_$ff_to_disable_-_stock_$5a
    .byte 0xFF                       ;Point 1

	;.org	0x8549
LMPSHF_OverboostFuelShutoffDisablePointFromMap_Limp:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Overboost\
    ;mptbladdr 0x0CEE
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname OverboostFuelShutoffDisablePointFromMap_Limp
    ;mptblcname LMPSHF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Overboost_Shutoff_when_Wastegate_problem_has_been_detected_(should_not_disable_this)
    ;mpmapaxis y
    .byte 0x73                       ;Point 1

	;.org	0x854a
REVLMT_MapLimpinAndThrAbove25PercentLower1850:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0CFC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MapLimpinAndThrAbove25PercentLower1850
    ;mptblcname REVLMT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Fuel_Off_RPM_for_bad_MAP
    .byte 0x3A                       ;Point 1

	;.org	0x854b
REVLMT2_MapLimpinAndThrAbove25PercentUpper2000:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D09
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MapLimpinAndThrAbove25PercentUpper2000
    ;mptblcname REVLMT2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Fuel_On_RPM_for_bad_MAP
    .byte 0x3E                       ;Point 1

	;.org	0x854c
REVLMT3_MapAbove75PctAndIdleSwitchClosed2000:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D16
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MapAbove75PctAndIdleSwitchClosed2000
    ;mptblcname REVLMT3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x3E                       ;Point 1

	;.org	0x854d
REVLMT4_MapAbove75PctAndThrLimpin2000:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D23
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MapAbove75PctAndThrLimpin2000
    ;mptblcname REVLMT4
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x5E                       ;Point 1

	;.org	0x854e
REVLMT5_RPMLimiterNormalOnRPM:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Rev_Limiter\
    ;mptbladdr 0x0D30
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RPMLimiterNormalOnRPM
    ;mptblcname REVLMT5
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0xC1                       ;Point 1

	;.org	0x854f
REVLMT6_RPMLimiterNormalOffRPM:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Rev_Limiter\
    ;mptbladdr 0x0D3D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RPMLimiterNormalOffRPM
    ;mptblcname REVLMT6
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0xD0                       ;Point 1

	;.org	0x8550
THRTHR_25PctThrValueFromShutoff:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D4A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname 25PctThrValueFromShutoff
    ;mptblcname THRTHR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x21                       ;Point 1

	;.org	0x8551
RVLSPD_CarSpeedForRevLimitWithTBOff:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D57
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CarSpeedForRevLimitWithTBOff
    ;mptblcname RVLSPD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 128 mph
    ;mptbldesc Detailed_Description
    .byte 0x14                       ;Point 1

	;.org	0x8552
DFRPM1_2050RPM_DecelFuelShutoffTurnonLimit:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D64
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname 2050RPM_DecelFuelShutoffTurnonLimit
    ;mptblcname DFRPM1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x2C                       ;Point 1

	;.org	0x8553
DFRPM2_2550RPM_DecelFuelShutoffUpperRpmLimit:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D71
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname 2550RPM_DecelFuelShutoffUpperRpmLimit
    ;mptblcname DFRPM2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x32                       ;Point 1

	;.org	0x8554
DFS20M_20MPHDecelFuelShutoffSpeedLimitOFF:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D7E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname 20MPHDecelFuelShutoffSpeedLimitOFF
    ;mptblcname DFS20M
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x14                       ;Point 1

	;.org	0x8555
DFS20L_20MPHDecelFuelShutoffSpeedLimitON:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D8B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname 20MPHDecelFuelShutoffSpeedLimitON
    ;mptblcname DFS20L
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x10                       ;Point 1

	;.org	0x8556
DFSTMH_60DegCDecelFuelShutoffTempLimitOff:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0D98
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname 60DegCDecelFuelShutoffTempLimitOff
    ;mptblcname DFSTMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xCD                       ;Point 1

	;.org	0x8557
DFSTML_60DegCDecelFuelShutoffTempLimitON:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0DA5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname 60DegCDecelFuelShutoffTempLimitOn
    ;mptblcname DFSTML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xCA                       ;Point 1

	;.org	0x8558
DFSTMRH_3minuteDecelFuelShutoffTimeLimitOFF:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0DB2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname 3minuteDecelFuelShutoffTimeLimitOFF
    ;mptblcname DFSTMRH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0B                       ;Point 1

	;.org	0x8559
DFSMPH_MAPDecelFuelShutoffTimeLimitOFF:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0DBF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MAPDecelFuelShutoffTimeLimitOFF
    ;mptblcname DFSMPH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x24                       ;Point 1

	;.org	0x855a
DFSMPL_MAPDecelFuelShutoffTimeLimitON:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0DCC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MAPDecelFuelShutoffTimeLimitON
    ;mptblcname DFSMPL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x27                       ;Point 1

	;.org	0x855b
L855C_L855c:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x0DD9
    ;mptbltype 9
    ;mpsubtype n
    ;mptbllname L855C_L855c
    ;mptblcname L855C
    ;mpxaxis in_desc 11 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x05                       ;Point 1
    .byte 0x2F                       ;Point 2
    .byte 0x12                       ;Point 3
    .byte 0x1F                       ;Point 4
    .byte 0x23                       ;Point 5
    .byte 0x1B                       ;Point 6
    .byte 0x11                       ;Point 7
    .byte 0x16                       ;Point 8
    .byte 0x32                       ;Point 9
    .byte 0x11                       ;Point 10
    .byte 0x21                       ;Point 11

	;.org	0x8566
SPDLMH_SpeedLimitFuelShutoff254mph:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Speed_Limiter\
    ;mptbladdr 0x0DF0
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SpeedLimitFuelShutoff254mph
    ;mptblcname SPDLMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 255 MPH
    ;mptbldesc Detailed_Description
    .byte 0xFA                       ;Point 1

	;.org	0x8567
SPDLML_SpeedLimitFuelShutoffRestore253mph:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Speed_Limiter\
    ;mptbladdr 0x0DFD
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SpeedLimitFuelShutoffRestore253mph
    ;mptblcname SPDLML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFA                       ;Point 1

	;.org	0x8568
SPDRPM_EngineSpeedHighLimitToEnableOverspeed:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0E0A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EngineSpeedHighLimitToEnableOverspeed
    ;mptblcname SPDRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xD5                       ;Point 1

	;.org	0x8569
SPDRPM2_EngineSpeedLowLimitToDisableOverspeed:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x0E17
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EngineSpeedLowLimitToDisableOverspeed
    ;mptblcname SPDRPM2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xD1                       ;Point 1

	;.org	0x856a
AISTRT_AisStartupPosition_FromTemp:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E24
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AisStartupPosition_FromTemp
    ;mptblcname AISTRT
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis AIS_Open 0 255 steps
    ;mptbldesc AIS_motor_startup_position_from_engine_temp
    .byte 0x03                       ;Number of points in table
    .byte 0x6E, 0x99, 0xFC, 0x33     ;Point 1
    .byte 0x7D, 0x60, 0xFF, 0x44     ;Point 2
    .byte 0xDB, 0x1B                 ;Point 3

	;.org	0x8581
RPMDEF_RPMDefaultForIdleControl:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E34
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RPMDefaultForIdleControl
    ;mptblcname RPMDEF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0xA0                       ;Point 1

	;.org	0x8582
RPMTHS_RPMThresholdForIdleControl:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E41
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RPMThresholdForIdleControl
    ;mptblcname RPMTHS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x0D                       ;Point 1

	;.org	0x8583
TIMED2_AISDecelBaseAirflowCurveOffset2:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E4E
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname DecelAisBaseAirflowCurveOffset_FromTime2
    ;mptblcname TIMED2
    ;mpxaxis in_desc 0 255 scale
    ;mpyaxis Time 0 720 sec
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x16, 0x0D, 0xF9, 0x80     ;Point 1
    .byte 0x18, 0x00                 ;Point 2

	;.org	0x858e
AISDLY_DelayFromStartRunThatAisFeedbackDisabled:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E5D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DelayFromStartRunThatAisFeedbackDisabled
    ;mptblcname AISDLY
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 720 sec
    ;mptbldesc Delay_from_Start/Run_transition_that_AIS_feedback_is_disabled_in_11msec_units
    .byte 0x5D                       ;Point 1

	;.org	0x858f
AISPN_IdleSpeedParkNeutral_FromTemp:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E6A
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname IdleSpeedParkNeutral_FromTemp
    ;mptblcname AISPN
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis RPM 0 2048 rpm
    ;mptbldesc Idle_Speed_From_Temp_in_park/neutral_or_manual_trans
    .byte 0x02                       ;Number of points in table
    .byte 0x7F, 0xA3, 0xFF, 0x5C     ;Point 1
    .byte 0xBC, 0x7C                 ;Point 2

	;.org	0x859a
AISCLD_IdleSpeedDrive_FromTemp:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E79
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname IdleSpeedDrive_FromTemp
    ;mptblcname AISCLD
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis RPM 0 2048 rpm
    ;mptbldesc Idle_Speed_From_temp_in_Drive,_auto_trans_only
    .byte 0x02                       ;Number of points in table
    .byte 0x7F, 0xAF, 0xFF, 0x41     ;Point 1
    .byte 0xC2, 0x7D                 ;Point 2

	;.org	0x85a5
CLDPOS_AisColdPosition_FromTemp:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E88
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AisColdPosition_FromTemp
    ;mptblcname CLDPOS
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis AIS_Open 0 2048 steps
    ;mptbldesc Cold_OffIdle_AIS_Positioning,_Increases_instantly,_decreases_after_DLYOFI
    .byte 0x06                       ;Number of points in table
    .byte 0x63, 0x77, 0xFC, 0x74     ;Point 1
    .byte 0x6E, 0x50, 0xFE, 0xD3     ;Point 2
    .byte 0x7F, 0x3C, 0xFE, 0xE2     ;Point 3
    .byte 0x90, 0x29, 0xFF, 0x80     ;Point 4
    .byte 0xA6, 0x1E, 0xFF, 0x57     ;Point 5
    .byte 0xD2, 0x01                 ;Point 6

	;.org	0x85bc
RPMPOS_AisPosition_FromRpm:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0E9B
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AisPosition_FromRpm
    ;mptblcname RPMPOS
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc AIS_Position_from_RPMs
    .byte 0x04                       ;Number of points in table
    .byte 0x21, 0x00, 0x00, 0x1C     ;Point 1
    .byte 0x46, 0x04, 0x00, 0x00     ;Point 2
    .byte 0x64, 0x04, 0x00, 0x52     ;Point 3
    .byte 0x7D, 0x0C                 ;Point 4

	;.org	0x85cb
THRPOS_AisPosition_FromThrottle:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0EAC
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AisPosition_FromThrottle
    ;mptblcname THRPOS
    ;mpxaxis TPS 0 5 Volts
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc AIS_Position_from_throttle
    .byte 0x02                       ;Number of points in table
    .byte 0x03, 0x00, 0x00, 0xAB     ;Point 1
    .byte 0x0F, 0x08                 ;Point 2

	;.org	0x85da
ACCTBL_ACOffIdleDelta_FromSpeed:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0EBB
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname ACOffIdleDelta_FromSpeed
    ;mptblcname ACCTBL
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x05                       ;Number of points in table
    .byte 0x1E, 0x19, 0x00, 0x9A     ;Point 1
    .byte 0x32, 0x25, 0x00, 0x40     ;Point 2
    .byte 0x46, 0x2A, 0xFF, 0x9A     ;Point 3
    .byte 0x5A, 0x22, 0x00, 0x13     ;Point 4
    .byte 0x82, 0x25                 ;Point 5

	;.org	0x85ed
ACPOS_ACPositionWhenTempToCold:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0ECD
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ACPositionWhenTempToCold
    ;mptblcname ACPOS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc AIS:_AC_clutch_position_when_temp_to_cold
    .byte 0x24                       ;Point 1

	;.org	0x85ee
ACTMP_Use_ACCTBL_WhenTempAboveThisElseUse_ACPOS:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0EDA
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Use_ACCTBL_WhenTempAboveThisElseUse_ACPOS
    ;mptblcname ACTMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x7F                       ;Point 1

	;.org	0x85ef
DLYOF1_UpdateRateOffIdleWhenAisClosing:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0EE7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UpdateRateOffIdleWhenAisClosing
    ;mptblcname DLYOF1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x07                       ;Point 1

	;.org	0x85f0
ADDAIS_AISAddedFromTimeEngRunning:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0EF4
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AISAddedFromTimeEngRunning
    ;mptblcname ADDAIS
    ;mpxaxis TimeEngRun 0 2.8 sec
    ;mpyaxis Factor 0 1 scale
    ;mptbldesc Description
    .byte 0x02                       ;Number of points in table
    .byte 0x07, 0x08, 0xFF, 0x88     ;Point 1
    .byte 0x18, 0x00                 ;Point 2

	;.org	0x8603
BARAIS_AISBaroCompensation:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0F03
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname BaroCompensation_FromBaro
    ;mptblcname BARAIS
    ;mpxaxis Baro -14.7 14.7 psi
    ;mpyaxis Factor 0 1 scale
    ;mptbldesc Barometric_compensation_factor_for_AIS_control
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x5E, 0x26, 0xFC, 0x8C     ;Point 1
    .byte 0x69, 0x00                 ;Point 2

	;.org	0x8612
BRKRPM_BrakeOverrideForAis_FromDeltaThrottle:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0F13
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname BrakeOverrideForAis_FromDeltaThrottle
    ;mptblcname BRKRPM
    ;mpxaxis in_desc 0 255 scale
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0xD0                 ;Point 1

	;.org	0x8621
FWDAIS_ForwardAisSteps_NoSlope:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0F21
    ;mptbltype 12
    ;mpsubtype n
    ;mptbllname ForwardAisSteps_NoSlope
    ;mptblcname FWDAIS
    ;mpxaxis in_desc 0 255 scale
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x06                       ;Number of points in table
    .byte 0x0F, 0x00                 ;Point 1
    .byte 0x14, 0x01                 ;Point 2
    .byte 0x28, 0x02                 ;Point 3
    .byte 0x3C, 0x04                 ;Point 4
    .byte 0x50, 0x05                 ;Point 5
    .byte 0x64, 0x06                 ;Point 6

	;.org	0x8630
REVAIS_ReverseAisSteps_NoSlope:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x0F34
    ;mptbltype 12
    ;mpsubtype n
    ;mptbllname ReverseAisSteps_NoSlope
    ;mptblcname REVAIS
    ;mpxaxis in_desc 0 255 scale
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Number of points in table
    .byte 0x0F, 0x00                 ;Point 1
    .byte 0x14, 0xFF                 ;Point 2
    .byte 0x28, 0xFE                 ;Point 3
    .byte 0x50, 0xFC                 ;Point 4

	;.org	0x863f
TIMEDC_AISDecelBaseAirflowCurveOffset:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0F45
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname DecelAisBaseAirflowCurveOffset_FromTime
    ;mptblcname TIMEDC
    ;mpxaxis in_desc 0 255 scale
    ;mpyaxis Time 0 720 sec
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x16, 0x08, 0xFC, 0x00     ;Point 1
    .byte 0x18, 0x00                 ;Point 2

	;.org	0x864e
TEMPDC_AISDecel_FromTemp:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0F54
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname DecelAis_FromTemp
    ;mptblcname TEMPDC
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x58, 0x28, 0xFF, 0xAA     ;Point 1
    .byte 0xCF, 0x00                 ;Point 2

	;.org	0x8669
DAISOP_DecelAisOpenStepsFromNeg_FromDeltaMap:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0F63
    ;mptbltype 2
    ;mpsubtype 1
    ;mptbllname DecelAisOpenStepsFromNeg_FromDeltaMap
    ;mptblcname DAISOP
    ;mpxaxis DeltaMAP 0 29.4 psi
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Decel_AIS_open_steps_from_-Delta_MAP
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x01, 0x00, 0x00, 0xBA     ;Point 1
    .byte 0x0C, 0x08                 ;Point 2

	;.org	0x8678
DAISCL_DecelAisOpenStepsFromPos_FromDeltaMap:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0F73
    ;mptbltype 2
    ;mpsubtype 1
    ;mptbllname DecelAisOpenStepsFromPos_FromDeltaMap
    ;mptblcname DAISCL
    ;mpxaxis DeltaMAP 0 29.4 psi
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Decel_AIS_open_steps_from_+Delta_MAP
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x02, 0x00, 0xFF, 0xAB     ;Point 1
    .byte 0x11, 0xFB                 ;Point 2

	;.org	0x8687
MAPFLR_AISAdditionToControlMap_FromRpm:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0F83
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AdditionToControlMap_FromRpm
    ;mptblcname MAPFLR
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc AIS_Decel_Addition_to_control_MAP_vs._RPM
    .byte 0x02                       ;Number of points in table
    .byte 0x26, 0x00, 0x00, 0x55     ;Point 1
    .byte 0x2F, 0x03                 ;Point 2

	;.org	0x869a
MPTEMP_TempTermForMapOffset_FromTemp:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0F92
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname TempTermForMapOffset_FromTemp
    ;mptblcname MPTEMP
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Factor 0 1 Factor
    ;mptbldesc AIS_Decel_Temperature_Term
    .byte 0x02                       ;Number of points in table
    .byte 0x90, 0x00, 0x04, 0xA3     ;Point 1
    .byte 0xC7, 0xFF                 ;Point 2

	;.org	0x86a9
BARFLR_OffsetCorrectionTo_MAPFLR_FromBaro:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0FA1
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname OffsetCorrectionTo_MAPFLR_FromBaro
    ;mptblcname BARFLR
    ;mpxaxis Baro -14.7 14.7 psi
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc AIS_Decel_Offset_correction_due_to_baro_effect
    ;mpmapaxis x
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x00                 ;Point 1

	;.org	0x86b8
DCLRFQ_TimeBetweenAisPulsesForDecelAis:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0FB0
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TimeBetweenAisPulsesForDecelAis
    ;mptblcname DCLRFQ
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 2.8 Sec
    ;mptbldesc Detailed_Description
    .byte 0x40                       ;Point 1

	;.org	0x86b9
DATHOT_EngineTempToStartCalibratingDacal:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0FBD
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EngineTempToStartCalibratingDacal
    ;mptblcname DATHOT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 Deg
    ;mptbldesc Detailed_Description
    .byte 0xCD                       ;Point 1

	;.org	0x86ba
DADRPM_DeltaRpmFromIdleSpeedForDacalUpdate:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0FCA
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaRpmFromIdleSpeedForDacalUpdate
    ;mptblcname DADRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

	;.org	0x86bb
DAACF_ACFactorDeltaFromBase:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0FD7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ACFactorDeltaFromBase
    ;mptblcname DAACF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0F                       ;Point 1

	;.org	0x86bc
DANOM_Base_nominalCal:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0FE4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Base_nominalCal
    ;mptblcname DANOM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x12                       ;Point 1

	;.org	0x86bd
DCALTM_DacalInhibitTimeAfterStartup:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0FF1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DacalInhibitTimeAfterStartup
    ;mptblcname DCALTM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x15                       ;Point 1

	;.org	0x86be
DCALRT_DacalUpdateRate01_03_07_0f_1f_3f_7f_ff:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x0FFE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DacalUpdateRate01_03_07_0f_1f_3f_7f_ff
    ;mptblcname DCALRT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x3F                       ;Point 1

	;.org	0x86bf
DCLMIN_MinLimitOnDecelAisControlledMap:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x100B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinLimitOnDecelAisControlledMap
    ;mptblcname DCLMIN
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x86c0
DCLMN2_NoAisControlIfMapAndControlMapBelowThis:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1018
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname NoAisControlIfMapAndControlMapBelowThis
    ;mptblcname DCLMN2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x14                       ;Point 1

	;.org	0x86c1
DLYTIM_AisDelayAfterThrottleClosesWhenMoving:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1026
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisDelayAfterThrottleClosesWhenMoving
    ;mptblcname DLYTIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 2.8 sec
    ;mptbldesc Decel_AIS_Delay_after_throttle_closes_when_moving
    .byte 0x95                       ;Point 1

	;.org	0x86c2
DLYTM2_AisDelayAfterThrottleClosesWhenStopped:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1033
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisDelayAfterThrottleClosesWhenStopped
    ;mptblcname DLYTIM2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 2.8 sec
    ;mptbldesc Decel_AIS_Delay_after_throttle_closes_when_stopped
    .byte 0x20                       ;Point 1

	;.org	0x86c3
DLYTM3_AisDelayAfterThrottleClosesWhenRpmAbove_DLYRPM:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1040
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisDelayAfterThrottleClosesWhenRpmAbove_DLYRPM
    ;mptblcname DLYTM3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 2.8 sec
    ;mptbldesc Decel_AIS_Delay_after_throttle_closes_when_MAP_is_below_DCLMN2
    .byte 0xD0                       ;Point 1

	;.org	0x86c4
DLYRPM_RpmTriggerForAisDelay:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x104D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RpmTriggerForAisDelay
    ;mptblcname DLYRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Decel_AIS_RPM_trigger_(third_AIS_delay)
    .byte 0x3D                       ;Point 1

	;.org	0x86c5
MPHREF_SwitchPointForDecelIdleAisControl:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x105A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SwitchPointForDecelIdleAisControl
    ;mptblcname MPHREF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 128 mph
    ;mptbldesc Switch_point_between_Decel_or_Idle_AIS_control._Note_there_is_also_a_1.5_mph_hysteresis
    .byte 0x07                       ;Point 1

	;.org	0x86c6
PNDLTN_DeltaRpmChangeToUse_DRPNK_or_PNDRK:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1067
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname DeltaRpmChangeToUse_DRPNK_or_PNDRK_A
    ;mptblcname PNDLT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x1F40                     ;Point 1

	;.org	0x86c8
PNDRK_ParkNeutralToDriveKicks_FromTemp:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1074
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname ParkNeutralToDriveKicks_FromTemp
    ;mptblcname PNDRK
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x00                 ;Point 1

	;.org	0x86d7
PNDLTP_DeltaRpmChangeToUse_DRPNK_or_PNDRK:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1082
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname DeltaRpmChangeToUse_DRPNK_or_PNDRK_B
    ;mptblcname PNDLTP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x1F40                     ;Point 1

	;.org	0x86d9
DRPNK_DriveToParkNeutralKicks_FromTemp:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x108F
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname DriveToParkNeutralKicks_FromTemp
    ;mptblcname DRPNK
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x00                 ;Point 1

	;.org	0x86e8
ACOFFK_ClosedThrottleAcOffKick:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x109D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ClosedThrottleAcOffKick
    ;mptblcname ACOFFK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x18                       ;Point 1

	;.org	0x86e9
AC2KCK_AcClutchKickOpenAfterAcEnabled:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x10AA
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AcClutchKickOpenAfterAcEnabled
    ;mptblcname AC2KCK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x86ea
ACTIME_TimeBeforeAcEnabledAndFullDeltaUsed:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x10B7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TimeBeforeAcEnabledAndFullDeltaUsed
    ;mptblcname ACTIME
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x20                       ;Point 1

	;.org	0x86eb
ACTDEF_TimeBeforeAcEnabledAndFullDeltaUsed_Default:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x10C4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TimeBeforeAcEnabledAndFullDeltaUsed_Default
    ;mptblcname ACTDEF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x2A                       ;Point 1

	;.org	0x86ec
PERKCK_AcClutchAisAdjustmentConstant:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x10D1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AcClutchAisAdjustmentConstant
    ;mptblcname PERKCK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x86ed
AC4KCK_AcClutchKickOpenBeforeAcEnabled2:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x10DE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AcClutchKickOpenBeforeAcEnabled2
    ;mptblcname AC4KCK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xF4                       ;Point 1

	;.org	0x86ee
AC3KCK_AcClutchKickOpenAfterAcEnabled2:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x10EB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AcClutchKickOpenAfterAcEnabled2
    ;mptblcname AC3KCK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFA                       ;Point 1

	;.org	0x86ef
ACTIM2_TimeBeforeAcEnabledAndFullDeltaUsed2:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x10F8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TimeBeforeAcEnabledAndFullDeltaUsed2
    ;mptblcname ACTIM2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x14                       ;Point 1

	;.org	0x86f0
OFFPER_AisInstantlyClosesWhenAcDisengages:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1105
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisInstantlyClosesWhenAcDisengages
    ;mptblcname OFFPER
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x80                       ;Point 1

	;.org	0x86f1
OFFPER2_AisInstantlyClosesWhenAcDisengages2:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1112
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisInstantlyClosesWhenAcDisengages2
    ;mptblcname OFFPER2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x80                       ;Point 1

	;.org	0x86f2
AISMPH_RollingAisMaxSpeed:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x111F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RollingAisMaxSpeed
    ;mptblcname AISMPH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x10                       ;Point 1

	;.org	0x86f3
RPMDLT_RollingAisMinRpm:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x112C
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname RollingAisMinRpm
    ;mptblcname RPMDLT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x07D0                     ;Point 1

	;.org	0x86f5
ISPDCY_RollingAisDecay:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1139
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RollingAisDecay
    ;mptblcname ISPDCY
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

	;.org	0x86f6
DECAIS_RollingAisUpdateRate_01_03_07_0f_1f_3f_7f_ff:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1146
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RollingAisUpdateRate_01_03_07_0f_1f_3f_7f_ff
    ;mptblcname DECAIS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x7F                       ;Point 1

	;.org	0x86f7
AISLMH_RollingAisHighLimit:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1153
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RollingAisHighLimit
    ;mptblcname AISLMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x20                       ;Point 1

	;.org	0x86f8
AISLML_RollingAisLowLimit:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1160
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RollingAisLowLimit
    ;mptblcname AISLML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

	;.org	0x86f9
ACDTMP_PartThrottleAcCutoutDisableTemp:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x116D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PartThrottleAcCutoutDisableTemp
    ;mptblcname ACDTMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x58                       ;Point 1

	;.org	0x86fa
ACDTHR_PartThrottleAcCutoutDisableThrottle:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x117A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PartThrottleAcCutoutDisableThrottle
    ;mptblcname ACDTHR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x1A                       ;Point 1

	;.org	0x86fb
ACDSPD_PartThrottleAcCutoutDisableSpeed:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1187
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname PartThrottleAcCutoutDisableSpeed
    ;mptblcname ACDSPD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0440                     ;Point 1

	;.org	0x86fd
ACETIM_PartThrottleAcCutoutMaxTimeActive:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x1194
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PartThrottleAcCutoutMaxTimeActive
    ;mptblcname ACETIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0C                       ;Point 1

	;.org	0x86fe
ACERPM_AllowAcClutchAboveThisRpm:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x11A1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AllowAcClutchAboveThisRpm
    ;mptblcname ACERPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x54                       ;Point 1

	;.org	0x86ff
ACESPD_AllowAcClutchAboveThisSpeed:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x11AE
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname AllowAcClutchAboveThisSpeed
    ;mptblcname ACESPD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0500                     ;Point 1

	;.org	0x8701
ACAETH_DisallowAcClutchEngageForThisTimeAfterAccelEnrich:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x11BB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DisallowAcClutchEngageForThisTimeAfterAccelEnrich
    ;mptblcname ACAETH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x2D                       ;Point 1

	;.org	0x8702
BTVAIS_MinVoltageForAis:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x11C8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinVoltageForAis
    ;mptblcname BTVAIS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x71                       ;Point 1

	;.org	0x8703
AISFRQ_AisPeriodForRpmFeedback11ms:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x11D5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisPeriodForRpmFeedback11ms
    ;mptblcname AISFRQ
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x82                       ;Point 1

	;.org	0x8704
AISHLM_AisHighLimitMaxOpenSteps:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x11E2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisHighLimitMaxOpenSteps
    ;mptblcname AISHLM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xA0                       ;Point 1

	;.org	0x8705
AISFAN_AisKickWhenFanTurnsOnClosedThrottle:
    ;mpgrp Idle\AIS_Decel\
    ;mptbladdr 0x11EF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisKickWhenFanTurnsOnClosedThrottle
    ;mptblcname AISFAN
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0A                       ;Point 1

	;.org	0x8706
CALPOS_PositionAisMotorIsAtIdle:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x11FC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PositionAisMotorIsAtIdle
    ;mptblcname CALPOS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc AIS:_Position_electronics_thinks_motor_is_(at_idle)
    .byte 0x1A                       ;Point 1

	;.org	0x8707
CALRAT_AisAdjustRate:
    ;mpgrp Idle\AIS_Control\
    ;mptbladdr 0x1209
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AisAdjustRate
    ;mptblcname CALRAT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc AIS_update_rate_when_calibrating_-_rate=(CALRAT+1)*11ms_(can_be_0,1,3,7,f,1f,3f,7f,ff)
    .byte 0x07                       ;Point 1

        .msg "..." ; these are just messages to display during assemble to let you know what's going on...

BSTSWS_HighBoostSwitchSelect:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x1217
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname HighBoostSwitchSelect
    ;mptblcname BSTSWS
    ;mpxaxis IN 0 255 X
    ;mpyaxis OUT 0 255 Y
    ;mptbldesc Switch_that_will_activate_high_boost_mode._If_no_switch_is_selected,_then_theboost_is_not_selectable,_and_the_Low_Boost_curve_needs_to_be_setup_as_the_high_boost_curve.
    ;mpchoices Park/Neutral_Switch  Speed_Control_Resume_(Momentary)  Brake_Switch  Speed_Control_On/Off  Uknown  Speed_Control_Set_(Momentary)  A/C_Clutch_Input(Do_Not_Use)  Uknown
    .byte 0x01                       ;Point 1
;        sw1_bit7           	        = $%10000000	;
;        sw1_ACclutch       	        = $%01000000	; A/C Clutch input
;        sw1_CruiseSet              	= $%00100000	; Cruise Set
;        sw1_bit4                       = $%00010000	;
;        sw1_CruiseOnOff         	= $%00001000	; Cruise On/Off
;        sw1_Brake          		= $%00000100	; Brake Switch
;        sw1_CruiseResume   		= $%00000010	; Cruise Resume
;        sw1_PNswitch                   = $%00000001	; Park/Neutral switch

	;.org	0x8708
WSGRPM_AllowedBoost_FromRpm:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x122D
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AllowedBoost_FromRpm
    ;mptblcname WSGRPM
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Boost_Allowed_from_RPMs._Boost_is_defined_as_MAP_reading_above_Baro
    ;mpmapaxis y
    .byte 0x04                       ;Number of points in table
    .byte 0x4B, 0x5D, 0x00, 0x85     ;Point 1
    .byte 0x64, 0x6A, 0x00, 0x00     ;Point 2
    .byte 0xC8, 0x6A, 0xFD, 0xD5     ;Point 3
    .byte 0xCE, 0x5D                 ;Point 4

	;.org	0x871b
WSGRPA_AllowedBoostKnock_FromRpm:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x123F
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AllowedBoostKnock_FromRpm
    ;mptblcname WSGRPA
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Boost_Allowed_from_RPMs_while_knocking._Boost_is_defined_as_MAP_reading_above_Baro
    ;mpmapaxis y
    .byte 0x04                       ;Number of points in table
    .byte 0x6A, 0x3D, 0x01, 0x20     ;Point 1
    .byte 0x8A, 0x61, 0x00, 0x00     ;Point 2
    .byte 0xA8, 0x61, 0xFF, 0x00     ;Point 3
    .byte 0xBA, 0x4F                 ;Point 4

LOWBST_AllowedBoostLo:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x1250
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AllowedBoostLo
    ;mptblcname LOWBST
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Low_boost_setting._Boost_is_defined_as_MAP_reading_above_Baro
    ;mpmapaxis y
    .byte 0x57                       ;Point 1

	;.org	0x872e
WSGTIM_AllowedBoost_FromTime:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x125E
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AllowedBoost_FromTime
    ;mptblcname WSGTIM
    ;mpxaxis Time 0 0.72 Sec
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Boost_Allowed_from_time_in_boost._Boost_is_defined_as_MAP_reading_above_Baro
    ;mpmapaxis y
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x6A                 ;Point 1

	;.org	0x8739
WSGCLT_AllowedBoost_FromTemp:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x126D
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AllowedBoost_FromTemp
    ;mptblcname WSGCLT
    ;mpxaxis Temp -200 260 degrees
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Boost_Allowed_from_Engine_Temp._Boost_is_defined_as_MAP_reading_above_Baro
    ;mpmapaxis y
    .byte 0x04                       ;Number of points in table
    .byte 0xB3, 0x5B, 0x01, 0x00     ;Point 1
    .byte 0xC2, 0x6A, 0x00, 0x00     ;Point 2
    .byte 0xEE, 0x6A, 0xF8, 0x80     ;Point 3
    .byte 0xF0, 0x5B                 ;Point 4

	;.org	0x874c
WSGCHG_AllowedBoost_FromChargeTemp:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x127F
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AllowedBoost_FromChargeTemp
    ;mptblcname WSGCHG
    ;mpxaxis charge_temp -200 260 degrees
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Boost_Allowed_from_Charge_Temp._Boost_is_defined_as_MAP_reading_above_Baro._Charge_Temp_numbers_are_approximate_only
    ;mpmapaxis y
    .byte 0x02                       ;Number of points in table
    .byte 0xF8, 0x6A, 0xFC, 0x40     ;Point 1
    .byte 0xFC, 0x5B                 ;Point 2

	;.org	0x875b
MXSBST_AllowedBoost_FromSpeed:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x128F
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AllowedBoostForAutomatics_FromSpeed
    ;mptblcname MXSBST
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Boost_Allowed_from_Speed_to_protect_automatic_transmissions.
    ;mpmapaxis y
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x6A                 ;Point 1

	;.org	0x876e
WSGPRT_AllowedBoostPartThrottle_FromThrottle:
    ;mpgrp Boost_Control\Target_Lookup\
    ;mptbladdr 0x129E
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AllowedBoostPartThrottle_FromThrottle
    ;mptblcname WSGPRT
    ;mpxaxis TPS 0 5 volts
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Boost_Allowed_from_Throttle_at_Part_Throttle._Boost_is_defined_as_MAP_reading_above_Baro
    ;mpmapaxis y
    .byte 0x04                       ;Number of points in table
    .byte 0x33, 0x22, 0x01, 0xA5     ;Point 1
    .byte 0x4F, 0x50, 0x00, 0xAB     ;Point 2
    .byte 0x70, 0x66, 0x00, 0x31     ;Point 3
    .byte 0x85, 0x6A                 ;Point 4

	;.org	0x877d
DCWOT_FullThrottleWastegateDutyCycle_C8is100Percent_FromMap:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x12B0
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname FullThrottleWastegateDutyCycle_C8is100Percent_FromMap
    ;mptblcname DCWOT
    ;mpxaxis TargetBoost 0 29.4 psi
    ;mpyaxis Duty_Cycle 0 128 percent
    ;mptbldesc WOT_WG_Duty_Cycle
    ;mpmapaxis x
    .byte 0x04                       ;Number of points in table
    .byte 0x46, 0x40, 0x01, 0x8E     ;Point 1
    .byte 0x4F, 0x4E, 0x01, 0x39     ;Point 2
    .byte 0x61, 0x64, 0x00, 0xE4     ;Point 3
    .byte 0x6A, 0x6C                 ;Point 4

	;.org	0x8798
DCWADJ_FullThrottleWastegateDutyCycleAdjustment_FromRpm:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x12C2
    ;mptbltype 2
    ;mpsubtype n
    ;mptbllname FullThrottleWastegateDutyCycleAdjustment_FromRpm
    ;mptblcname DCWADJ
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis DC_Adjust -64 64 percent
    ;mptbldesc WOT_Duty_Cycle_Adjustment
    .byte 0x04                       ;Number of points in table
    .byte 0x4B, 0x11, 0xFF, 0x74     ;Point 1
    .byte 0x6A, 0x00, 0x00, 0x00     ;Point 2
    .byte 0x8D, 0x00, 0x00, 0x66     ;Point 3
    .byte 0x9C, 0x06                 ;Point 4

        .msg "..." ; these are just messages to display during assemble to let you know what's going on...

; DCWBST_FullThrottleWastegateDutyCycleAdjustment_FromBoostTarget:
; ; this is a Turbonator boost Control added table, not a stock table
;        chem2 group "Boost - WG Control"
;        .chem 0 1 FullThrottleWastegateDutyCycleAdjustment_FromBoostTarget DeltaMAP 0 29.4 psi DC_Adjust 0 128 percent DCWBST WOT_WG_Duty_Cycle_added_vs_delta_to_boost_target.
;        chem2 table DCWBST simple use "DeltaMAP" 0 29.4 "psi" use "DC Adjust" 0 128 "percent" "WOT WG Duty Cycle added vs delta to boost target."
;        .byte   0x06                              ; number of points in table
;        .byte   0x42,  0x00,  0x05,  0xB6         ; point 1
;        .byte   0x57,  0x78,  0x01,  0x29         ; point 2
;        .byte   0x82,  0xAA,  0x00,  0xAE         ; point 3
;        .byte   0xAE,  0xC8,  0x00,  0x00         ; point 4
;        .byte   0xC6,  0xC8,  0x00,  0x00         ; point 5
;        .byte   0xDE,  0xC8                       ; point 6

	;.org	0x87b7
MAPPT2_WastegateDutyCycleMapSwitchPoint2:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x12E2
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname WastegateDutyCycleMapSwitchPoint2
    ;mptblcname MAPPT2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Wastegate_Duty_Cycle_Adjustment_Map_Switch_Point
    ;mpmapaxis y
    .byte 0x1F                       ;Point 1

	;.org	0x87b8
RPMBST_MinimumRpmToTrackBoostCreep:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x12F0
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinimumRpmToTrackBoostCreep
    ;mptblcname RPMBST
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Min_RPM_to_increment_the_boost_error_timer.
    .byte 0x4C                       ;Point 1

	;.org	0x87b9
KDCINC_WastegateDutyCycleIncreaseStepWhenKnocking:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x12FD
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleIncreaseStepWhenKnocking
    ;mptblcname KDCINC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

	;.org	0x87ba
KDCMAX_WastegateDutyCycleIncreaseMaxWhenKnocking:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x130A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleIncreaseMaxWhenKnocking
    ;mptblcname KDCMAX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x14                       ;Point 1

	;.org	0x87bb
KDCMIN_WastegateDutyCycleIncreaseMinWhenKnocking:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1317
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleIncreaseMinWhenKnocking
    ;mptblcname KDCMIN
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

	;.org	0x87bc
DECTIM_TimeScaleFor_DCDECK:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1324
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TimeScaleFor_DCDECK
    ;mptblcname DECTIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x07                       ;Point 1

	;.org	0x87bd
DCDECK_WastegateDutyCycleDecrementWhenSparkStillDerated:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1331
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleDecrementWhenSparkStillDerated
    ;mptblcname DCDECK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

	;.org	0x87be
MPDEL1_IncCounterWhenDeltaMapBelowThis:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x133E
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname IncCounterWhenDeltaMapBelowThis
    ;mptblcname MPDEL1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x07                       ;Point 1

	;.org	0x87bf
MPFLOR_StopAdaptiveWGWhenDeltaMapIsLessThanThis:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x134C
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname StopAdaptiveWhenDeltaMapIsLessThanThis
    ;mptblcname MPFLOR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x02                       ;Point 1

	;.org	0x87c1
DECPT_AdaptiveDecAfterThisTime:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x135A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveDecAfterThisTime
    ;mptblcname DECPT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Number_of_BoostErrTimer_counts_before_WG_Duty_Cycle_is_decremented._Used_when_boost_is_above_target.
    .byte 0x14                       ;Point 1

	;.org	0x87c2
DECLIM_LowerLimitOnWastegateDutyCycleCorrection:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1367
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LowerLimitOnWastegateDutyCycleCorrection
    ;mptblcname DECLIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x18                       ;Point 1

	;.org	0x87c3
WGDCOF_WastegateDutyCycleOffset:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1374
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleOffset
    ;mptblcname WGDCOF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DutyCycle 0 128 Percent
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x87c4
MPROOF_StopAdaptiveWGWhenMapIsThisCloseToBoostTarget:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1381
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname StopAdaptiveWGWhenMapIsThisCloseToBoostTarget
    ;mptblcname MPROOF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x01                       ;Point 1

	;.org	0x87c5
MPDEL2_IncCounterWhenDeltaMapBelowThis2:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x138F
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname IncCounterWhenDeltaMapBelowThis2
    ;mptblcname MPDEL2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x03                       ;Point 1

	;.org	0x87c6
DECPTX_AdaptiveDecAfterThisTimeX:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x139D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveDecAfterThisTimeX
    ;mptblcname DECPTX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x1F                       ;Point 1

	;.org	0x87c7
WGMXER_MaxWGDCForBoostErrorCorrection:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x13AA
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MaxWGDCForBoostErrorCorrection
    ;mptblcname WGMXER
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis WGDC 0 128 percent
    ;mptbldesc Detailed_Description
    .byte 0xBC                       ;Point 1

	;.org	0x87c8
DCRPML_NoWastegateDutyCycleCorrectionBelowThisRpm:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x13B7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NoWastegateDutyCycleCorrectionBelowThisRpm
    ;mptblcname DCRPML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x3B                       ;Point 1

	;.org	0x87c9
DCRPMH_NoWastegateDutyCycleCorrectionAboveThisRpm:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x13C4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NoWastegateDutyCycleCorrectionAboveThisRpm
    ;mptblcname DCRPMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0xC8                       ;Point 1

	;.org	0x87ca
TPSLIM_UpdateAdaptiveWGTPSUpperLimit:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x13D1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UpdateAdaptiveWGTPSUpperLimit
    ;mptblcname TPSLIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis TPS_Volts 0 5 volts
    ;mptbldesc Detailed_Description
    .byte 0x66                       ;Point 1

	;.org	0x87cb
DCCTSL_NoWastegateDutyCycleCorrectionBelowThisCoolantTemp:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x13DE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NoWastegateDutyCycleCorrectionBelowThisCoolantTemp
    ;mptblcname DCCTSL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis CoolantTemp -200 260 DegF
    ;mptbldesc Detailed_Description
    .byte 0xB1                       ;Point 1

	;.org	0x87cc
MAPPT_WastegateDutyCycleMapSwitchPoint:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x13EB
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname WastegateDutyCycleMapSwitchPoint
    ;mptblcname MAPPT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Wastegate_Duty_Cycle_Adjustment_boost_switch_point.
    ;mpmapaxis y
    .byte 0x5C                       ;Point 1

	;.org	0x87cd
DCRPM1_WastegateDutyCycleRpmBoundary1:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x13F9
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleRpmBoundary1
    ;mptblcname DCRPM1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x4B                       ;Point 1

	;.org	0x87ce
DCRPM2_WastegateDutyCycleRpmBoundary2:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1406
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleRpmBoundary2
    ;mptblcname DCRPM2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x58                       ;Point 1

	;.org	0x87cf
DCRPM3_WastegateDutyCycleRpmBoundary3:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1413
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleRpmBoundary3
    ;mptblcname DCRPM3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x67                       ;Point 1

	;.org	0x87d0
VNTALT_VNTHighAltitudeBoostSetpointBase:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1420
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname VNTHighAltitudeBoostSetpointBase
    ;mptblcname VNTALT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x6A                       ;Point 1

	;.org	0x87d1
VNTTMP_VNTDecelEngineTempToDetermineVanePos:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x142E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTDecelEngineTempToDetermineVanePos
    ;mptblcname VNTTMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis CoolantTemp -200 260 DegF
    ;mptbldesc Detailed_Description
    .byte 0xA6                       ;Point 1

	;.org	0x87d2
VNTMAX_VNTMaxActuatorDutyCycle:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x143B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTMaxActuatorDutyCycle
    ;mptblcname VNTMAX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis VNTDC 0 128 percent
    ;mptbldesc Detailed_Description
    .byte 0xC8                       ;Point 1

	;.org	0x87d3
VNTRPM_RPMThresholdForVNTControl:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1448
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RPMThresholdForVNTControl
    ;mptblcname VNTRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x32                       ;Point 1

	;.org	0x87d4
VNTMIN_VNTMinActuatorDutyCycle:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1455
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTMinActuatorDutyCycle
    ;mptblcname VNTMIN
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis VNTDC 0 128 percent
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x87d5
DECPTV_AdaptiveDecAfterThisTimeVNT:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1462
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveDecAfterThisTimeVNT
    ;mptblcname DECPTV
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis BstErrTime 0 2.8 sec
    ;mptbldesc Detailed_Description
    .byte 0x1F                       ;Point 1

	;.org	0x87d6
INCPTV_AdaptiveIncAfterThisTimeVNT:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x146F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveIncAfterThisTimeVNT
    ;mptblcname INCPTV
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis BstErrTime 0 2.8 sec
    ;mptbldesc Detailed_Description
    .byte 0x2F                       ;Point 1

	;.org	0x87d7
DCRPMLV_NoWastegateDutyCycleCorrectionBelowThisRpmVNT:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x147C
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NoWastegateDutyCycleCorrectionBelowThisRpmVNT
    ;mptblcname DCRPMLV
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x51                       ;Point 1

	;.org	0x87d8
DCRPM4_WastegateDutyCycleRpmBoundary4:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1489
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleRpmBoundary4
    ;mptblcname DCRPM4
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x8A                       ;Point 1

	;.org	0x87d9
DCRPM5_WastegateDutyCycleRpmBoundary5:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x1496
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WastegateDutyCycleRpmBoundary5
    ;mptblcname DCRPM5
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0xA9                       ;Point 1

	;.org	0x87da
HABARO_VNTHighAltitudeBoostCalculationFromBaro:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x14A3
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname VNTHighAltitudeBoostCalculationFromBaro
    ;mptblcname HABARO
    ;mpxaxis Baro 0 29.4 psi
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0x54, 0x18, 0xFF, 0x0A     ;Point 1
    .byte 0x6D, 0x00                 ;Point 2

	;.org	0x87e1
HARPM_VNTHighAltitudeBoostCalculationFromRPM:
    ;mpgrp Boost_Control\WG_Control\
    ;mptbladdr 0x14B3
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname VNTHighAltitudeBoostCalculationFromRPM
    ;mptblcname HARPM
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x03                       ;Number of points in table
    .byte 0x7D, 0x00, 0x07, 0xC9     ;Point 1
    .byte 0x99, 0xDA, 0x01, 0xF3     ;Point 2
    .byte 0xAC, 0xFF                 ;Point 3

	;.org	0x87ec
BPRMIN_VNTMinimumBoostForIncrRateAdjustment:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x14C3
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname VNTMinimumBoostForIncrRateAdjustment
    ;mptblcname BPRMIN
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0xFF                       ;Point 1

	;.org	0x87ed
OBCTRL_OverboostControlPoint:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x14D1
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname OverboostControlPoint
    ;mptblcname OBCTRL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x75                       ;Point 1

	;.org	0x87ee
BPRMN2_VNTMinimumDeltaBoostForIncrRateAdjustment:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x14DF
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname VNTMinimumDeltaBoostForIncrRateAdjustment
    ;mptblcname BPRMN2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x06                       ;Point 1

	;.org	0x87ef
DBCRNG_DeltaBoostLimitNegativeForBoostCreep:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x14ED
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DeltaBoostLimitNegativeForBoostCreep
    ;mptblcname DBCRNG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x03                       ;Point 1

	;.org	0x87f0
DLTBSC_DeltaBoostSampleCounterMax:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x14FB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaBoostSampleCounterMax
    ;mptblcname DLTBSC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaBTimer 0 2.8 sec
    ;mptbldesc Detailed_Description
    .byte 0x07                       ;Point 1

	;.org	0x87f1
DECMAX_VNTWGDutyCylceMaxDecreaseFromIncrRate:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1508
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTWGDutyCylceMaxDecreaseFromIncrRate
    ;mptblcname DECMAX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xB4                       ;Point 1

	;.org	0x87f2
DBCRPS_DeltaBoostLimitPositiveForBoostCreep:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1515
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DeltaBoostLimitPositiveForBoostCreep
    ;mptblcname DBCRPS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x01                       ;Point 1

	;.org	0x87f3
INCPT_AdaptiveIncAfterThisTime:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1523
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AdaptiveIncAfterThisTime
    ;mptblcname INCPT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaBTimer 0 2.8 sec
    ;mptbldesc Detailed_Description
    .byte 0x0F                       ;Point 1

	;.org	0x87f4
WGDCON_WGDCOffsetNegatve:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1530
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WGDCOffsetNegatve
    ;mptblcname WGDCON
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis WGDC 0 128 percent
    ;mptbldesc Detailed_Description
    .byte 0x08                       ;Point 1

	;.org	0x87f5
WGDCDB_VNTWGDutyCycleDecreaseFromDeltaBoost:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x153D
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname VNTWGDutyCycleDecreaseFromDeltaBoost
    ;mptblcname WGDCDB
    ;mpxaxis DeltaBst 0 29.4 psi
    ;mpyaxis WGDCChange 0 128 percent
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x04                       ;Number of points in table
    .byte 0x05, 0x00, 0x04, 0x00     ;Point 1
    .byte 0x0A, 0x14, 0x06, 0x00     ;Point 2
    .byte 0x0F, 0x32, 0x06, 0x00     ;Point 3
    .byte 0x14, 0x50                 ;Point 4

	;.org	0x8804
VNTCNT_VNTBoostControlCounter1Init:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x154F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTBoostControlCounter1Init
    ;mptblcname VNTCNT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Counter 0 255 cnt
    ;mptbldesc Detailed_Description
    .byte 0xE3                       ;Point 1

	;.org	0x8805
VMINRP_MinimumRPMForVNTBoostControl:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x155C
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinimumRPMForVNTBoostControl
    ;mptblcname VMINRP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8806
WGDCMN_MinimumWastegateDutyCycle:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1569
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinimumWastegateDutyCycle
    ;mptblcname WGDCMN
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DutyCycle 0 128 percent
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x8807
WGDCMX_MaximumWastegateDutyCycle:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1576
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MaximumWastegateDutyCycle
    ;mptblcname WGDCMX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DutyCycle 0 128 percent
    ;mptbldesc Detailed_Description
    .byte 0xC8                       ;Point 1

	;.org	0x8808
VNTDCR_VNTDutyCycleFromRPM:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1583
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname VNTDutyCycleFromRPM
    ;mptblcname VNTDCR
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis DutyCycle 0 128 percent
    ;mptbldesc Detailed_Description
    .byte 0x03                       ;Number of points in table
    .byte 0x5D, 0x00, 0x00, 0x00     ;Point 1
    .byte 0x7D, 0x00, 0x00, 0xF8     ;Point 2
    .byte 0x9C, 0x1E                 ;Point 3
        
	;.org	0x8817
VNTDCL_MAPBelowBaroForDecelDetermination:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1593
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname MAPBelowBaroForDecelDetermination
    ;mptblcname VNTDCL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x25                       ;Point 1

	;.org	0x8818
VNTVAC_VNTActuatorDutyCycleFromVacBelowThreshold:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x15A1
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname VNTActuatorDutyCycleFromVacBelowThreshold
    ;mptblcname VNTVAC
    ;mpxaxis MAP 0 29.4 psi
    ;mpyaxis VNTDC 0 128 percent
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x02                       ;Number of points in table
    .byte 0x01, 0x00, 0x00, 0x34     ;Point 1
    .byte 0x32, 0x0A                 ;Point 2

	;.org	0x881f
WGTVAC_WastegateDutyCycleFromVacBelowThreshold:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x15B1
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname WastegateDutyCycleFromVacBelowThreshold
    ;mptblcname WGTVAC
    ;mpxaxis MAP 0 29.4 psi
    ;mpyaxis WGDC 0 128 percent
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x02                       ;Number of points in table
    .byte 0x01, 0x14, 0x01, 0x39     ;Point 1
    .byte 0x32, 0x50                 ;Point 2

	;.org	0x8826
VNTBLM_BoostLimitForNormalVNTControl:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x15C1
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname BoostLimitForNormalVNTControl
    ;mptblcname VNTBLM
    ;mpxaxis in 0 255 in
    ;mpyaxis MAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x0D                       ;Point 1

	;.org	0x8827
VNTWOT_VNTFullThrottleDutyCycle:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x15CF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTFullThrottleDutyCycle
    ;mptblcname VNTWOT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis VNTDC 0 128 percent
    ;mptbldesc Detailed_Description
    .byte 0xC8                       ;Point 1

	;.org	0x8828
VNTDC_VNTDutyCycleFromBoost:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x15DC
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname VNTDutyCycleFromBoost
    ;mptblcname VNTDC
    ;mpxaxis Boost 0 29.4 psi
    ;mpyaxis VNTDC 0 128 percent
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x02                       ;Number of points in table
    .byte 0x0D, 0x0A, 0x0A, 0x8E     ;Point 1
    .byte 0x1F, 0xC8                 ;Point 2

	;.org	0x882f
WGDCVN_WGDCFromVNTDutyCycle:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x15EC
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname WGDCFromBoost
    ;mptblcname WGDCVN
    ;mpxaxis Boost 0 29.4 psi
    ;mpyaxis VNTDC 0 128 percent
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x02                       ;Number of points in table
    .byte 0x0D, 0x50, 0x02, 0xC7     ;Point 1
    .byte 0x1F, 0x82                 ;Point 2

	;.org	0x8836
VNTDCW_VNTFullThrottleWastegateDutyCycle:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x15FC
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname VNTFullThrottleWastegateDutyCycle
    ;mptblcname VNTDCW
    ;mpxaxis Boost 0 29.4 psi
    ;mpyaxis VNTDC 0 128 percent
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x02                       ;Number of points in table
    .byte 0x04, 0x96, 0xFE, 0x85     ;Point 1
    .byte 0x1F, 0x6E                 ;Point 2

	;.org	0x883d
L883E_L883e:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x160C
    ;mptbltype 9
    ;mpsubtype n
    ;mptbllname L883E_L883e
    ;mptblcname L883E
    ;mpxaxis in_desc 11 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1
    .byte 0x5A                       ;Point 2
    .byte 0x34                       ;Point 3
    .byte 0x22                       ;Point 4
    .byte 0x11                       ;Point 5
    .byte 0x1C                       ;Point 6
    .byte 0x41                       ;Point 7
    .byte 0x01                       ;Point 8
    .byte 0x40                       ;Point 9
    .byte 0xFF                       ;Point 10
    .byte 0xFF                       ;Point 11

	;.org	0x8848
VNTLMP_BoostFromRPMForVNTLimpInMode:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1623
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname BoostFromRPMForVNTLimpInMode
    ;mptblcname VNTLMP
    ;mpxaxis Boost 0 29.4 psi
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    ;mpmapaxis x
    .byte 0x02                       ;Number of points in table
    .byte 0xA9, 0x58, 0xFD, 0x94     ;Point 1
    .byte 0xBC, 0x2A                 ;Point 2

	;.org   0x8857
RPMMP2_SwitchPointForDownUp_FromRpm2 :
    ;mpgrp Fuel\Transient_Enrichment\Part_Throttle_Enrichment\
    ;mptbladdr 0x1633
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname SwitchPointForDownUp_FromRpm2
    ;mptblcname RPMMP2
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc EPP_Control_toggle
    ;mpmapaxis y
    .byte 0x02                       ;Number of points in table
    .byte 0x4D, 0xA0, 0xFD, 0xD1     ;Point 1
    .byte 0x6E, 0x58                 ;Point 2

	;.org	0x886a
VLMPMN_MinimumBoostSetpointForVNTLimpinMode:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1643
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname MinimumBoostSetpointForVNTLimpinMode
    ;mptblcname VLMPMN
    ;mpxaxis Boost 0 29.4 psi
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    ;mpmapaxis x
    .byte 0x19                       ;Point 1

	;.org	0x886b
VNTRMX_MaximumRPMForVNTLimpInControl:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x1651
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MaximumRPMForVNTLimpInControl
    ;mptblcname VNTRMX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0xBC                       ;Point 1

;       .byte  0x00,0x01,0xff

	;.org	0x886f
BRPMLO_BaroReadLowRPM1800:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x1660
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname BaroReadLowRPM1800
    ;mptblcname BRPMLO
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .word 0x3840                     ;Point 1

	;.org	0x8871
BRPMHI_BaroReadHighRPM6650:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x166D
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname BaroReadHighRPM6650
    ;mptblcname BRPMHI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .word 0xCFD0                     ;Point 1

	;.org	0x8873
BRDLAY_BaroReadDelayAfterThrottleClosed2sec:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x167A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BaroReadDelayAfterThrottleClosed2sec
    ;mptblcname BRDLAY
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 2.8 sec
    ;mptbldesc Detailed_Description
    .byte 0xB5                       ;Point 1

	;.org	0x8874
BARTIM_BaroReadMinTimeBetweenReadings179sec:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x1687
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BaroReadMinTimeBetweenReadings179sec
    ;mptblcname BARTIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 720 sec
    ;mptbldesc Detailed_Description
    .byte 0x40                       ;Point 1

	;.org	0x8875
BROPTM_BaroReadDelayAfterSolenoidOpenTenthSec:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x1694
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BaroReadDelayAfterSolenoidOpenTenthSec
    ;mptblcname BROPTM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 2.8 sec
    ;mptbldesc Detailed_Description
    .byte 0x09                       ;Point 1

	;.org	0x8876
BRCLTM_BaroReadDelayAfterSolenoidClosedTenthSec:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x16A1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BaroReadDelayAfterSolenoidClosedTenthSec
    ;mptblcname BRCLTM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Time 0 2.8 sec
    ;mptbldesc Detailed_Description
    .byte 0x09                       ;Point 1

	;.org	0x8877
BAROHI_BaroReadValidHighLimit:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x16AE
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname BaroReadValidHighLimit
    ;mptblcname BAROHI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Baro -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x85                       ;Point 1

	;.org	0x8878
BAROLO_BaroReadValidLowLimit:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x16BC
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname BaroReadValidLowLimit
    ;mptblcname BAROLO
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Baro -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x45                       ;Point 1

	;.org	0x8879
BARDFT_BaroReadDefaultValue:
    ;mpgrp Utility\Baro_Read\
    ;mptbladdr 0x16CA
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname BaroReadDefaultValue
    ;mptblcname BARDFT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Baro -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x7F                       ;Point 1

	;.org	0x887a
FANTMP1_FanTurnOnTempAbove45Mph:
    ;mpgrp Fan_Control\
    ;mptbladdr 0x16D8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FanTurnOnTempAbove45Mph
    ;mptblcname FANTMP1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 F
    ;mptbldesc Detailed_Description3
    .byte 0xE8                       ;Point 1

	;.org	0x887b
FANTMP2_FanTurnOffTempAbove45Mph:
    ;mpgrp Fan_Control\
    ;mptbladdr 0x16E5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FanTurnOffTempAbove45Mph
    ;mptblcname FANTMP2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 F
    ;mptbldesc Detailed_Description3
    .byte 0xE3                       ;Point 1

	;.org	0x887c
FANTMP3_FanTurnOnTempBelow35Mph:
    ;mpgrp Fan_Control\
    ;mptbladdr 0x16F2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FanTurnOnTempBelow35Mph
    ;mptblcname FANTMP3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 F
    ;mptbldesc Detailed_Description3
    .byte 0xE3                       ;Point 1

	;.org	0x887d
FANTMP4_FanTurnOffTempBelow35Mph:
    ;mpgrp Fan_Control\
    ;mptbladdr 0x16FF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FanTurnOffTempBelow35Mph
    ;mptblcname FANTMP4
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 F
    ;mptbldesc Detailed_Description3
    .byte 0xDD                       ;Point 1

	;.org	0x887e
FANMAP_FanTurnsOnWhenMapAboveBaroPlusThis:
    ;mpgrp Fan_Control\
    ;mptbladdr 0x170C
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname FanTurnsOnWhenMapAboveBaroPlusThis
    ;mptblcname FANMAP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Boost 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x22                       ;Point 1

	;.org	0x887f
FANBAT_FanTurnsOnWhenBatteryTempAboveThis:
    ;mpgrp Fan_Control\
    ;mptbladdr 0x171A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FanTurnsOnWhenBatteryTempAboveThis
    ;mptblcname FANBAT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Battery_Temp -200 260 Degrees
    ;mptbldesc Detailed_Description
    .byte 0xBB                       ;Point 1

        .msg "..." ; these are just messages to display during assemble to let you know what's going on...

FNSPHI_FanControlSpeedHi:
    ;mpgrp Fan_Control\
    ;mptbladdr 0x1728
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FanControlSpeedHi
    ;mptblcname FNSPHI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 1024 mph
    ;mptbldesc Detailed_Description
    .byte 0x0B                       ;Point 1

FNSPLO_FanControlSpeedLo:
    ;mpgrp Fan_Control\
    ;mptbladdr 0x1734
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FanControlSpeedLo
    ;mptblcname FNSPLO
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 1024 mph
    ;mptbldesc Detailed_Description
    .byte 0x09                       ;Point 1

	;.org	0x8880
PURMAP_CannisterPurgeWhenBelowThisBaro:
    ;mpgrp Utility\Purge_Control\
    ;mptbladdr 0x1741
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname CannisterPurgeWhenBelowThisBaro
    ;mptblcname PURMAP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x05                       ;Point 1

	;.org	0x8881
PURHYS_CannisterPurgeBaroHysteresis:
    ;mpgrp Utility\Purge_Control\
    ;mptbladdr 0x174F
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname CannisterPurgeBaroHysteresis
    ;mptblcname PURHYS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x02                       ;Point 1

	;.org	0x8882
PURTMP_CanisterPurgeCoolantTemp:
    ;mpgrp Utility\Purge_Control\
    ;mptbladdr 0x175D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CanisterPurgeCoolantTemp
    ;mptblcname PURTMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xB6                       ;Point 1

	;.org	0x8883
CL2PTR_Cyl2AdaptiveMemoryPointer:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x176A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl2AdaptiveMemoryPointer
    ;mptblcname CL2PTR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0D                       ;Point 1

	;.org	0x8884
CL1PTR_Cyl1AdaptiveMemoryPointer:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x1777
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl1AdaptiveMemoryPointer
    ;mptblcname CL1PTR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x03                       ;Point 1

	;.org	0x8885
CL3PTR_Cyl3AdaptiveMemoryPointer:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x1784
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl3AdaptiveMemoryPointer
    ;mptblcname CL3PTR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

	;.org	0x8886
CL4PTR_Cyl4AdaptiveMemoryPointer:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x1791
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl4AdaptiveMemoryPointer
    ;mptblcname CL4PTR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x05                       ;Point 1

	;.org	0x8887
CL2LMT_Cyl2TrimLimit:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x179E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl2TrimLimit
    ;mptblcname CL2LMT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x33                       ;Point 1

	;.org	0x8888
CL1LMT_Cyl1TrimLimit:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x17AB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl1TrimLimit
    ;mptblcname CL1LMT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x33                       ;Point 1

	;.org	0x8889
CL3LMT_Cyl3TrimLimit:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x17B8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl3TrimLimit
    ;mptblcname CL3LMT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x33                       ;Point 1

	;.org	0x888a
CL4LMT_Cyl4TrimLimit:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x17C5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl4TrimLimit
    ;mptblcname CL4LMT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x33                       ;Point 1

	;.org	0x888b
CL2INC_Cyl2TrimIncrement:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x17D2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl2TrimIncrement
    ;mptblcname CL2INC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x05                       ;Point 1

	;.org	0x888c
CL1INC_Cyl1TrimIncrement:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x17DF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl1TrimIncrement
    ;mptblcname CL1INC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x05                       ;Point 1

	;.org	0x888d
CL3INC_Cyl3TrimIncrement:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x17EC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl3TrimIncrement
    ;mptblcname CL3INC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x05                       ;Point 1

	;.org	0x888e
CL4INC_Cyl4TrimIncrement:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x17F9
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl4TrimIncrement
    ;mptblcname CL4INC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x05                       ;Point 1

	;.org	0x888f
CLTRMN_MinimumCylinderTrim:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x1806
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinimumCylinderTrim
    ;mptblcname CLTRMN
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x07                       ;Point 1

	;.org	0x8890
CLTRP2_Cyl2TrimValueForPurgeVolume:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x1813
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl2TrimValueForPurgeVolume
    ;mptblcname CLTRP2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x20                       ;Point 1

	;.org	0x8891
CLTRP1_Cyl1TrimValueForPurgeVolume:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x1820
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl1TrimValueForPurgeVolume
    ;mptblcname CLTRP1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x12                       ;Point 1

	;.org	0x8892
CLTRP3_Cyl3TrimValueForPurgeVolume:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x182D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl3TrimValueForPurgeVolume
    ;mptblcname CLTRP3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFE                       ;Point 1

	;.org	0x8893
CLTRP4_Cyl4TrimValueForPurgeVolume:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x183A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Cyl4TrimValueForPurgeVolume
    ;mptblcname CLTRP4
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x84                       ;Point 1

	;.org	0x8894
ACLRPM_DisableAcBelowThisRPM_500:
    ;mpgrp Utility\AC_Control\
    ;mptbladdr 0x1847
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname DisableAcBelowThisRPM_500
    ;mptblcname ACLRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0FA0                     ;Point 1

	;.org	0x8896
ACOUT_DeltaAboveMinThrottleToCutOutAc:
    ;mpgrp Utility\AC_Control\
    ;mptbladdr 0x1854
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaAboveMinThrottleToCutOutAc
    ;mptblcname ACOUT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x8A                       ;Point 1

	;.org	0x8897
ACCRPM_DoNotAllowAcToEngageAboveThisRPM_4000:
    ;mpgrp Utility\AC_Control\
    ;mptbladdr 0x1861
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname DoNotAllowAcToEngageAboveThisRPM_4000
    ;mptblcname ACCRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x7D00                     ;Point 1

	;.org	0x8899
ACCTIM_AcDelayFromStartRunTransfer:
    ;mpgrp Utility\AC_Control\
    ;mptbladdr 0x186E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AcDelayFromStartRunTransfer
    ;mptblcname ACCTIM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

	;.org	0x889a
ACCNTI_ACCounterInitial:
    ;mpgrp Utility\AC_Control\
    ;mptbladdr 0x187B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ACCounterInitial
    ;mptblcname ACCNTI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x06                       ;Point 1

	;.org	0x889b
WOTDLT_DeltaThrottleFrom_MINTHR_ToDetermineFullThrottle:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x1888
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaThrottleFrom_MINTHR_ToDetermineFullThrottle
    ;mptblcname WOTDLT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x85                       ;Point 1

	;.org	0x889c
UNLOAD_DeltaThrottleFrom_MINTHR_ToUnloadCrankingFuel:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x1895
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaThrottleFrom_MINTHR_ToUnloadCrankingFuel
    ;mptblcname UNLOAD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x85                       ;Point 1

	;.org	0x889d
VACREG_CruiseControlVacRegularGainGurve_FromDeltaSpeed:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x18A2
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CruiseControlVacRegularGainGurve_FromDeltaSpeed
    ;mptblcname VACREG
    ;mpxaxis Delta_Speed 0 127 mph
    ;mpyaxis AccRate 0 5 mph/sec
    ;mptbldesc Detailed_Description
    .byte 0x03                       ;Number of points in table
    .byte 0x00, 0x02, 0x00, 0x0E     ;Point 1
    .byte 0x24, 0x04, 0x00, 0x10     ;Point 2
    .byte 0xFF, 0x12                 ;Point 3

	;.org	0x88b4
VACACC_CruiseControlVacAcceleratedGainCurve_FromDeltaSpeed:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x18B2
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CruiseControlVacAcceleratedGainCurve_FromDeltaSpeed
    ;mptblcname VACACC
    ;mpxaxis Delta_Speed 0 127 mph
    ;mpyaxis AccRate 0 5 mph/sec
    ;mptbldesc Detailed_Description
    .byte 0x03                       ;Number of points in table
    .byte 0x00, 0x02, 0x00, 0x78     ;Point 1
    .byte 0x40, 0x20, 0x00, 0x0E     ;Point 2
    .byte 0xFD, 0x2A                 ;Point 3

	;.org	0x88c3
VENTRG_CruiseControlVentRegularGainCurve_FromDeltaSpeed:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x18C2
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CruiseControlVentRegularGainCurve_FromDeltaSpeed
    ;mptblcname VENTRG
    ;mpxaxis Delta_Speed 0 127 mph
    ;mpyaxis AccRate 0 5 mph/sec
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Number of points in table
    .byte 0x00, 0x02, 0xFF, 0xF2     ;Point 1
    .byte 0x12, 0x01, 0xFF, 0xE6     ;Point 2
    .byte 0x1C, 0x00, 0xFF, 0xF7     ;Point 3
    .byte 0xFF, 0xF8                 ;Point 4

	;.org	0x88d2
CRUZ1_UknownTableForCruiseControl1:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x18D3
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname UknownTableForCruiseControl1
    ;mptblcname CRUZ1
    ;mpxaxis in 0 255 in
    ;mpyaxis out 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x00, 0xE0, 0xFF, 0xC0     ;Point 1
    .byte 0xC0, 0xB0                 ;Point 2

	;.org	0x88e1
CRUZ2_UknownTableForCruiseControl2:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x18E2
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname UknownTableForCruiseControl2
    ;mptblcname CRUZ2
    ;mpxaxis in 0 255 in
    ;mpyaxis out 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x98, 0x01, 0x00, 0x30     ;Point 1
    .byte 0xCD, 0x0B                 ;Point 2

	;.org	0x88ec
CRUZ3_UknownTableForCruiseControl3:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x18F1
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname UknownTableForCruiseControl3
    ;mptblcname CRUZ3
    ;mpxaxis in 0 255 in
    ;mpyaxis out 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x78, 0x80, 0x03, 0xF8     ;Point 1
    .byte 0x98, 0xFF                 ;Point 2

	;.org	0x88f7
CRUZ4_UknownTableForCruiseControl4:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1900
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname UknownTableForCruiseControl4
    ;mptblcname CRUZ4
    ;mpxaxis in 0 255 in
    ;mpyaxis out 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x33, 0x06, 0xFF, 0xE8     ;Point 1
    .byte 0x68, 0x01                 ;Point 2

	;.org	0x8902
CRUZ5_UknownTableForCruiseControl5:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x190F
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname UknownTableForCruiseControl5
    ;mptblcname CRUZ5
    ;mpxaxis in 0 255 in
    ;mpyaxis out 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x68, 0xFF, 0xFC, 0x08     ;Point 1
    .byte 0x88, 0x80                 ;Point 2

	;.org	0x890d
SETPW_CruiseControlSetupPulseForSet_FromSpeed:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x191E
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CruiseControlSetupPulseForSet_FromSpeed
    ;mptblcname SETPW
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis Vacuum 0 2.8 Pulsewidth
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Number of points in table
    .byte 0x46, 0x29, 0x00, 0x11     ;Point 1
    .byte 0x64, 0x2B, 0x00, 0x22     ;Point 2
    .byte 0x82, 0x2F, 0x00, 0x2C     ;Point 3
    .byte 0xC8, 0x3B                 ;Point 4

	;.org	0x891c
RESTBL_CruiseControlAdditionalSetupPulseForResume_FromSpeedDifference:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x192F
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname CruiseControlAdditionalSetupPulseForResume_FromSpeedDifference
    ;mptblcname RESTBL
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis AbsMAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x06                       ;Number of points in table
    .byte 0x1A, 0x77, 0x00, 0x28     ;Point 1
    .byte 0x53, 0x80, 0x00, 0x6E     ;Point 2
    .byte 0x6F, 0x8C, 0x00, 0xEB     ;Point 3
    .byte 0x87, 0xA2, 0x00, 0x00     ;Point 4
    .byte 0x9A, 0xA2, 0xFD, 0x40     ;Point 5
    .byte 0xA2, 0x8C                 ;Point 6

	;.org	0x8933
RESTBL2_CruiseControlAdditionalSetupPulseForResume_FromSpeedDifference2:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1943
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CruiseControlAdditionalSetupPulseForResume_FromSpeedDifference2
    ;mptblcname RESTBL2
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis Vacuum 0 2.8 Pulsewidth
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Number of points in table
    .byte 0x70, 0x77, 0x00, 0x90     ;Point 1
    .byte 0x80, 0x80, 0x00, 0x2B     ;Point 2
    .byte 0xBC, 0x8A, 0x00, 0x33     ;Point 3
    .byte 0xEE, 0x94                 ;Point 4

	;.org	0x8952
THGAIN_CruiseControlThrottleGainFactor_FromThrottle:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1954
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CruiseControlThrottleGainFactor_FromThrottle
    ;mptblcname THGAIN
    ;mpxaxis TPS 0 255 tps
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x01, 0x08, 0x0C, 0x00     ;Point 1
    .byte 0x03, 0x20                 ;Point 2

	;.org	0x895d
SPGAIN_CruiseControlSpeedGainFactor_FromSpeed:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1963
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CruiseControlSpeedGainFactor_FromSpeed
    ;mptblcname SPGAIN
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis out_desc 0 255 scale
    ;mptbldesc Detailed_Description
    .byte 0x03                       ;Number of points in table
    .byte 0x3C, 0x14, 0xFF, 0x9A     ;Point 1
    .byte 0x6E, 0x00, 0x00, 0xF3     ;Point 2
    .byte 0x94, 0x24                 ;Point 3

	;.org	0x8968
CRUZ6_UknownTableForCruiseControl6:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1973
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname UknownTableForCruiseControl6
    ;mptblcname CRUZ6
    ;mpxaxis in 0 255 in
    ;mpyaxis out 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Number of points in table
    .byte 0x00, 0x06, 0x00, 0x33     ;Point 1
    .byte 0x05, 0x07                 ;Point 2

	;.org	0x8973
CRUZ7_UknownTableForCruiseControl7:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1982
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownTableForCruiseControl7
    ;mptblcname CRUZ7
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x8974
VNTAB1_CruiseControlLimitToAMaxVent:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x198F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlLimitToAMaxVent
    ;mptblcname VNTAB1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x90                       ;Point 1

	;.org	0x8975
VNTAB2_CruiseControlLimitToHalfMaxVent:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x199C
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlLimitToHalfMaxVent
    ;mptblcname VNTAB2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x60                       ;Point 1

	;.org	0x8976
CRUZ46_UknownConstForCruiseControl46:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x19A9
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl46
    ;mptblcname CRUZ46
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x09                       ;Point 1

	;.org	0x8977
CRUZ47_UknownConstForCruiseControl47:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x19B6
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl47
    ;mptblcname CRUZ47
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x2F                       ;Point 1

	;.org	0x8978
ACLRST_CruiseControlDeltaSpeedToResetAccFlag:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x19C3
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlDeltaSpeedToResetAccFlag
    ;mptblcname ACLRST
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaSpeed 0 127 mph
    ;mptbldesc Detailed_Description
    .byte 0x18                       ;Point 1

	;.org	0x8979
CLOTHR_CruiseControlDontVentIfThrottleBelowThis:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x19D0
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlDontVentIfThrottleBelowThis
    ;mptblcname CLOTHR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x897a
MAXTHR_CruiseControlDontVacIfThrottleAboveThis:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x19DD
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlDontVacIfThrottleAboveThis
    ;mptblcname MAXTHR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x66                       ;Point 1

	;.org	0x897b
MAXSET_CruiseControlMaxSetSpeedTimesTwo:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x19EA
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlMaxSetSpeedTimesTwo
    ;mptblcname MAXSET
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 128 MPH
    ;mptbldesc Detailed_Description
    .byte 0xAA                       ;Point 1

	;.org	0x897c
MINSET_CruiseControlMinSetSpeedTimesTwo:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x19F7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlMinSetSpeedTimesTwo
    ;mptblcname MINSET
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 128 MPH
    ;mptbldesc Detailed_Description
    .byte 0x46                       ;Point 1

	;.org	0x897d
SCNVHI_CruiseControlForBrakeFlagManualTransmissionClutchDisableHi:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A04
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlForBrakeFlagManualTransmissionClutchDisableHi
    ;mptblcname SCNVHI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x897e
SCNVLO_CruiseControlForBrakeFlagManualTransmissionClutchDisableLo:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A11
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlForBrakeFlagManualTransmissionClutchDisableLo
    ;mptblcname SCNVLO
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x52                       ;Point 1

	;.org	0x897f
CRUZ21_UknownConstForCruiseControl21:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A1E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl21
    ;mptblcname CRUZ21
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x3C                       ;Point 1

	;.org	0x8980
CRUZ22_UknownConstForCruiseControl22:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A2B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl22
    ;mptblcname CRUZ22
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xBC                       ;Point 1

	;.org	0x8981
CRUZ23_UknownConstForCruiseControl23:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A38
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl23
    ;mptblcname CRUZ23
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x06                       ;Point 1
 
CRUZ2x_UknownConstForCruiseControl2x:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A44
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl2x
    ;mptblcname CRUZ2X
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

CRUZ2y_UknownConstForCruiseControl2y:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A50
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl2y
    ;mptblcname CRUZ2Y
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xBA                       ;Point 1

	;.org	0x8984
CRUZ24_UknownConstForCruiseControl24:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A5D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl24
    ;mptblcname CRUZ24
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x8985
CRUZ25_UknownConstForCruiseControl25:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A6A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl25
    ;mptblcname CRUZ25
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x30                       ;Point 1

	;.org	0x8986
CRUZ26_UknownConstForCruiseControl26:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A77
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl26
    ;mptblcname CRUZ26
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

	;.org	0x8987
CRUZ27_UknownConstForCruiseControl27:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A84
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl27
    ;mptblcname CRUZ27
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8988
CRUZ28_UknownConstForCruiseControl28:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A91
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl28
    ;mptblcname CRUZ28
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8989
CRUZ29_UknownConstForCruiseControl29:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1A9E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl29
    ;mptblcname CRUZ29
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x898a
CRUZ30_UknownConstForCruiseControl30:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1AAB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl30
    ;mptblcname CRUZ30
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

	;.org	0x898b
CRUZ31_UknownConstForCruiseControl31:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1AB8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl31
    ;mptblcname CRUZ31
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x34                       ;Point 1

	;.org	0x898c
CRUZ32_UknownConstForCruiseControl32:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1AC5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl32
    ;mptblcname CRUZ32
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x08                       ;Point 1

	;.org	0x898d
CRUZ33_UknownConstForCruiseControl33:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1AD2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl33
    ;mptblcname CRUZ33
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x898e
CRUZ34_UknownConstForCruiseControl34:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1ADF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl34
    ;mptblcname CRUZ34
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x20                       ;Point 1

	;.org	0x898f
CRUZ35_UknownConstForCruiseControl35:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1AEC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl35
    ;mptblcname CRUZ35
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0C                       ;Point 1

	;.org	0x8990
CRUZ36_UknownConstForCruiseControl36:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1AF9
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownConstForCruiseControl36
    ;mptblcname CRUZ36
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x8C                       ;Point 1

	;.org	0x8991
SETDLT_CruiseControlSetDeltaControlPointForCableAdaptive:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B06
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseControlSetDeltaControlPointForCableAdaptive
    ;mptblcname SETDLT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x8992
CRSCN2_CruiseComapreConstant2:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B13
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseComapreConstant2
    ;mptblcname CRSCN2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x06                       ;Point 1

	;.org	0x8993
CRMSK2_CruiseMask2:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B20
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseMask2
    ;mptblcname CRMSK2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x07                       ;Point 1

	;.org	0x8994
CRMSK3_CruiseMask3:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B2D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseMask3
    ;mptblcname CRMSK3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xF6                       ;Point 1

	;.org	0x8995
CRMSK7_CruiseMask7:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B3A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseMask7
    ;mptblcname CRMSK7
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8996
CRMSK4_CruiseMask4:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B47
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseMask4
    ;mptblcname CRMSK4
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

	;.org	0x8997
CRMSK6_CruiseMask6:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B54
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseMask6
    ;mptblcname CRMSK6
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x1F                       ;Point 1

	;.org	0x8998
CRMSK5_CruiseMask5:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B61
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseMask5
    ;mptblcname CRMSK5
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xE1                       ;Point 1

	;.org	0x8999
CRSCN1_CruiseComapreConstant1:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B6E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseComapreConstant1
    ;mptblcname CRSCN1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x16                       ;Point 1

	;.org	0x899a
CRMASK_CruiseMask:
    ;mpgrp Utility\Cruise_Control\
    ;mptbladdr 0x1B7B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CruiseMask
    ;mptblcname CRMASK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x11                       ;Point 1

	;.org	0x899b
PTUMTP_PTUMinLockTemperature:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1B88
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PTUMinLockTemperature
    ;mptblcname PTUMTP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 F
    ;mptbldesc Min_temp_for_PTU_lock
    .byte 0xFF                       ;Point 1

	;.org	0x899c
PTUMSP_PTUMinLockSpeed:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1B95
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PTUMinLockSpeed
    ;mptblcname PTUMSP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 128 MPH
    ;mptbldesc Min_Speed_for_PTU_lock
    .byte 0x5B                       ;Point 1

	;.org	0x899d
PTUCNH_PTUCounterHiSpeed:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1BA2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PTUCounterHiSpeed
    ;mptblcname PTUCNH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x5B                       ;Point 1

	;.org	0x899e
PTUCNL_PTUCounterLoSpeed:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1BAF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PTUCounterLoSpeed
    ;mptblcname PTUCNL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x5B                       ;Point 1

	;.org	0x899f
PTUDTP_PTUDeltaTPSForUnlock:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1BBC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PTUDeltaTPSForUnlock
    ;mptblcname PTUDTP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Delta_TPS 0 5 V
    ;mptbldesc Min_TPS_for_PTU_unlock
    .byte 0x34                       ;Point 1

	;.org	0x89a0
PTUMP1_PTUMAPThresholdForLock1:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1BC9
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname PTUMAPThresholdForLock1
    ;mptblcname PTUMP1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Delta_MAP 0 29.4 PSI
    ;mptbldesc Delta_MAP_for_PTU_unlock
    ;mpmapaxis y
    .byte 0x78                       ;Point 1

	;.org	0x89a1
PTUMP2_PTUMAPThresholdForLock2:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1BD7
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname PTUMAPThresholdForLock2
    ;mptblcname PTUMP2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Delta_MAP 0 29.4 PSI
    ;mptbldesc Delta_MAP_for_PTU_unlock
    ;mpmapaxis y
    .byte 0x56                       ;Point 1

	;.org	0x89a2
PTUMP3_PTUMAPThresholdForLock3:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1BE5
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname PTUMAPThresholdForLock3
    ;mptblcname PTUMP3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Delta_MAP 0 29.4 PSI
    ;mptbldesc Delta_MAP_for_PTU_unlock
    ;mpmapaxis y
    .byte 0x78                       ;Point 1

	;.org	0x89a3
PTUCNI_PTUCounterTimerIntervalForLoop:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1BF3
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname PTUCounterTimerIntervalForLoop
    ;mptblcname PTUCNI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x07                       ;Point 1

	;.org	0x89a4
PRPTUE_PrimaryPTUEngagement:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1C00
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname PrimaryPTUEngagement
    ;mptblcname PRPTUE
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis Delta_TPS 0 5 Volts
    ;mptbldesc Primary_engagnement_point_for_PTU
    .byte 0x04                       ;Number of points in table
    .byte 0x44, 0x04, 0x09, 0x40     ;Point 1
    .byte 0x48, 0x29, 0x00, 0xAB     ;Point 2
    .byte 0x5A, 0x35, 0x0A, 0xCD     ;Point 3
    .byte 0x64, 0xA1                 ;Point 4

	;.org	0x89b7
PRPTUD_PrimaryPTUDisengagement:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1C11
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname PrimaryPTUDisengagement
    ;mptblcname PRPTUD
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis Delta_TPS 0 5 Volts
    ;mptbldesc Primary_disengagnement_point_for_PTU
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x04                 ;Point 1

	;.org	0x89c2
SRPTUE_SecondaryPTUEngagement:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1C1F
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname SecondaryPTUEngagement
    ;mptblcname SRPTUE
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis Delta_TPS 0 5 Volts
    ;mptbldesc Secondary_engagnement_point_for_PTU
    .byte 0x04                       ;Number of points in table
    .byte 0x48, 0x06, 0x06, 0x80     ;Point 1
    .byte 0x4C, 0x20, 0x00, 0x80     ;Point 2
    .byte 0x6E, 0x31, 0x0B, 0x33     ;Point 3
    .byte 0x78, 0xA1                 ;Point 4

	;.org	0x89d5
SRPTUD_SecondaryPTUDisengagement:
    ;mpgrp Utility\PTU_Control\
    ;mptbladdr 0x1C30
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname SecondaryPTUDisengagement
    ;mptblcname SRPTUD
    ;mpxaxis Speed 0 128 mph
    ;mpyaxis Delta_TPS 0 5 Volts
    ;mptbldesc Secondary_disengagnement_point_for_PTU
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x06                 ;Point 1

	;.org	0x89e0
MININC_Amount_MINTHR_IsIncreasedAtKeyOnOnly:
    ;mpgrp OB,_Speed,_and_Rev_Limiter\Misc,_Limp_Mode\
    ;mptbladdr 0x1C3E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname Amount_MINTHR_IsIncreasedAtKeyOnOnly
    ;mptblcname MININC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x03                       ;Point 1

	;.org	0x89e1
MAPTHR_ThrottleSelfCalibrationMapDeltaThreshold:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x1C4B
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname ThrottleSelfCalibrationMapDeltaThreshold
    ;mptblcname MAPTHR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x31                       ;Point 1

	;.org	0x89e2
RPMTHR_ThrottleSelfCalibrationRpmThreshold:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x1C59
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ThrottleSelfCalibrationRpmThreshold
    ;mptblcname RPMTHR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x30                       ;Point 1

	;.org	0x89e3
MTHRMX_ValueOf_MINTHR_WhenBatteryDisconnected:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x1C66
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ValueOf_MINTHR_WhenBatteryDisconnected
    ;mptblcname MTHRMX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x5C                       ;Point 1

	;.org	0x89e4
MAXCNT_ProgramLoopsWithThrottleBelow_MINTHR_ToDecrement_MINTHR:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x1C73
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ProgramLoopsWithThrottleBelow_MINTHR_ToDecrement_MINTHR
    ;mptblcname MAXCNT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x10                       ;Point 1

	;.org	0x89e5
MTHRCL_NumberOfBitsAbove_MINTHR_ToDetermineOnThrottleTransition:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x1C80
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NumberOfBitsAbove_MINTHR_ToDetermineOnThrottleTransition
    ;mptblcname MTHRCL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

	;.org	0x89e6
MTHROP_NumberOfBitsAbove_MINTHR_ToDetermineOffThrottleTransition:
    ;mpgrp Setup\Throttle_Calibration\
    ;mptbladdr 0x1C8D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname NumberOfBitsAbove_MINTHR_ToDetermineOffThrottleTransition
    ;mptblcname MTHROP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x89e7
EGR1_ExhGasRecircConst:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1C9A
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname ExhGasRecircConst1
    ;mptblcname EGR1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x01C6                     ;Point 1

	;.org	0x89e9
EGR3_ExhGasRecircConst3:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1CA7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConst3
    ;mptblcname EGR3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x28                       ;Point 1

	;.org	0x89ea
EGR18_ExhGasRecircConstLoLimit:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1CB4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstLoLimit18
    ;mptblcname EGR18
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89eb
EGR18a_ExhGasRecircConstHiLimit:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1CC1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstHiLimit18a
    ;mptblcname EGRR18A
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89ec
EGR16_ExhGasRecircConstLoLimit16:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1CCE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstLoLimit16
    ;mptblcname EGR16
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89ed
EGR16a_ExhGasRecircConstHiLimit:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1CDB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstHiLimit16a
    ;mptblcname EGR16A
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89ee
EGR14_ExhGasRecircConstFromTPSVoltsLoLimit14:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1CE8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstFromTPSVoltsLoLimit14
    ;mptblcname EGR14
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89ef
EGR14a_ExhGasRecircConstFromTPSVoltsHiLimit14a:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1CF5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstFromTPSVoltsHiLimit14a
    ;mptblcname EGR14A
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89f0
EGR19_ExhGasRecircConstLoLimit19:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D02
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstLoLimit19
    ;mptblcname EGR19
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89f1
EGR19a_ExhGasRecircConstHiLimit19a:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D0F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstHiLimit19a
    ;mptblcname EGR19A
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89f2
EGR15_ExhGasRecircConstFromRPMLoLimit15:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D1C
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstFromRPMLoLimit15
    ;mptblcname EGR15
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89f3
EGR17_ExhGasRecircConstLoLimit:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D29
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstLoLimit17
    ;mptblcname EGR17
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89f4
EGR17a_ExhGasRecircConstHiLimit17a:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D36
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstHiLimit17a
    ;mptblcname EGR17A
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89f6
EGR4_ExhGasRecircConst4:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D43
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConst4
    ;mptblcname EGR4
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xEB                       ;Point 1
;	.byte	0xff

	;.org	0x89f7
EGR5_ExhGasRecircConst5:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D51
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConst5
    ;mptblcname EGR5
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x89f8
EGR6_ExhGasRecircConst6:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D5E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConst6
    ;mptblcname EGR6
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x89f9
EGR15a_ExhGasRecircConstFromRPMHiLimit:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D6B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstFromRPMHiLimit15a
    ;mptblcname EGR15A
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x6C                       ;Point 1

	;.org	0x89fa
EGR7_ExhGasRecircConst7:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D78
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConst7
    ;mptblcname EGR7
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x14                       ;Point 1

	;.org	0x89fb
SCRMP1_SecondaryRampSubtractor1:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D85
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname SecondaryRampSubtractor1
    ;mptblcname SCRMP1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x10                       ;Point 1

	;.org	0x89fc
ADMEMA_ValueFromAdaptivememoryAdder1:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D92
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ValueFromAdaptivememoryAdder1
    ;mptblcname ADMEMA
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

	;.org	0x89fd
EGR8_ExhGasRecircConst8:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1D9F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConst8
    ;mptblcname EGR8
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0D                       ;Point 1

	;.org	0x89fe
EGR8a_ExhGasRecircConst8a:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1DAC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConst8a
    ;mptblcname EGR8A
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x89ff
EGR2_ExhGasRecircConstFromMAPBelowBaro:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1DB9
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname ExhGasRecircConstFromMAPBelowBaro2
    ;mptblcname EGR2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x16                       ;Point 1

	;.org	0x8a00
EGR9_ExhGasRecircConstFromTimeEngRunning9:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1DC7
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstFromTimeEngRunning9
    ;mptblcname EGR9
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x6B                       ;Point 1

	;.org	0x8a01
EGR21_ExhGasRecircConstFromRPM1:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1DD4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstFromRPM1
    ;mptblcname EGR21
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFA                       ;Point 1

	;.org	0x8a02
EGR22_ExhGasRecircConstFromRPM2:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1DE1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstFromRPM2
    ;mptblcname EGR22
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8a03
EGR23_ExhGasRecircConstFromMAP1:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1DEE
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname ExhGasRecircConstFromMAP1
    ;mptblcname EGR23
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0xFA                       ;Point 1

	;.org	0x8a04
EGR24_ExhGasRecircConstFromMAP2:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1DFC
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname ExhGasRecircConstFromMAP2
    ;mptblcname EGR24
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x03                       ;Point 1

	;.org	0x8a05
EGR25_ExhGasRecircConstFromBaro1:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1E0A
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname ExhGasRecircConstFromBaro1
    ;mptblcname EGR25
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Baro 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x00                       ;Point 1

	;.org	0x8a06
EGR26_ExhGasRecircConstFromBaro2:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1E18
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname ExhGasRecircConstFromBaro2
    ;mptblcname EGR26
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Baro 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x00                       ;Point 1

	;.org	0x8a07
EGR27_ExhGasRecircConstFromCoolantTemp:
    ;mpgrp Utility\EGR\
    ;mptbladdr 0x1E26
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ExhGasRecircConstFromCoolantTemp
    ;mptblcname EGR27
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFF                       ;Point 1

	;.org	0x8a08
LMPINN_LimpinTableForMapFromThrottle:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x1E33
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname LimpinTableForMapFromThrottle
    ;mptblcname LMPINN
    ;mpxaxis TPS 0 255 tps
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x05                       ;Number of points in table
    .byte 0x00, 0x00, 0x02, 0x50     ;Point 1
    .byte 0x10, 0x25, 0x01, 0xDB     ;Point 2
    .byte 0x17, 0x32, 0x01, 0x5D     ;Point 3
    .byte 0x22, 0x41, 0x00, 0xF9     ;Point 4
    .byte 0x45, 0x63                 ;Point 5

	;.org	0x8a1f
MPLMOF_OffsetForCalcMapInMapLimpin:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x1E46
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname OffsetForCalcMapInMapLimpin
    ;mptblcname MPLMOF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x20                       ;Point 1

	;.org	0x8a20
THROFF_OffsetAddedToCalcThrottle:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x1E54
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname OffsetAddedToCalcThrottle
    ;mptblcname THROFF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x0B                       ;Point 1

	;.org	0x8a21
OFSMID_OffsetForMAPOverIdle:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x1E61
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname OffsetForMAPOverIdle
    ;mptblcname OFSMID
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFE                       ;Point 1

	;.org	0x8a22
INCMID_IncrementForMAPOverIdle:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x1E6E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname IncrementForMAPOverIdle
    ;mptblcname INCMID
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

	;.org	0x8a23
OFSRID_OffsetForRPMOverIdle:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x1E7B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname OffsetForRPMOverIdle
    ;mptblcname OFSRID
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xD0                       ;Point 1

	;.org	0x8a24
INCRID_IncrementForRPMOverIdle:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x1E88
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname IncrementForRPMOverIdle
    ;mptblcname INCRID
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8a25
MNRPO2_MinimumRPMOverIdleForO2Feedback:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x1E95
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinimumRPMOverIdleForO2Feedback
    ;mptblcname MNRPO2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xD0                       ;Point 1

	;.org	0x8a26
CTLMC1_CylinderTrimCounter1LimitFromCoolantTemp:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x1EA2
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CylinderTrimCounter1LimitFromCoolantTemp
    ;mptblcname CTLMC1
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x7F                 ;Point 1

	;.org	0x8a31
CTLMC2_CylinderTrimCounter2LimitFromCoolantTemp:
    ;mpgrp Fuel\Individual_Cylinder_Trim\
    ;mptbladdr 0x1EB0
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname CylinderTrimCounter2LimitFromCoolantTemp
    ;mptblcname CTLMC2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x7F                 ;Point 1

	;.org	0x8a3c
DFBFMD_DefaultBaseFuelModifierFromRPMOverIdle:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x1EBE
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname DefaultBaseFuelModifierFromRPMOverIdle
    ;mptblcname DFBFMD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x00                 ;Point 1

	;.org	0x8a47
TMPLOW_OutOfRangeHotTooLowA2D:
    ;mpgrp Utility\On-Board_Diagnostics\Coolant_Temp_Sensor\
    ;mptbladdr 0x1ECC
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname OutOfRangeHotTooLowA2D
    ;mptblcname TMPLOW
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x1A                       ;Point 1

	;.org	0x8a48
TMPHIG_OutOfRangeColdTooHighA2D:
    ;mpgrp Utility\On-Board_Diagnostics\Coolant_Temp_Sensor\
    ;mptbladdr 0x1ED9
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname OutOfRangeColdTooHighA2D
    ;mptblcname TMPHIG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFD                       ;Point 1

	;.org	0x8a49
DEFTMP_DefaultEngineTemp:
    ;mpgrp Utility\On-Board_Diagnostics\Coolant_Temp_Sensor\
    ;mptbladdr 0x1EE6
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DefaultEngineTemp
    ;mptblcname DEFTMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xB2                       ;Point 1

	;.org	0x8a4a
BTLRPM_LowBatteryVoltageAtThisRpm1500:
    ;mpgrp Utility\On-Board_Diagnostics\Battery_Volts\
    ;mptbladdr 0x1EF3
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LowBatteryVoltageAtThisRpm1500
    ;mptblcname BTLRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x2E                       ;Point 1

	;.org	0x8a4b
CTLRPM_LowBatteryVoltageAtThisCoolantTemp:
    ;mpgrp Utility\On-Board_Diagnostics\Battery_Volts\
    ;mptbladdr 0x1F00
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LowBatteryVoltageAtThisCoolantTemp
    ;mptblcname CTLRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xCD                       ;Point 1

	;.org	0x8a4c
BTLRPM2_LowBatteryVoltageAtThisRpm1500:
    ;mpgrp Utility\On-Board_Diagnostics\Battery_Volts\
    ;mptbladdr 0x1F0D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LowBatteryVoltageAtThisRpm1500_2
    ;mptblcname BTLRPM2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x2E                       ;Point 1

	;.org	0x8a4d
AMBLOW_BattTempLowWhenHot:
    ;mpgrp Utility\On-Board_Diagnostics\Battery_Temp_Sensor\
    ;mptbladdr 0x1F1A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BattTempLowWhenHot
    ;mptblcname AMBLOW
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x05                       ;Point 1

	;.org	0x8a4e
AMBHIG_BattTempHighWhenCold:
    ;mpgrp Utility\On-Board_Diagnostics\Battery_Temp_Sensor\
    ;mptbladdr 0x1F27
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BattTempHighWhenCold
    ;mptblcname AMBHIG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFA                       ;Point 1

	;.org	0x8a4f
CHGLOW_ChargeTempOutOfRangeLow:
    ;mpgrp Utility\On-Board_Diagnostics\Charge_TempSensor\
    ;mptbladdr 0x1F34
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ChargeTempOutOfRangeLow
    ;mptblcname CHGLOW
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x1A                       ;Point 1

	;.org	0x8a50
CHGHIG_ChargeTempOutOfRangeHigh:
    ;mpgrp Utility\On-Board_Diagnostics\Charge_TempSensor\
    ;mptbladdr 0x1F41
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ChargeTempOutOfRangeHigh
    ;mptblcname CHGHIG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFD                       ;Point 1

	;.org	0x8a51
DEFCHG_DefaultChargeTemp_Limpin:
    ;mpgrp Utility\On-Board_Diagnostics\Charge_TempSensor\
    ;mptbladdr 0x1F4E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DefaultChargeTemp_Limpin
    ;mptblcname DEFCHG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x95                       ;Point 1

	;.org	0x8a52
ERRRPM_RPMLimitforErrorCodeSetting:
    ;mpgrp Utility\On-Board_Diagnostics\Error_Code\
    ;mptbladdr 0x1F5B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname RPMLimitforErrorCodeSetting
    ;mptblcname ERRRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x38                       ;Point 1

	;.org	0x8a53
ERRMAP_MAPLimitforErrorCodeSetting:
    ;mpgrp Utility\On-Board_Diagnostics\Error_Code\
    ;mptbladdr 0x1F68
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname MAPLimitforErrorCodeSetting
    ;mptblcname ERRMAP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x2B                       ;Point 1

	;.org	0x8a54
ERRTMP_CoolantTempLimitforErrorCodeSetting:
    ;mpgrp Utility\On-Board_Diagnostics\Error_Code\
    ;mptbladdr 0x1F76
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CoolantTempLimitforErrorCodeSetting
    ;mptblcname ERRTMP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xA0                       ;Point 1

	;.org	0x8a55
THRLOW_ThrottleLowerLimit:
    ;mpgrp Utility\On-Board_Diagnostics\TPS_Sensor\
    ;mptbladdr 0x1F83
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ThrottleLowerLimit
    ;mptblcname THRLOW
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x08                       ;Point 1

	;.org	0x8a56
THRHIG_ThrottleUpperLimit:
    ;mpgrp Utility\On-Board_Diagnostics\TPS_Sensor\
    ;mptbladdr 0x1F90
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ThrottleUpperLimit
    ;mptblcname THRHIG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xE4                       ;Point 1

	;.org	0x8a57
MPTHR_MapSwitchPointForFullThrottleOrIdle:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x1F9D
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname MapSwitchPointForFullThrottleOrIdle
    ;mptblcname MPTHR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x68                       ;Point 1

	;.org	0x8a58
COILLO_LoLimitBatteryVoltsForCoilVerify:
    ;mpgrp Utility\On-Board_Diagnostics\Ignition_Coil\
    ;mptbladdr 0x1FAB
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname LoLimitBatteryVoltsForCoilVerify
    ;mptblcname COILLO
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x05                       ;Point 1

	;.org	0x8a59
COILHI_HiLimitBatteryVoltsForCoilVerify:
    ;mpgrp Utility\On-Board_Diagnostics\Ignition_Coil\
    ;mptbladdr 0x1FB9
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname HiLimitBatteryVoltsForCoilVerify
    ;mptblcname COILHI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xBA                       ;Point 1

	;.org	0x8a5a
MAPLOW_MapSensorLowerLimit:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x1FC6
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MapSensorLowerLimit
    ;mptblcname MAPLOW
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8a5b
MAPHIG_MapSensorUpperLimit:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x1FD3
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MapSensorUpperLimit
    ;mptblcname MAPHIG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xEE                       ;Point 1

	;.org	0x8a5c
MPLTHR_ThrottleLevelAbove_MINTHR_ToMatureMapLimpin:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x1FE0
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ThrottleLevelAbove_MINTHR_ToMatureMapLimpin
    ;mptblcname MPLTHR
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x42                       ;Point 1

	;.org	0x8a5d
MPDELT_DeltaMapThatChecksGood:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x1FED
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaMapThatChecksGood
    ;mptblcname MPDELT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8a5e
MPDELA_MatureMapLimpinWhenDeltaAbove_MPDELT_plus_MPDELA:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x1FFA
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MatureMapLimpinWhenDeltaAbove_MPDELT_plus_MPDELA
    ;mptblcname MPDELA
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1

	;.org	0x8a5f
MPRPML_DisableMapCheckUnderThisRpm_600:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x2007
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname DisableMapCheckUnderThisRpm_600
    ;mptblcname MPRPML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x12C0                     ;Point 1

	;.org	0x8a61
MPRPMH_DisableMapCheckAboveThisRpm_1500:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x2014
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname DisableMapCheckAboveThisRpm_1500
    ;mptblcname MPRPMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x2EE0                     ;Point 1

	;.org	0x8a63
MPDAGL_DisableMapCheckBelowThisMap:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x2021
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DisableMapCheckBelowThisMap
    ;mptblcname MPDAGL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x10                       ;Point 1

	;.org	0x8a64
MPDAGH_DisableMapCheckAboveThisMap:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x202F
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname DisableMapCheckAboveThisMap
    ;mptblcname MPDAGH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x81                       ;Point 1

	;.org	0x8a65
MPRMPD_CheckMapAtZeroSpeedAndThisDeltaRpm:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x203D
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname CheckMapAtZeroSpeedAndThisDeltaRpm
    ;mptblcname MPRMPD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0200                     ;Point 1

	;.org	0x8a67
BAROSW_CheckMapAtZeroSpeedAndThisBaroSwitch:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x204A
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname CheckMapAtZeroSpeedAndThisBaroSwitch
    ;mptblcname BAROSW
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x62                       ;Point 1

	;.org	0x8a68
MPVACD_AllowMapToTestGoodThisNearBaro:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x2058
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AllowMapToTestGoodThisNearBaro
    ;mptblcname MPVACD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x11                       ;Point 1

MPVAC2_AllowMapToTestGoodThisNearBaro2:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x2065
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname AllowMapToTestGoodThisNearBaro2
    ;mptblcname MPVAC2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis MAP -14.7 14.7 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x08                       ;Point 1

	;.org	0x8a6a
MPDELX_DeltaMapThatChecksGoodX:
    ;mpgrp Utility\On-Board_Diagnostics\MAP_Sensor\
    ;mptbladdr 0x2073
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DeltaMapThatChecksGoodX
    ;mptblcname MPDELX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

UknownByteA:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x207F
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownBytesA
    ;mptblcname UKNOWNBYTESA
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x03                       ;Point 1

UknownByteB:
    ;mpgrp Utility\On-Board_Diagnostics\
    ;mptbladdr 0x208B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname UknownBytesB
    ;mptblcname UKNOWNBYTESB
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xA8                       ;Point 1

	;.org	0x8a6d
FLWMNC_FuelMonitorCorrection:
    ;mpgrp Utility\On-Board_Diagnostics\Fuel_Monitor\
    ;mptbladdr 0x2098
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname FuelMonitorCorrection
    ;mptblcname FLWMNC
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    ;mpinjscale word
    .word 0x0000                     ;Point 1

FLMNC2_FuelMonitorCorrection2:
    ;mpgrp Utility\On-Board_Diagnostics\Fuel_Monitor\
    ;mptbladdr 0x20A5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FuelMonitorCorrection2
    ;mptblcname FLMNC2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

; ***********************************************************************
; ERROR CODE MASKS
; ***********************************************************************
; Error code "masking" is implemented differently in the '89 T1 than in the earlier code.
; Instead of masking bits for the individual codes, an internal code is used to mask up to
; 7 different code bytes. The code bytes are as follows:
;
; Code #	Code					Offset (masking code)
; 61	Baro sensor open or shorted			 31
; 62	EMR mileage cannot be stored in EEPROM 		 30
; 63	Controller cannot write to EEPROM		 2f
;
; 44	Loss of FJ2					 08,2c
; 45	Nothing (overboost)				 07
; 46	Battery Volts High				 06
; 47	Battery Volts Low				 05
; 51	Lean condition					 04
; 52	Rich Condition					 03,2d
; 53	Prom Checksum					 02
; 54	Distributor Sync				 01
;
; 33	AC Cutout Relay 				 10
; 34	Speed Ctl Solenoid				 0f
; 35	Radiator Fan Relay				 0e
; 36	Wastegate Solenoid				 0d
; 37	Barometric Read Solenoid			 0c
; 41	Charging System 				 0b
; 42	Auto Shutdown Relay				 0a
; 43	Ignition Coil Control				 09,28,29,2b
;
; 22	Coolant Temp Sensor				 1e,1f
; 23	Charge Temp Sensor				 1c,1d
; 24	Throttle Position				 1a,1b
; 25	AIS Motor					 19
; 26	Injector Current Limit Not Achieved		 16,17,18
; 27	Injector Driver interface			 13,14,15
; 31	Purge Solenoid					 12
; 32	Exh Gas Recirc Solenoid 			 11,2e
;
; 11	Engine Not Cranked Since Battery Disconnected	 28
; 12	Memory Standby Power Lost			 00
; 13	MAP Pneumatic					 26,27
; 14	MAP Electrical					 24,25
; 15	Vehicle Distance Sensor 			 23
; 16	Battery Voltage Sense				 22
; 17	Engine Running Too Cool (thermostat)		 21
; 21	Oxygen Sensor					 20
;
; The "internal" or "masking" code is actually the offset used to lookup the code
; in the table 'ErrorCodesToDash_Table'
;
; The last byte MUST be 0x00, otherwise the code will result in an error.
; I think the original intent was to allow the factory calibrators to mask
; specific internal codes to try and debug errors. Previously, only the final
; error code could be masked - making the cause unclear in the case where multiple
; internal codes set the same error code.
;
; It should be possible to increase the size of the list by adding additional code
; bytes after "FLTMSK7_ErrorBitsMask7". Just make sure that the byte after the last one in
; the list remains 0x00. The mask cheking routine looks for this to mark the end of
; the list. Also, if the list is too long, it may cause lack of space for other
; items. So, be careful if adding to this list.

	;.org	0x8a6f ;<--- this signifies the original location from the dis-assy...
FLTMSK_ErrorBitsMask1:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x20F1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ErrorBitsMask1
    ;mptblcname FLTMSK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Used_to_disable_error_code_storage.
    .byte 0x00                       ;Point 1

FLTMSK2_ErrorBitsMask2:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x20FD
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ErrorBitsMask2
    ;mptblcname FLTMSK2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Used_to_disable_error_code_storage.
    .byte 0x00                       ;Point 1

FLTMSK3_ErrorBitsMask3:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x2109
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ErrorBitsMask3
    ;mptblcname FLTMSK3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Used_to_disable_error_code_storage.
    .byte 0x00                       ;Point 1

FLTMSK4_ErrorBitsMask4:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x2115
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ErrorBitsMask4
    ;mptblcname FLTMSK4
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Used_to_disable_error_code_storage.
    .byte 0x00                       ;Point 1

FLTMSK5_ErrorBitsMask5:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x2121
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ErrorBitsMask5
    ;mptblcname FLTMSK5
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Used_to_disable_error_code_storage.
    .byte 0x00                       ;Point 1

FLTMSK6_ErrorBitsMask6:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x212D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ErrorBitsMask6
    ;mptblcname FLTMSK6
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Used_to_disable_error_code_storage.
    .byte 0x00                       ;Point 1

FLTMSK7_ErrorBitsMask7:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x2139
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ErrorBitsMask7
    ;mptblcname FLTMSK7
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Used_to_disable_error_code_storage.
    .byte 0x00                       ;Point 1

FLTMSKX_ErrorBitsMaskTerminator:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x2145
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname ErrorBitsMaskTerminator
    ;mptblcname FLTMSKX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Must_be_0x00,_and_must_be_at_the_end_of_the_error_code_list.
    .byte 0x00                       ;Point 1

	;.org	0x8a77
IPLMSK_PowerLossLightMask:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x2152
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname PowerLossLightMask
    ;mptblcname IPLMSK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Illuminate_PowerLoss_Light_Mask1._These_errors_alert_the_driver.
    ;mpchoices ChargeTemp_Sensor  CoolantTemp_Sensor  Charging  bit3  BatVolts  Map_Signal  Tps_Signal  Map_Pneumatic
    .byte 0xFF                       ;Point 1

	;.org	0x8a78
IPLMSK2_PowerLossLightMask2:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x2160
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname PowerLossLightMask2
    ;mptblcname IPLMSK2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Illuminate_PowerLoss_Light_Mask2._These_errors_alert_the_driver.
    ;mpchoices bit0  bit1  bit2  Wastegate  InjectorFault  bit5  MajorFault  bit7
    .byte 0xF8                       ;Point 1

	;.org	0x8a79
PIAMSK_PIA1ADDRMask:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x216E
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname PIAMSK_PIA1ADDRMask
    ;mptblcname PIAMSK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc These_flags_enable_error_reporting_on_specific_output_bits.
    ;mpchoices Cruise_Vacuum  Purge_Solenoid  Part_Throt_Unlock  AC_Clutch_Relay  Fan_Relay  ASD_Relay  CE_Light  Cruise_Vent
    .byte 0x70                       ;Point 1

	;.org	0x8a7a
PIBMSK_PIA1BDDRMask:
    ;mpgrp Setup\Cal_Configuration\
    ;mptbladdr 0x217C
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname PIBMSK_PIA1BDDRMask
    ;mptblcname PIBMSK
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc These_flags_enable_error_reporting_on_specific_output_bits.
    ;mpchoices bit0  bit1  bit2  bit3  Emission_Light  Baro_Read_Solenoid  Wastegate_Solenoid  EGR_Solenoid
    .byte 0xDC                       ;Point 1

	;.org	0x8a7b
TTEMPL_TstatDiagnosticsMinTempToArmDiagnosticsAtStartup:
    ;mpgrp Utility\On-Board_Diagnostics\T-Stat_Diagnostics\
    ;mptbladdr 0x218A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TstatDiagnosticsMinTempToArmDiagnosticsAtStartup
    ;mptblcname TTEMPL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 deg
    ;mptbldesc Detailed_Description
    .byte 0x63                       ;Point 1

	;.org	0x8a7c
TTEMPH_TstatDiagnosticsMaxTempToArmDiagnosticsAtStartup:
    ;mpgrp Utility\On-Board_Diagnostics\T-Stat_Diagnostics\
    ;mptbladdr 0x2197
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TstatDiagnosticsMaxTempToArmDiagnosticsAtStartup
    ;mptblcname TTEMPH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 deg
    ;mptbldesc Detailed_Description
    .byte 0xE4                       ;Point 1

	;.org	0x8a7d
TDAGTP_TstatDiagnosticsTemperatureGoalWithin_HOTIME:
    ;mpgrp Utility\On-Board_Diagnostics\T-Stat_Diagnostics\
    ;mptbladdr 0x21A4
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TstatDiagnosticsTemperatureGoalWithin_HOTIME
    ;mptblcname TDAGTP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Coolant_Temp -200 260 deg
    ;mptbldesc Detailed_Description
    .byte 0xC7                       ;Point 1

	;.org	0x8a7e
HOTIME_TstatDiagnosticsTimeToAchieveTemperatureGoal:
    ;mpgrp Utility\On-Board_Diagnostics\T-Stat_Diagnostics\
    ;mptbladdr 0x21B1
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname TstatDiagnosticsTimeToAchieveTemperatureGoal
    ;mptblcname HOTIME
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xAE                       ;Point 1

	;.org	0x8a7f
BTVHYS_BatteryVoltsHysteresisForAlternatorControl:
    ;mpgrp Utility\On-Board_Diagnostics\Alternator_Diagnostics\
    ;mptbladdr 0x21BE
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BatteryVoltsHysteresisForAlternatorControl
    ;mptblcname BTVHYS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Point 1

	;.org	0x8a80
BTVLMT_BatteryVoltsDiagLimitOverTarget:
    ;mpgrp Utility\On-Board_Diagnostics\Alternator_Diagnostics\
    ;mptbladdr 0x21CB
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BatteryVoltsDiagLimitOverTarget
    ;mptblcname BTVLMT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x10                       ;Point 1

	;.org	0x8a81
BTVCNT_BatteryVoltsDiagCounterMax:
    ;mpgrp Utility\On-Board_Diagnostics\Alternator_Diagnostics\
    ;mptbladdr 0x21D8
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BatteryVoltsDiagCounterMax
    ;mptblcname BTVCNT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x8E                       ;Point 1

	;.org	0x8a82
BTVCN3_BatteryVoltsDiagCounterMin:
    ;mpgrp Utility\On-Board_Diagnostics\Alternator_Diagnostics\
    ;mptbladdr 0x21E5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BatteryVoltsDiagCounterMin
    ;mptblcname BTVCN3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x06                       ;Point 1

	;.org	0x8a83
BTVCN2_BatteryVoltsDiagCounterMax2:
    ;mpgrp Utility\On-Board_Diagnostics\Alternator_Diagnostics\
    ;mptbladdr 0x21F2
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname BatteryVoltsDiagCounterMax2
    ;mptblcname BTVCN2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x7F                       ;Point 1

	;.org	0x8a84
O2DIAG_CounterLimitForO2SensorDiag:
    ;mpgrp Utility\On-Board_Diagnostics\O2_Sensor_Diagnostics\
    ;mptbladdr 0x21FF
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname CounterLimitForO2SensorDiag
    ;mptblcname O2DIAG
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x13                       ;Point 1

	;.org	0x8a85
O2MID_LimitForO2SensorBatteryDiag:
    ;mpgrp Utility\On-Board_Diagnostics\O2_Sensor_Diagnostics\
    ;mptbladdr 0x220C
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname LimitForO2SensorBatteryDiag
    ;mptblcname O2MID
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x4D                       ;Point 1

	;.org	0x8a86
O2MIDX_HighLimitForInMiddleDeterminationX:
    ;mpgrp Utility\On-Board_Diagnostics\O2_Sensor_Diagnostics\
    ;mptbladdr 0x2219
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname HighLimitForInMiddleDeterminationX
    ;mptblcname O2MIDX
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x3E                       ;Point 1

	;.org	0x8a87
DCLMER_MinTimeEngineRunningForDecelFuelShutoff:
    ;mpgrp Fuel\Decel_Fuel_Shutoff\
    ;mptbladdr 0x2226
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinTimeEngineRunningForDecelFuelShutoff
    ;mptblcname DCLMER
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x02                       ;Point 1

	;.org	0x8a88
DCLMCT_MinCoolantTempForDecelFuelShutoff:
    ;mpgrp Fuel\Decel_Fuel_Shutoff\
    ;mptbladdr 0x2233
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname MinCoolantTempForDecelFuelShutoff
    ;mptblcname DCLMCT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xD2                       ;Point 1

	;.org	0x8a89
DCLRPH_EngineRPMLimitForDecelFuelShutoffHigh:
    ;mpgrp Fuel\Decel_Fuel_Shutoff\
    ;mptbladdr 0x2240
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EngineRPMLimitForDecelFuelShutoffHigh
    ;mptblcname DCLRPH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc High_RPM_to_activate_decel_fuel_shutoff._Should_be_lower_than_shutoff_RPM_Off_point.
    .byte 0x11                       ;Point 1

	;.org	0x8a8a
DCLRPL_EngineRPMLimitForDecelFuelShutoffLow:
    ;mpgrp Fuel\Decel_Fuel_Shutoff\
    ;mptbladdr 0x224D
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname EngineRPMLimitForDecelFuelShutoffLow
    ;mptblcname DCLRPL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Low_RPM_to_activate_decel_fuel_shutoff._Should_be_lower_than_shutoff_RPM_On_point.
    .byte 0x0F                       ;Point 1

	;.org	0x8a8b
DCAISI_AISIncrementWhenUsingDecelFuelShut:
    ;mpgrp Fuel\Decel_Fuel_Shutoff\
    ;mptbladdr 0x225A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname AISIncrementWhenUsingDecelFuelShut
    ;mptblcname DCAISI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc AIS_Increment_for_recovery_from_decel_fuel_shutoff.
    .byte 0x00                       ;Point 1

	;.org	0x8a8c
DFRPMH_DecelFuelShutoffDeltaRPMOff:
    ;mpgrp Fuel\Decel_Fuel_Shutoff\
    ;mptbladdr 0x2267
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DecelFuelShutoffDeltaRPMOff
    ;mptblcname DFRPMH
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPMOverIdle 0 8192 rpm
    ;mptbldesc Decel_fuel_shutoff_RPM_over_Idle_off_point.
    .byte 0x1E                       ;Point 1

	;.org	0x8a8d
DFRPML_DecelFuelShutoffDeltaRPMOn:
    ;mpgrp Fuel\Decel_Fuel_Shutoff\
    ;mptbladdr 0x2274
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname DecelFuelShutoffDeltaRPMOn
    ;mptblcname DFRPML
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPMOverIdle 0 8192 rpm
    ;mptbldesc Decel_fuel_shutoff_RPM_over_Idle_on_point.
    .byte 0x11                       ;Point 1

	;.org	0x8a8e
VOBMAP_VNTOverboostSampleCounterMAP:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x2281
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterMAP
    ;mptblcname VOBMAP
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0xFE                       ;Point 1

	;.org	0x8a8f
VOBCT_VNTOverboostSampleCounterCoolantTemp:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x228E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterCoolantTemp
    ;mptblcname VOBCT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x58                       ;Point 1

	;.org	0x8a90
VOBTPS_VNTOverboostSampleCounterTPS:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x229B
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterTPS
    ;mptblcname VOBTPS
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x10                       ;Point 1

	;.org	0x8a91
VOBSCI_VNTOverboostSampleCounterIncr:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x22A8
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterIncr
    ;mptblcname VOBSCI
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x02A0                     ;Point 1

	;.org	0x8a93
VOBSCL_VNTOverboostSampleCounterLimit:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x22B5
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterLimit
    ;mptblcname VOBSCL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0002                     ;Point 1

	;.org	0x8a95
VOBSCD_VNTOverboostSampleCounterDecr:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x22C2
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterDecr
    ;mptblcname VOBSCD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0006                     ;Point 1

	;.org	0x8a97
VOBSCL2_VNTOverboostSampleCounterLimit2:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x22CF
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterLimit2
    ;mptblcname VOBSCL2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0001                     ;Point 1

	;.org	0x8a99
VOBSCL3_VNTOverboostSampleCounterLimit3:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x22DC
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterLimit3
    ;mptblcname VOBSCL3
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0200                     ;Point 1

	;.org	0x8a9b
VOBSCI2_VNTOverboostSampleCounterIncr2:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x22E9
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterIncr2
    ;mptblcname VOBSCI2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0002                     ;Point 1

	;.org	0x8a9d
VOBSCD2_VNTOverboostSampleCounterDecr2:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x22F6
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname VNTOverboostSampleCounterDecr2
    ;mptblcname VOBSCD2
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .word 0x0001                     ;Point 1

	;.org	0x8a9f
VOBRPX_VNTOverboostFuelAddedFromRPMWhenOverboosting:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x2303
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname VNTOverboostFuelAddedFromRPMWhenOverboosting
    ;mptblcname VOBRPX
    ;mpxaxis EngineRPM 0 8192 rpm
    ;mpyaxis Scale 0 100 percent
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x80                 ;Point 1

;        .byte   0x80

	;.org	0x8ab6
ADRMRP_AdvanceRemovedFromRPMForDwellCalculation:
    ;mpgrp Spark\Normal_Advance\
    ;mptbladdr 0x2313
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname AdvanceRemovedFromRPMForDwellCalculation
    ;mptblcname ADRMRP
    ;mpxaxis RPM 0 8192 rpm
    ;mpyaxis Advance 0 128 deg
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Number of points in table
    .byte 0xFF, 0x14                 ;Point 1
	
; DWLADB_DwellTime_AdjForBatVolts:
;        chem2 group "Setup - Transfer Functions"
;        .chem 1 n DwellTime_AdjForBatVolts BatVolts 0 16 Volts DwellTime 0 255 uSec DWLADB DwellTime_AdjForBatVolts
;        chem2 table DWLADB simple use "BatVolts" 0 16 "Volts" use "DwellTime" 0 255 "uSec" "DwellTime AdjForBatVolts"
;        .byte   0x82                              ; point 1
;        .word   0xE609,  0x4059
;        .byte   0xAA                              ; point 2
;        .word   0xF017,  0x2908
;        .byte   0xC8                              ; point 3
;        .word   0xF4E6,  0x138C
;        .byte   0xDC                              ; point 4
;        .word   0xF66D,  0x1100
;        .byte   0xF0                              ; point 5
;        .word   0xF7C1,  0x0C55
;        .byte   0xFF


	;.org	0x8acd
L8ACE_L8ace:
    ;mpgrp Fuel\Running\
    ;mptbladdr 0x2332
    ;mptbltype 9
    ;mpsubtype n
    ;mptbllname L8ACE_L8ace
    ;mptblcname L8ACE
    ;mpxaxis in_desc 4 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x01                       ;Point 1
    .byte 0xFF                       ;Point 2
    .byte 0x52                       ;Point 3
    .byte 0xFF                       ;Point 4

	;.org	0x8ad8
OBSMPL_OverboostSampleThreshold:
    ;mpgrp Boost_Control\VNT_Control\
    ;mptbladdr 0x2342
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname OverboostSampleThreshold
    ;mptblcname OBSMPL
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis DeltaMAP 0 29.4 psi
    ;mptbldesc Detailed_Description
    ;mpmapaxis y
    .byte 0x84                       ;Point 1

	;.org	0x8ae0
FastDataOutputCommandByte:
    ;mpgrp Setup\DRB_Datalogging\
    ;mptbladdr 0x2350
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FastDataOutputCommandByte
    ;mptblcname FASTDT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x18                       ;Point 1

	;.org	0x8ae1
FastDataOutputAddressTable:
    ;mpgrp Setup\DRB_Datalogging\
    ;mptbladdr 0x235D
    ;mptbltype 9
    ;mpsubtype n
    ;mptbllname FastDataOutputAddressTable
    ;mptblcname FASTDA
    ;mpxaxis in_desc 30 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1
    .byte 0x00                       ;Point 2
    .byte 0x00                       ;Point 3
    .byte 0x00                       ;Point 4
    .byte 0x00                       ;Point 5
    .byte 0x00                       ;Point 6
    .byte 0x00                       ;Point 7
    .byte 0x00                       ;Point 8
    .byte 0x00                       ;Point 9
    .byte 0x00                       ;Point 10
    .byte 0x00                       ;Point 11
    .byte 0x00                       ;Point 12
    .byte 0x00                       ;Point 13
    .byte 0x00                       ;Point 14
    .byte 0x00                       ;Point 15
    .byte 0x00                       ;Point 16
    .byte 0x00                       ;Point 17
    .byte 0x00                       ;Point 18
    .byte 0x00                       ;Point 19
    .byte 0x00                       ;Point 20
    .byte 0x00                       ;Point 21
    .byte 0x00                       ;Point 22
    .byte 0x00                       ;Point 23
    .byte 0x00                       ;Point 24
    .byte 0x00                       ;Point 25
    .byte 0x00                       ;Point 26
    .byte 0x00                       ;Point 27
    .byte 0x00                       ;Point 28
    .byte 0x00                       ;Point 29
    .byte 0x00                       ;Point 30

	;.org	0x8aff
FastDataOutTerminator:
    ;mpgrp Setup\DRB_Datalogging\
    ;mptbladdr 0x2387
    ;mptbltype 9
    ;mpsubtype n
    ;mptbllname FastDataOutTerminator
    ;mptblcname FASTTM
    ;mpxaxis in_desc 1 255 in
    ;mpyaxis Y 0 255 out
    ;mptbldesc Detailed_Description
    .byte 0x00                       ;Point 1

; data moved to data section from code section
TMPTL1_TempForColdScaleFromA2D:
    ;mpgrp Setup\Transfer_Functions\
    ;mptbladdr 0x2394
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname TempForColdScaleFromA2D
    ;mptblcname TMPTL1
    ;mpxaxis raw 0 255 scale
    ;mpyaxis Coolant_Temperature -200 260 F
    ;mptbldesc Detailed_Description
    .byte 0x07                       ;Number of points in table
    .byte 0x00, 0xD3, 0xFF, 0x85     ;Point 1
    .byte 0x53, 0xAB, 0xFF, 0x9D     ;Point 2
    .byte 0xD7, 0x78, 0xFF, 0x55     ;Point 3
    .byte 0xE6, 0x6E, 0xFF, 0x17     ;Point 4
    .byte 0xF1, 0x64, 0xFE, 0xCD     ;Point 5
    .byte 0xF6, 0x5E, 0xFD, 0xAB     ;Point 6
    .byte 0xFF, 0x49                 ;Point 7

	;;.org	0x88a7
TMPTL2_TempForHotScaleA2D:
    ;mpgrp Setup\Transfer_Functions\
    ;mptbladdr 0x23A8
    ;mptbltype 0
    ;mpsubtype n
    ;mptbllname TempForHotScaleA2D
    ;mptblcname TMPTL2
    ;mpxaxis raw 0 255 scale
    ;mpyaxis Coolant_Temperature -200 260 F
    ;mptbldesc Detailed_Description
    .byte 0x04                       ;Number of points in table
    .byte 0x42, 0xFF, 0xFF, 0x55     ;Point 1
    .byte 0x57, 0xF1, 0xFF, 0x75     ;Point 2
    .byte 0xC5, 0xB5, 0xFF, 0x4F     ;Point 3
    .byte 0xFF, 0x8D                 ;Point 4
       
MINAMP_MinimumAverageMAP:
    ;mpgrp Setup\Transfer_Functions\
    ;mptbladdr 0x23B8
    ;mptbltype 3
    ;mpsubtype 1
    ;mptbllname MinimumAverageMAP
    ;mptblcname MINAMP
    ;mpxaxis IN 0 255 X
    ;mpyaxis PSI 0 29.4 psi
    ;mptbldesc Minimum_value_for_the_MAP_averaging_function.
    ;mpmapaxis y
    .byte 0x06                       ;Point 1

KNKMIN_FlashCEMinTemp:
    ;mpgrp Turbonator\CEL_Knock_Indicator\
    ;mptbladdr 0x23C5
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname FlashCEMinTemp
    ;mptblcname KNKMIN
    ;mpxaxis IN 0 255 X
    ;mpyaxis CoolantTemp -200 260 deg
    ;mptbldesc The_min_temp_allowed_before_the_CE_light_is_flashed._To_avoid_false_indication_on_a_cold_engine.
    .byte 0xA8                       ;Point 1

MAPMULT_ScaleMAPVoltsToPresMultiplyConst:
    ;mpgrp Setup\Transfer_Functions\
    ;mptbladdr 0x23D1
    ;mptbltype 8
    ;mpsubtype 1
    ;mptbllname ScaleMAPVoltsToPresMultiplyConst
    ;mptblcname MAPMULT
    ;mpxaxis IN 0 255 X
    ;mpyaxis OUT 0 255 Y
    ;mptbldesc Map_Scale_multiplier._This_is_the_slope_constant_for_the_MAP_sensor_transfer_function._#07_is_the_original_Mopar_2-bar_constant._#09_for_the_S60_3-bar_sensor._The_GM_or_MSD_3-Bar_sensors_may_need_these_values_changed_for_accuracy.
    ;mpchoices 1.0_Bar 07 1.5_Bar 07 2.0_Bar 07 2.5_Bar 08 3.0_Bar 09 3.5_Bar 09 4.0_Bar 09 4.5_Bar 09
    ;mpmapaxis b
    .byte 0x07                       ;Point 1

MAPADD_ScaleMAPVoltsToPresAddConst:
    ;mpgrp Setup\Transfer_Functions\
    ;mptbladdr 0x23DF
    ;mptbltype 8
    ;mpsubtype 1
    ;mptbllname ScaleMAPVoltsToPresAddConst
    ;mptblcname MAPADD
    ;mpxaxis IN 0 255 X
    ;mpyaxis OUT 0 255 Y
    ;mptbldesc Scale_MAP_Volts_to_MAP_add_constant:_This_is_the_offset_constant_for_the_MAP_sensor_transfer_function._#0361_is_the_original_Mopar_2-bar_constant._#0700_for_the_S60_3-bar_sensor._The_GM_or_MSD_3-Bar_sensors_may_need_these_values_changed_for_accuracy.
    ;mpchoices 1.0_Bar 0361 1.5_Bar 0361 2.0_Bar 0361 2.5_Bar 0700 3.0_Bar 0700 3.5_Bar 0700 4.0_Bar 0700 4.5_Bar 0700
    ;mpmapaxis w
    .word 0x0361                     ;Point 1

ANTLAG_AntiLagRetardfromBoostGoalDelta:
    ;mpgrp Spark\Anti-Lag_Retard\
    ;mptbladdr 0x23ED
    ;mptbltype 0
    ;mpsubtype 1
    ;mptbllname AntiLagRetardfromBoostGoalDelta
    ;mptblcname ANTLAG
    ;mpxaxis DeltaMAP 0 29.4 psi
    ;mpyaxis Spark_Retard 0 8 Degrees
    ;mptbldesc Curve_for_retard_based_on_delta_MAP_for_anti-lag_feature._This_will_be_subtracted_from_the_calculated_spark_advance.
    ;mpmapaxis x
    .byte 0x05                       ;Number of points in table
    .byte 0x12, 0x00, 0x02, 0x22     ;Point 1
    .byte 0x30, 0x40, 0x01, 0x11     ;Point 2
    .byte 0x4E, 0x60, 0x00, 0x8E     ;Point 3
    .byte 0x79, 0x78, 0x00, 0x26     ;Point 4
    .byte 0xAE, 0x80                 ;Point 5
       
SLRPM_ShiftLightSetpoint:
    ;mpgrp Turbonator\Shift_Light\
    ;mptbladdr 0x23FF
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname ShiftLightSetpoint
    ;mptblcname SLRPM
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Shift_light_setpoint.
    .word 0x9B00                     ;Point 1

; SLSETP1_ShiftLightSetpoint1_2:
;        chem2 group "Turbonator - Shift Light"
;        .chem 4 n ShiftLightSetpoint1-2 in_desc 0 255 in RPM 0 8192 rpm SLSETP1 Shift_light_setpoint_for_the_1-2_shift.
;        chem2 word SLSETP1 "Shift light setpoint for the 1-2 shift."
;        .word   0x9B00
; 
; SLSETP2_ShiftLightSetpoint2_3:
;        chem2 group "Turbonator - Shift Light"
;        .chem 4 n ShiftLightSetpoint2-3 in_desc 0 255 in RPM 0 8192 rpm SLSETP2 Shift_light_setpoint_for_shifts_2-3_and_higher.
;        chem2 word SLSETP2 "Shift light setpoint for shifts 2-3 and higher."
;        .word   0x9E00
; 
; SLSPAC_ShiftLightMinorSpacingInRPM:
;        chem2 group "Turbonator - Shift Light"
;        .chem 4 n ShiftLightMinorSpacingInRPM in_desc 0 255 in RPM 0 8192 rpm SLSPAC Spacing_in_RPM_for_the_minor_shift_lights.
;        chem2 word SLSPAC "Spacing in RPM for the minor shift lights."
;        .word   0x0320
; 
; SLDURN_ShiftLightMinorDurationInRPM:
;        chem2 group "Turbonator - Shift Light"
;        .chem 4 n ShiftLightMinorDurationInRPM in_desc 0 255 in RPM 0 8192 rpm SLDURN Duration_in_RPM_for_the_minor_shift_lights.
;        chem2 word SLDURN "Duration in RPM for the minor shift lights."
;        .word   0x0118
;
; SLDELT_DeltaRPMToDetectShift:
;        chem2 group "Turbonator - Shift Light"
;        .chem 4 n DeltaRPMToDetectShift in_desc 0 255 in RPM 0 8192 rpm SLDELT Delta_RPM_to_determine_if_a_shift_occured.
;        chem2 word SLDELT "Delta RPM to determine if a shift occured."
;        .word   0x12C0

STGSWS_StagingLimiterEnableSwitch:
    ;mpgrp Turbonator\Staging_Limiter\
    ;mptbladdr 0x2429
    ;mptbltype 5
    ;mpsubtype n
    ;mptbllname StagingLimiterEnableSwitch
    ;mptblcname STGSWS
    ;mpxaxis IN 0 255 X
    ;mpyaxis OUT 0 255 Y
    ;mptbldesc Switch_that_will_activate_the_staging_limiter.
    ;mpchoices B1Voltage_Sense(Do_Not_Use)  Speed_Control_Set_(Momentary)  Speed_Control_On/Off  Speed_Control_Resume_(Momentary)  A/C_Switch  A/C_Clutch_Input(Do_Not_Use)  Brake_Switch  Park/Neutral_Switch
    .byte 0x00                       ;Point 1
    stg_PNswitch		= $%10000000	; Park/Neutral switch
    stg_Brake			= $%01000000	; Brake Switch
    stg_DistSync		= $%00100000	; Distributor Sync
    stg_ACclutch		= $%00010000	; A/C Clutch input
    stg_CruiseResume		= $%00001000	; Cruise Resume
    stg_CruiseOnOff		= $%00000100	; Cruise On/Off
    stg_CruiseSet		= $%00000010	; Cruise Set
    stg_B1Volt			= $%00000001	; B1 Voltage Sense

STGSPD_StageLimiterCutoffSpeed:
    ;mpgrp Turbonator\Staging_Limiter\
    ;mptbladdr 0x243E
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname StageLimiterCutoffSpeed
    ;mptblcname STGSPD
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis Speed 0 255 mph
    ;mptbldesc Detailed_Description
    .byte 0x0A                       ;Point 1

STGROF_StageLimiterRPMOffSetpoint:
    ;mpgrp Turbonator\Staging_Limiter\
    ;mptbladdr 0x244A
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname StageLimiterRPMOffSetpoint
    ;mptblcname STGROF
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x7D                       ;Point 1

STGRON_StageLimiterRPMOnSetpoint:
    ;mpgrp Turbonator\Staging_Limiter\
    ;mptbladdr 0x2456
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname StageLimiterRPMOnSetpoint
    ;mptblcname STGRON
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis RPM 0 8192 rpm
    ;mptbldesc Detailed_Description
    .byte 0x77                       ;Point 1
       
WOTBAT_WOTBatteryVoltsTarget:
    ;mpgrp Turbonator\Voltage_Regulator\
    ;mptbladdr 0x2462
    ;mptbltype 3
    ;mpsubtype n
    ;mptbllname WOTBatteryVoltsTarget
    ;mptblcname WOTBAT
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis BatVolts 0 16.2 V
    ;mptbldesc Battery_volts_target_when_at_WOT.
    .byte 0xEC                       ;Point 1
       
SRCID_SourceCodeVersionID:
    ;mpgrp Setup\Cal_ID\
    ;mptbladdr 0x246E
    ;mptbltype 4
    ;mpsubtype n
    ;mptbllname SourceCodeVersionID
    ;mptblcname SRCID
    ;mpxaxis in_desc 0 255 in
    ;mpyaxis out_desc 0 255 out
    ;mptbldesc Desc
    .word 0x0C03                     ;Point 1
    ;mp******************************
    ;mpcodebase 0A T-LM
    ;mpcodebase 0B T-SMEC
    ;mpcodebase 0C T-SBEC
    ;mpcodebase 0D T-TIII_(91)
    ;mpcodebase 0E T-TIII_(92-93)
    ;mp******************************

; I replaced the hutsville tester codes with the Source code version ID so that I can always see what version of the codebase
; the cal is based on. This may be similar functionality to the original, though I don't know the meaning of the Huntsville codes.
;
; Codes:
;
; The first byte is the codebase type (LM, SMEC, SBEC, etc.)
;
; a = T-LM
; b = T-SMEC
; c = T-SBEC
; d = T-TIII (91)
; e = T-TIII (92-93)
; f = ??
;
; The 2nd byte is the source code version in HEX. For example:
; 0x10 = 16dec = version 16


        .msg "Complete." ; these are just messages to display during assemble to let you know what's going on...


