	.title 1987 TurbonatorGLHSv1
	.area ROM (ABS)
; Mopar ECM - 68HC11 Disassembly
; 
; Custom disassembler
; Copyright � 2012 by Robert Lloyd.
; www.boostbutton.com
;  ____________________________________________________________________________
; /                                                                            \
; |   '86 T2 Turbonator GLHS codebase                                          |
; |   Mopar ECM                                                                |
; |   1986 Turbo II                                                            |
; |                                                                            |
; | Code and original design and data Copyright 1985 by Chrysler Corporation   |
; |                                                                            |
; | Other code modules are Copyright 2012 by Robert Lloyd		       |
; |                                                                            |
; |                                              			       |
; | 1) Replaced TRANSM with CONFIG - a full cal option flag constant similar   |
; |    to the CONFIG constant + OPTION flags used on the '89 T1. Changed all   |
; |    of the auto trans checks to look for the 'new' auto config flag. All    |
; |    of the new and previous cal options are configurable by config flags.   |
; |    This allows features to be added to the cal without the need to         |
; |    re-assemble the code.                                                   |
; |                                                                            |
; | 2) Added switchable boost. Similar in operation to the later code, but the |
; |    low setting is set by a single constant rather than a boost x rpm       |
; |    table (similar to the S60 implementation).                              |
; |                                                                            |
; | 3) Added Anti-lag Retard routine. This routine looks at the delta to boost |
; |    goal and pulls up to 16 deg based on this delta (could be configured    |
; |    for 32 degrees as well). It will only pull timing at WOT (and so should |
; |    no affect emmisions or driveability) except when the staging limiter is |
; |    active to help spoolup off the line for manual cars. There were some    |
; |    code changes to the staging limiter code to support this function. But  |
; |    the functionality of the staging limiter is the same as previous.       |
; |                                                                            |
; | 4) Staging Limiter Changes. Re-coded for simplicity. Added the option to   |
; |    enable the staging limiter by switch. Default is setup for the brake    |
; |    switch (useful for ATX cars).                                           |
; \___________________________________________________________________________/

; ***********************************************************************
;
; Version 1
; 06/28/12 - First release.
;          - Turbonator routines carried over from T/LM
;
;
; ***********************************************************************

version == 1
LowerChipOrg == 0xa000
DataOrg == 0xe000
UpperChipCodeOrg == 0xe600

.define CalDataFile /C:\Users\Rob\Dropbox\BoostButton\Products\Cal Data\Source Files\86 GLHS Master\T-GLHS_t2_mtx_640_STGII_3-bar.tpl/


CPU_Port1_DataDirection	 == 0x0000
CPU_Port2_DataDirection	 == 0x0001
CPU_Port1_ControlRegister	 == 0x0002
    CPU_P1Ctrl_KnockCap		= $%10000000	;
    CPU_P1Ctrl_Injector		= $%01000000	;
    CPU_P1Ctrl_PwrLoss		= $%00100000	;
    CPU_P1Ctrl_VoltReg		= $%00010000	;
    CPU_P1Ctrl_CTSBias		= $%00001000	;
    CPU_P1Ctrl_Inj34		= $%00000100	;
    CPU_P1Ctrl_Inj12	        = $%00000010	;
    CPU_P1Ctrl_SpeedSens	= $%00000001	;

; Pin   Mask    Bit Function            LM Pin
; 20    x80     7   knock kill (int)
; 19    x40     6   injector (int)
; 18    x20     5   power loss light    R4
; 17    x10     4   voltage reg
; 16    x08     3   cts bias (int)      R5
; 15    x04     2   injector 3-4        R3
; 14    x02     1   injector 1-2        R2
; 13    x01     0   speed sensor        R9

CPU_Port2_ControlRegister	 == 0x0003
    CPU_P2Ctrl_Bit7		= $%10000000	;
    CPU_P2Ctrl_Bit6		= $%01000000	;
    CPU_P2Ctrl_Bit5		= $%00100000	;
    CPU_P2Ctrl_SCITx		= $%00010000	;
    CPU_P2Ctrl_SCIRx		= $%00001000	;
    CPU_P2Ctrl_Bit2		= $%00000100	;
    CPU_P2Ctrl_AntiDwell	= $%00000010	;
    CPU_P2Ctrl_DistrRef		= $%00000001	;

; Pin   Mask    Bit Function            LM Pin
;       x80     7
;       x40     6
;       x20     5
; 12    x10     4   sci tx              R11
; 11    x08     3   sci rx              R13
; 10    x04     2   serial clock?
; 9     x02     1   anti-dwell          R6      anti-dwell on = spark, off = no spark
; 8     x01     0   dist reference      R10

CPU_PortX_DataDirection	                == 0x0004
CPU_PortY_DataDirection	                == 0x0005
CPU_PortX_ControlRegister	        == 0x0006
CPU_PortY_ControlRegister	        == 0x0007
CPU_TimerControlStatReg	                == 0x0008
CPU_Counter_HB	                        == 0x0009
CPU_Counter_LB	                        == 0x000a
CPU_OCR_HB	                        == 0x000b
CPU_OCR_LB	                        == 0x000c
CPU_ICR_HB	                        == 0x000d  ; used for distributor sync timer
CPU_ICR_LB	                        == 0x000e
CPU_PortX_ControlStatReg	        == 0x000f
CPU_SCI_ModeControlReg	                == 0x0010
CPU_SCI_TxRxCntrlReg	                == 0x0011
CPU_SCI_RxDataReg	                == 0x0012
CPU_SCI_TxDataReg	                == 0x0013
CPU_RAM_ControlReg	                == 0x0014
CPU_Count_Alt_HB	                == 0x0015
CPU_Count_Alt_LB	                == 0x0016
CPU_TimerControl1	                == 0x0017
CPU_TimerControl2	                == 0x0018
CPU_TimerStatus	                        == 0x0019
CPU_OCR2_HB	                        == 0x001a
CPU_OCR2_LB	                        == 0x001b
CPU_OCR3_HB	                        == 0x001c
CPU_OCR3_LB	                        == 0x001d
CPU_ICR2_HB	                        == 0x001e
CPU_ICR2_LB	                        == 0x001f

;  ______________________
; |                      \
; |   Memory             |
; \______________________|

; Battery-Backed RAM:

MINTHR_LowestSessionTPS	         == 0x0040
Timer_DacalCountdown	         == 0x0041
CurrentAisPosition	         == 0x0042
DCCOR1_AdaptiveWastegateCellBelowMAPPT	 == 0x0043
DCCOR2_AdaptiveWastegateCellAboveMAPPT	 == 0x0044
LowestHistoricalTPS	         == 0x0045
AutoCalCell0	                 == 0x0046
AutoCalCell1	                 == 0x0047
AutoCalCell2	                 == 0x0048
AutoCalCell3	                 == 0x0049
AutoCalCell4	                 == 0x004a
AutoCalCell5	                 == 0x004b
AutoCalCell6	                 == 0x004c
AutoCalCell7	                 == 0x004d
AutoCalCell8	                 == 0x004e
AutoCalCell9	                 == 0x004f
AutoCalCell10	                 == 0x0050
AutoCalCell11	                 == 0x0051
AutoCalCell12	                 == 0x0052
ErrorBitRegister0	         == 0x0053
    flg_errLostFJ2		= $%10000000	; 44 Loss of FJ2
    flg_errNothing		= $%01000000	; 45 Nothing (overboost)
    flg_errHighVoltage		= $%00100000	; 46 Battery Volts High
    flg_errLowVoltage		= $%00010000	; 47 Battery Volts Low
    flg_errStuckLean		= $%00001000	; 51 Lean condition
    flg_errStuckRich		= $%00000100	; 52 Rich Condition
    flg_errChecksum		= $%00000010	; 53 Prom Checksum
    flg_errDistSync		= $%00000001	; 54 Distributor Sync
ErrorBitRegister1	         == 0x0054
    flg_errAcCutoutRelay	= $%10000000	; 33 AC Cutout Relay
    flg_errSpeedCtlSolenoid	= $%01000000	; 34 Speed Ctl Solenoid
    flg_errRadFanRelay		= $%00100000	; 35 Radiator Fan Relay
    flg_errWastegateSolenoid	= $%00010000	; 36 Wastegate Solenoid
    flg_errBaroReadSolenoid	= $%00001000	; 37 Barometric Read Solenoid
    flg_errChargingSystem	= $%00000100	; 41 Charging System
    flg_errASDRelay		= $%00000010	; 42 Auto Shutdown Relay
    flg_errIgnitionCoil 	= $%00000001	; 43 Ignition Coil Control
ErrorBitRegister2	         == 0x0055
    flg_errCoolantTempSensor	= $%10000000	; 22 Coolant Temp Sensor
    flg_errChargeTempSensor	= $%01000000	; 23 Charge Temp Sensor
    flg_errTPS			= $%00100000	; 24 Throttle Position
    flg_errAIS			= $%00010000	; 25 AIS Motor
    flg_errInjectorCurrent	= $%00001000	; 26 Injector Current Limit Not Achieved
    flg_errInjectorDriver	= $%00000100	; 27 Injector Driver interface
    flg_errPurgeSolenoid	= $%00000010	; 31 Purge Solenoid
    flg_errEGR		        = $%00000001	; 32 Exh Gas Recirc Solenoid
ErrorBitRegister3	         == 0x0056
    flg_errNotCranked		= $%10000000	; 11 Engine Not Cranked Since Battery Disconnected
    flg_errMemPowerLost 	= $%01000000	; 12 Memory Standby Power Lost
    flg_errMapPneumatic 	= $%00100000	; 13 MAP Pneumatic
    flg_errMapElectrical	= $%00010000	; 14 MAP Electrical
    flg_errDistanceSensor	= $%00001000	; 15 Vehicle Distance Sensor
    flg_errBattVoltageSense	= $%00000100	; 16 Battery Voltage Sense
    flg_errEngineTooCool	= $%00000010	; 17 Engine Running Too Cool (thermostat)
    flg_errO2Sensor		= $%00000001	; 21 Oxygen Sensor
ErrorBitRegisterStored0	         == 0x0057
ErrorBitRegisterStored1	         == 0x0058
ErrorBitRegisterStored2	         == 0x0059
ErrorBitRegisterStored3	         == 0x005a
SlowCounter	                 == 0x005b
AISMotorBits	                 == 0x005c
BitFlags_5D	                 == 0x005d
BitFlags_AIS	                 == 0x005e
     flg_bit7			= $%10000000	;
     flg_bit6			= $%01000000	;
     flg_UseAIS		        = $%00100000	;
     flg_bit4			= $%00010000	;
     flg_ATXInGear		= $%00001000	;Auto in gear
     flg_ATXChngGear		= $%00000100	;Auto just changed gears
     flg_bit1			= $%00000010	;
     flg_bit0			= $%00000001	;

ClearTheErrorTimer_0	         == 0x005f

; Volatile RAM:

ClearTheErrorTimer_1	         == 0x0060
VehicleSpeed_HB	                 == 0x0061
VehicleSpeed_LB	                 == 0x0062
StackPtrTemp_HB	                 == 0x0063
StackPtrTemp_LB	                 == 0x0064
TimerOverflowsBetweenDistPulses	 == 0x0065
DistributorFallingEdgePulsewidth_HB	 == 0x0066
DistributorFallingEdgePulsewidth_LB	 == 0x0067
Counter_TimerPastHalfwayBetweenDistPulses	 == 0x0068
Timer_FuelMonitorOutputTimer_HB	 == 0x0069
Timer_FuelMonitorOutputTimer_LB	 == 0x006a
LastDistributorFallingEdgeTime_HB	 == 0x006b
LastDistributorFallingEdgeTime_LB	 == 0x006c
BitFlags_6d	                 == 0x006d
    flg_EngineKnocking          = $%10000000    ; Engine has knocked
    flg_MapOutOfRange           = $%01000000    ; MAP error ?
    flg_bit5                    = $%00100000    ; Staging Limiter Active
    flg_bit4                    = $%00010000    ; Boost Above 5psi
    flg_bit3                    = $%00001000    ; Dist Sync Error?
    flg_bit2                    = $%00000100    ; Wastegate Control
    flg_bit1                    = $%00000010    ; injector circuit 3-4
    flg_bit0                    = $%00000001    ; injector circuit 1-2
; or, the bottom two bits are the current cylinder as 1-4-2-3
BitFlags_6e	                 == 0x006e
    flg_OffIdle                 = $%10000000    ; Throttle Pressed (off idle)
    flg_LowTpsUpdated           = $%01000000    ; LowestHistoricalTPS has been updated
    flg_bit5                    = $%00100000    ;   ? Oxygen Sensor Stuck?
    flg_bit4                    = $%00010000    ; Oxygen Sensor Has Been Outside .75V to .29V Range (Thus is returning a signal)
    flg_bit3                    = $%00001000    ; Throttle below half
    flg_O2Rich                  = $%00000100    ; Oxygen Sensor data currently not valid (just after starting)
    flg_bit1                    = $%00000010    ;   ? WHEN SET, DOESNT DO CLOSED LOOP STUFF? DOES CHECK RAM0077
    flg_FullThrottle            = $%00000001    ; Throttle Floored (full throttle)
BitFlags_6f	                 == 0x006f
    flg_EngineNotRunning        = $%10000000    ; ENGINE RUNNING = 0, Engine not running = 1
    flg_DistSync                = $%01000000    ;
    flg_FuelRunMode             = $%00100000    ; Fuel Mode: 1 = Running, 0 = Starting
    flg_bit4                    = $%00010000    ; baro read processing done
    flg_DecayingFuelStartToRun  = $%00001000    ; 1 if still decaying fuel from start to run
    flg_SearchBladeEndRef_INSYNC = $%00000100   ; Search for end of window blade on Reference Signal
    flg_DisableNormalDwell      = $%00000010    ; Spark Mode: 1 = Starting, 0 = Running
    flg_bit0                    = $%00000001    ;   ? O2 sensor known bad
BitFlags_70	                 == 0x0070
BitFlags_71	                 == 0x0071
    flg_bit7                    = $%10000000    ; Open
    flg_bit6                    = $%01000000    ; Open
    flg_bit5                    = $%00100000    ; Maybe Used
    flg_bit4                    = $%00010000    ;   ? ASD circuit set (code 42)
    flg_bit3                    = $%00001000    ;   ? Injector 2 circuit failure (code 27)
    flg_bit2                    = $%00000100    ;   ? Injector 1 circuit failure (code 26)
    flg_bit1                    = $%00000010    ; Cruise Control Enabled
    flg_bit0                    = $%00000001    ; Used, Speedo interupt
BitFlags_72	                 == 0x0072
    flg_bit7                    = $%10000000    ; Engine has knocked
    flg_MapOutOfRange           = $%01000000    ; MAP error ?
    flg_bit5                    = $%00100000    ; Staging Limiter Active
    flg_bit4                    = $%00010000    ; Boost Above 5psi
    flg_bit3                    = $%00001000    ; Dist Sync Error?
    flg_bit2                    = $%00000100    ; Wastegate Control
    flg_bit1                    = $%00000010    ; injector circuit 3-4
    flg_bit0                    = $%00000001    ; injector circuit 1-2
TargetIdleSpeed_HB	         == 0x0073
TargetIdleSpeed_LB	         == 0x0074
KeyOnOrEngineRunningTime	 == 0x0075
Counter_MainLoop	         == 0x0076
SumOfFuelModifiers_HB	         == 0x0077
SumOfFuelModifiers_LB	         == 0x0078
InjectorPulsewidth_HB	         == 0x0079
InjectorPulsewidth_LB	         == 0x007a
Pulsewidth_PartThrottleEnrichment_HB	 == 0x007b
Pulsewidth_PartThrottleEnrichment_LB	 == 0x007c
Timer16bitCopyA_HB	         == 0x007d
Timer16bitCopyA_LB	         == 0x007e
Timer16bitCopyB_HB	         == 0x007f
Timer16bitCopyB_LB	         == 0x0080
EngineRpm_HB	                 == 0x0081
EngineRpm_LB	                 == 0x0082

MapVolts	                 == 0x0083
AverageMAPValue	                 == 0x0084
MapScratch	                 == 0x0085
MapValue	                 == 0x0086
Factor_LeanoutOrEnrichTime_MAP	 == 0x0087

AverageTPSVolts	                 == 0x0088
TpsScratch	                 == 0x0089
TpsVolts	                 == 0x008a
Factor_LeanoutOrEnrichTime_TPS	 == 0x008b

CoolantTemp	                 == 0x008c
AmbientAirTempVolts	         == 0x008d
O2SensorVolts	                 == 0x008e
LastChargeTempVolts	         == 0x008f
LastCoolantTempVolts	         == 0x0090
TPSVolts_11msUpdate	         == 0x0091
KnockVolts	                 == 0x0092
BatteryVolts	                 == 0x0093
TargetBatteryVolts	         == 0x0094
Timer_VoltageRegSignal	         == 0x0095
Timer_DelayBeforeUpdating_MINTHR	 == 0x0096
Factor_ACVDCY_CurveACurveCDecayAfterRunModeReached	 == 0x0097
Timer_Leanout	                 == 0x0098
Counter_PrimaryAndSecondaryRamp	 == 0x0099
PointerIntoAdaptiveMemory	 == 0x009a
Timer_CountdownFromStartRunForAisFeedback	 == 0x009b
MinimumTimerCountBeforeMainloopCanContinue	 == 0x009c
Timer_CLTIME_ClosedLoopTimer	 == 0x009d
Counter_AdaptiveMem_Erase	 == 0x009e
Timer_O2CNTR_CountdownFromAbove196FtoEnableClosedLoop	 == 0x009f
Counter_A2DScan2	         == 0x00a0
Timer_AisChanges	         == 0x00a1
AdaptiveCellUpdateTimer_IncrementedEveryDistRisingEdge	 == 0x00a2
SparkScatter	                 == 0x00a3
Temp0	                         == 0x00a4
Temp1	                         == 0x00a5
Temp2	                         == 0x00a6
Temp3	                         == 0x00a7
Temp4	                         == 0x00a8
Temp5	                         == 0x00a9
Temp6	                         == 0x00aa
Temp7	                         == 0x00ab
Temp8	                         == 0x00ac
Temp9	                         == 0x00ad
FuelBaselineResult_HB	         == 0x00ae
FuelBaselineResult_LB	         == 0x00af
DwellTime_HB	                 == 0x00b0
DwellTime_LB	                 == 0x00b1
PreviousMAP	                 == 0x00b2
LeanoutFactor_HB	         == 0x00b3
LeanoutFactor_LB	         == 0x00b4
ADScanIndex	                 == 0x00b5
Cylinder2Retard	                 == 0x00b6
Cylinder1Retard	                 == 0x00b7
Cylinder3Retard	                 == 0x00b8
Cylinder4Retard	                 == 0x00b9
MaxRetardFromMAP	         == 0x00ba
Z83_CPU_Port1_copy	         == 0x00bb
BaroPressure	                 == 0x00bc
CalculatedSparkAdvance	         == 0x00bd
ChargeTempVolts	                 == 0x00be
Timer_OutOfClosedLoopMode	 == 0x00bf
InjectorLatency	                 == 0x00c0
Timer_OpenLoopFraction	         == 0x00c1
Timer_O2ToggleDuration	         == 0x00c2
Counter_FallingEdgeEPP_MaxFF	 == 0x00c3
DesiredNewAisPosition	         == 0x00c4
Timer_AisOrO2Sensor	         == 0x00c5
Delta_MAP	                 == 0x00c6
BoostTarget	                 == 0x00c7
Timer_BoostTimer	         == 0x00c8
CurrentWastegateDutyCycle	 == 0x00c9
BankEnrichmentFactor	         == 0x00ca
Counter_Over5psiBoost	         == 0x00cb
Timer_Over5PSIBoost	         == 0x00cc
Counter_BaroReadTime	         == 0x00cd
IncrementalMAP	                 == 0x00ce
WastegateDutyCycleIncreaseFromKnock	 == 0x00cf
Timer_BoostErrTimer	         == 0x00d0
VerySlowCounter2point6seconds	 == 0x00d1
Timer_FuelShutoff	         == 0x00d2
BitFlags_D3	                 == 0x00d3
BaseFuelModifier	         == 0x00d4
KnockLookup	                 == 0x00d5
FuelSubtractedFromStartToRun	 == 0x00d6
Timer_RadSteamingCountdown	 == 0x00d7
Timer_NavigatorFuelPulsewidth	 == 0x00d8
Timer_NormalDwell	         == 0x00d9
Timer_ThermostatDiagnostics	 == 0x00da
BaroReadTimeEngineWithinReadRange	 == 0x00db
AntiLagRetard                    == 0x00dc
Unused13                         == 0x00dd
Unused12	                 == 0x00de
Unused11	                 == 0x00df
Unused10	                 == 0x00e0
Unused9	                         == 0x00e1
Unused8	                         == 0x00e2
Unused7	                         == 0x00e3
Unused6	                         == 0x00e4
Unused5	                         == 0x00e5
Unused4	                         == 0x00e6
Unused3	                         == 0x00e7
Unused2	                         == 0x00e8
Unused1	                         == 0x00e9

;  ______________________
; |                      \
; |   Hardware           |
; \______________________|

; ***********************************************************************************
; ONLY Change here if you are remapping the hardware addresses, otherwise DON'T TOUCH
; ***********************************************************************************
Z83Mapping                  = 0x2000   ; address for Z83 I/O port mapping
Z85Mapping                  = 0x8000   ; address for Z85 A/D converter mapping
Z50Mapping                  = 0xa000   ; address for lower ROM chip
Z51Mapping                  = 0xe000   ; address for upepr ROM chip


; ***********
; Z83 IO Port
; ***********
Z83_IOPortADataCA1          = Z83Mapping

L2001	                         == 0x2001

Z83_PortAdata               = Z83Mapping + 2
; Pin   Mask    Bit Function            LM Pin
; 11    x80     7   cruise vent         B6
; 10    x40     6   egr                 B5
; 9     x20     5   cruise solenoid     B4
; 8     x10     4   ac clutch out       B3
; 7     x08     3   fan                 R21
; 6     x04     2   wastegate           R19
; 5     x02     1   asd relay           R17
; 4     x01     0   baro read solenoid  R15
; NOTE: for above, 1 is OFF, 0 is ON

Z83_PortBdata               = Z83Mapping + 3
; Pin   Mask    Bit Function            LM Pin
; 27    x80     7   a/d conversion  (int)
; 28    x40     6   fuel monitor        R14
; 29    x20     5   tach out            R12
; 30    x10     4   alt fault       (int)
; 31    x08     3   ais                 R22
; 32    x04     2   ais                 R16
; 33    x02     1   ais                 R18
; 34    x01     0   ais                 R20

Z83_PortCdata               = Z83Mapping + 4
; Pin   Mask    Bit Function            LM Pin
; 35    x80     7   dist sync           B17
; 36    x40     6   cruise enable       B15
; 37    x20     5                       B14
; 38    x10     4   brake               B13
; 39    x08     3   park/neutral        B12
; 1     x04     2   ac clutch in        B11
; 2     x02     1   cruise resume       B10
; 3     x01     0   cruise set          B9

Z83_PortADataDirection      = Z83Mapping + 6
Z83_PortBDataDirection      = Z83Mapping + 7
Z83_PortCDataDirection      = Z83Mapping + 8
Z83_PortAcontrol            = Z83Mapping + 9
Z83_PortBcontrol            = Z83Mapping + 0xa
Z83_PortCcontrol            = Z83Mapping + 0xb

L200E	                         == 0x200e

; *****************
; Z85 A/D Converter
; *****************
; Pin   Addr    Function            LM Pin
; 26    8000    MAP                 B19
; 27    8001    batt temp           B20
; 28    8002    O2                  B18
; 1     8003    air temp            B25
; 2     8004    coolant temp        B23
; 3     8005    tps                 B21
; 4     8006    knock               B24
; 5     8007    batt voltage        B22
Z85_ADConverter1            = Z85Mapping
Z85_ADConverter2            = Z85Mapping + 1
Z85_ADConverter3            = Z85Mapping + 2
Z85_ADConverter4            = Z85Mapping + 3
Z85_ADConverter5            = Z85Mapping + 4
Z85_ADConverterCoolantTemp  = Z85Mapping + 5
Z85_ADConverterMAP          = Z85Mapping + 6
Z85_ADConverterKnockSensor  = Z85Mapping + 7


; *****************************************************************************
; begin code
; *****************************************************************************

        .org LowerChipOrg
        .msg "Assembling Lower Code..."


	;.org	0xa000
LCHPID_LowerChipIDCode:
	.word	0x0016

	;.org	0xa002
UnknownCodeBits:
	.word	0x0038

DetermineFuelTweaks_MM:
           ldaa  BaroPressure
           ldx   #PWADD_FuelPWModifierFromBaro
           jsr   Lookup4ByteTable
           ldaa  DistributorFallingEdgePulsewidth_HB
           tst   TimerOverflowsBetweenDistPulses
           beq   LA015     
           ldaa  #0xff         ;  -11111111-
   LA015:  mul             
           lsrd            
           lsrd            
           lsrd            
           lsrd            
           lsrd            
           std   Temp0     
           ldx   #FuelLeanoutFactorOnThrottle
           ldaa  BitFlags_6e
           bmi   LA027     
           ldx   #FuelLeanoutFactorOffThrottle
   LA027:  ldd   EngineRpm_HB
           asld            
           jsr   Lookup4ByteTable
           clra            
           tstb            
           bpl   LA032     
           deca            
   LA032:  asld            
           asld            
           asld            
           addd  Temp0     
           std   LeanoutFactor_HB
           ldx   #BATOFF_FuelBatteryOffset
           ldaa  BatteryVolts
           jsr   Lookup4ByteTable
           staa  InjectorLatency
           
CalculateSelectiveBankEnrichment:
           ldx  #SBNRMP_BankScalingFromMAP    ; load index with value
           ldaa MapValue       ; load a with memory contents
           jsr  Lookup4ByteTable    ; call subroutine
           staa Temp0          ; store a into memory
           ldx  #SBNRRP_BankScalingFromRPM    ; load index with value
           ldd  EngineRpm_HB    ; load d (a&b) with memory contents
           asld                ; shift left (d=d*2)
           jsr  Lookup4ByteTable    ; call subroutine
           ldab Temp0          ; load b with memory contents
           mul                 ; multiply (d=a*b)
           adca #0x00          ;  -00000000-
           lsra            
           staa BankEnrichmentFactor    ; store a into memory

           ldab  MapValue  
           cmpb  AverageMAPValue
           bcc   LA057     
           ldab  Counter_MainLoop
           bitb  #0x07         ;  -00000111-
           bne   LA057     
           ldx   #AverageMAPValue
           sei             
           jsr   ProcessMapOrTpsBlockData
           cli             
   LA057:  ldd   InjectorPulsewidth_HB
           addd  Pulsewidth_PartThrottleEnrichment_HB
           subd  PWMIN_NoCellUpdateBelow_PWMIN_Pulsewidth
           ldaa  BitFlags_70
           bcs   LA06A     
           bita  #0x20         ;  -00100000-
           bne   LA06A     
           anda  #0xef         ;  -11101111-
           bra   LA06C     

   LA06A:  oraa  #0x10         ;  -00010000-
   LA06C:  staa  BitFlags_70
           rts             

CalculateTransientFuelAddition_MM:
           clra            
           clrb            
           std   Temp0     
           ldaa  BitFlags_6e
           bmi   LA07E     
           ldaa  TpsVolts  
           staa  AverageTPSVolts
   LA07B:  ldd   Temp0     
           rts             

   LA07E:  ldx   #POSTRG_PositiveTransientTriggerLevel
           ldab  TpsVolts  
           subb  AverageTPSVolts
           bcs   LA0A1     
           subb  0x00,x      ;  -00000000-
           bcs   LA0A5
           cmpb  0x01,x      ;  -00000001-
           bcs   LA091
           ldab  0x01,x      ;  -00000001-
   LA091:  stab  Temp4     
           ldaa  CoolantTemp
           inx             
           inx             
           jsr   Lookup4ByteTable
           ldab  Temp4     
           mul             
           std   Temp0     
           bra   LA0A5     

   LA0A1:  ldab  TpsVolts  
           stab  AverageTPSVolts
   LA0A5:  ldaa  MapValue  
           suba  AverageMAPValue
           bls   LA07B     
           suba  MAPTRG_DeltaMapTriggerLevel
           bcs   LA07B     
           cmpa  MAPMAX_MaxDeltaMapAllowed
           bcs   LA0B8     
           ldaa  MAPMAX_MaxDeltaMapAllowed
   LA0B8:  staa  Temp4     
           ldaa  CoolantTemp
           ldx   #AESLOP_DeltaMAPEnrichment_FromTemp2
           jsr   Lookup4ByteTable
           ldaa  Temp4     
           mul             
           addd  Temp0     
           rts             

CalculateInjectorPulsewidthForStarting_MM:
           ldaa  BitFlags_6f
           bpl   LA130     
           ldaa  BitFlags_6e
           lsra            
           ldd   #CPU_Port1_DataDirection
           bcs   LA11F     
           jsr   AllowForHeatSoakAfterStall
           ldx   #STRTFL_FuelStartFromCoolantTemp
           ldab  BitFlags_6e
           bmi   LA0E6     
           cmpa  STRLMT_ColdestTempAllowedAtClosedThrottle
           bcc   LA0E6     
           ldaa  STRLMT_ColdestTempAllowedAtClosedThrottle
   LA0E6:  jsr   Lookup4ByteTable
           mul             
           std   Temp0     
           ldaa  BaroPressure
           ldx   #STFBAR_FuelStartReductionFromBaro
           jsr   Lookup4ByteTable
           staa  Temp4     
           ldaa  CoolantTemp
           ldx   #STFTMP_FuelStartFuelFromCoolant
           jsr   Lookup4ByteTable
           ldaa  Temp4     
           mul             
           adca  #0x00         ;  -00000000-
           beq   LA110     
           tab             
           negb            
           clra            
           ldx   #Temp0    
           jsr   ScaleXbySignedB_ReturnD
           std   Temp0     
   LA110:  ldaa  Counter_FallingEdgeEPP_MaxFF
           ldx   #EPPMUL_FuelStartFuelPerEPP
           jsr   Lookup4ByteTable
           clra            
           ldx   #Temp0    
           jsr   ScaleXbySignedB_ReturnD
   LA11F:  std   Temp0     
           ldab  InjectorLatency
           clra            
           asld            
           addd  Temp0     
           cmpa  #0xbf         ;  -10111111-
           bls   LA12E     
           ldd   #0xbfff   
   LA12E:  std   InjectorPulsewidth_HB
   LA130:  rts             

CalculatePTEFactors_MM:
           ldaa  LMAPTC_TimeConstant
           ldab  MapValue  
           cmpb  AverageMAPValue
           bcs   LA142     
           ldx   #AETIME_EnrichmentTime_FromTemp_MAP
           ldaa  CoolantTemp
           jsr   Lookup4ByteTable
   LA142:  staa  Factor_LeanoutOrEnrichTime_MAP
           ldaa  CoolantTemp
           ldx   #THRTCN_EnrichmentTime_FromTemp
           jsr   Lookup4ByteTable
           staa  Factor_LeanoutOrEnrichTime_TPS
           rts             

SetMapErrorCode_MM:
           ldaa  BitFlags_72
           bita  #0x40         ;  -01000000-
           beq   LA16C     
           ldaa  #0x1d         ;  -00011101-
           staa  Temp4     
           jsr   ThrowCriticalError
           sei             
           ldaa  BitFlags_6d
           bcc   LA165     
           oraa  #0x80         ;  -10000000-
           staa  BitFlags_6d
   LA165:  ldaa  BitFlags_72
           anda  #0xbf         ;  -10111111-
           staa  BitFlags_72
           cli             
   LA16C:  rts             

   LA16E:  ldab  BitFlags_71
           bitb  #0x04         ;  -00000100-
           beq   LA187     
           andb  #0xfb         ;  -11111011-
           stab  BitFlags_71
           cmpa  BAROHI_BaroReadValidHighLimit
           bcc   LA182     
           cmpa  BAROLO_BaroReadValidLowLimit
           bcc   LA185     
   LA182:  ldaa  BARDFT_BaroReadDefaultValue
   LA185:  staa  BaroPressure
   LA187:  rts             

VerifyOperationOfMapSensor_MM:
           ldaa  Z85_ADConverterMAP
           ldab  MINTHR_LowestSessionTPS
           addb  DLTTHR_MinDeltaThrottleforErrorCodeReset
           cmpb  TpsVolts  
           bcs   LA199     
           cmpa  MAPHIG_MapSensorUpperLimit
           bcc   LA1A5     
   LA199:  ldx   EngineRpm_HB
           cpx   #0x1770   
           bcc   ConvertMAPVoltsToValue
           cmpa  MAPLOW_MapSensorLowerLimit
           bcc   ConvertMAPVoltsToValue
   LA1A5:  ldab  BitFlags_72
           orab  #0x40         ;  -01000000-
           stab  BitFlags_72
ConvertMAPVoltsToValue:
           staa  Temp5     
           ldab  MAPMULT_ScaleMAPVoltsToPresMultiplyConst
           bpl   LA1B5     
           clr   Temp5     
   LA1B5:  mul             
           adda  Temp5     
           bcc   LA1BC     
           ldaa  #0xff         ;  -11111111-
   LA1BC:  addd  MAPADD_ScaleMAPVoltsToPresAddConst
           bcc   LA1C3     
           ldaa  #0xff         ;  -11111111-
   LA1C3:  rts             

Throttle_MM:
           ldaa  Counter_TimerPastHalfwayBetweenDistPulses
           cmpa  MAXCDH_MaximumCounterDistrubtorHalfwayforErrorCodeReset
           bcc   LA1F3     
           ldaa  BitFlags_6f
           bmi   Throttle_EngineNotRunning
           ldx   KeyOnOrEngineRunningTime
           cpx   MAXERT_MaximumEngineRunningTimeforErrorCodeReset
           bcc   LA1F3     
Throttle_EngineNotRunning:
           ldaa  MINTHR_LowestSessionTPS
           adda  DLTTHR_MinDeltaThrottleforErrorCodeReset
           cmpa  TpsVolts  
           bcs   Throttle_ClearMAPError
           ldaa  StackPtrTemp_HB
           suba  MapVolts  
           bcc   LA1E6     
           nega            
   LA1E6:  cmpa  MAPERR_MinMAPforErrorCodeReset
           bcs   LA1F3     
Throttle_ClearMAPError:
           sei             
           ldaa  BitFlags_6d
           anda  #0x7f         ;  -01111111-
           staa  BitFlags_6d
           cli             
   LA1F3:  rts             

   LA1F4:  ldx   #IDLWA_Idle_word_A
           ldaa  #0x40         ;  -01000000-
           staa  Temp6     
           ldd   EngineRpm_HB
           subd  TargetIdleSpeed_HB
           bcc   LA20B     
           asl   Temp6     
           ldx   #IDLWB_Idle_word_B
           ldd   TargetIdleSpeed_HB
           subd  EngineRpm_HB
   LA20B:  lsrd            
           lsrd            
           subd  FWDARP_SubtractedFromRPMDuringIdleRoutine
           ldaa  0x00, X      ;  -00000000-
           bcc   LA21E     
           addb  REVARP_AddedBackToRPMDuringIdleRoutine
           bmi   LA24F     
           ldaa  0x01, X      ;  -00000001-
           mul             
           adca  0x02, X      ;  -00000010-
   LA21E:  ldab  Temp6     
           bpl   LA223     
           nega            
   LA223:  ldab  BitFlags_6d
           bitb  #0x82         ;  -10000010-
           bne   LA235     
           ldx   TimerOverflowsBetweenDistPulses
           cpx   SSIPRD_ScatterInhibitBelowThisSpeed
           bcc   LA235     
           tab             
           addb  Temp5     
           stab  Temp5     
   LA235:  adda  SparkScatter
           bvc   DoUseSparkScatter
           ldab  DesiredNewAisPosition
           cmpb  CurrentAisPosition
           bne   DontUseSparkScatter
           ldaa  FTUNPW_FineTuneStepForAis
           beq   DontUseSparkScatter
           ldab  Temp6     
           bmi   SaveDesiredAisPosition
           nega            
SaveDesiredAisPosition:
           jsr   StoreAndLimitDesiredAisPosition
DontUseSparkScatter:
           clra            
DoUseSparkScatter:
           staa  SparkScatter
   LA24F:  rts             

ControlPurgeSolenoid_MM:
           ldab  BitFlags_6e
           lsrb            
           bcs   LA27F     
           ldab  Timer_OpenLoopFraction
           cmpb  LMTOLF2_LimitTimerOpenLoopFraction2
           bcc   LA27F     
           ldab  BaroPressure
           ldaa  Z83_CPU_Port1_copy
           bmi   LA265     
           subb  PURHYS_CannisterPurgeBaroHysteresis
   LA265:  subb  PURMAP_CannisterPurgeWhenBelowThisBaro
           cmpb  MapValue  
           bcs   LA27F     
           ldab  BitFlags_6e
           bitb  #0x10         ;  -00010000-
           bne   LA279     
           ldab  Timer_CLTIME_ClosedLoopTimer
           cmpb  O2TIME_DelayTimeToClosedLoop
           bcs   LA27F     
   LA279:  ldaa  Z83_CPU_Port1_copy
           oraa  #0x80         ;  -10000000-
           bra   LA283     

   LA27F:  ldaa  Z83_CPU_Port1_copy
           anda  #0x7f         ;  -01111111-
   LA283:  staa  Z83_CPU_Port1_copy
           rts             

ControlFan2_MM:
           ldab  Z83_CPU_Port1_copy
           ldaa  BaroPressure
           adda  FANMAP_FanTurnsOnWhenMapAboveBaroPlusThis
           bcs   LA2A2     
           bitb  #0x08         ;  -00001000-
           beq   LA297     
           adda  #0x03         ;  -00000011-
           bcs   LA2A2     
   LA297:  cmpa  MapValue  
           bcc   LA2A2     
           ldaa  AmbientAirTempVolts
           cmpa  FANBAT_FanTurnsOnWhenBatteryTempAboveThis
           bcs   LA2F1     
   LA2A2:  ldaa  CoolantTemp
           cmpa  #0xd2         ;  -11010010-
           bcs   LA2BF     
           ldaa  Timer_RadSteamingCountdown
           beq   LA2BF     
           tst   Counter_MainLoop
           bne   LA2B4     
           deca            
           staa  Timer_RadSteamingCountdown
   LA2B4:  clra            
           bitb  #0x08         ;  -00001000-
           bne   LA2BB     
           ldaa  #0x08         ;  -00001000-
   LA2BB:  cmpa  VehicleSpeed_HB
           bcc   LA2F1     
   LA2BF:  ldaa  BitFlags_6d
           bita  #0x02         ;  -00000010-
           bne   LA2F1     
           ldx   #FANTMP1_FanTurnOnTempAbove45Mph
           ldaa  VehicleSpeed_HB
           cmpa  #0x5a         ;  -01011010-
           bcc   LA2DE     
           cmpa  #0x46         ;  -01000110-
           ldaa  BitFlags_70
           bcs   LA2D8     
           bita  #0x01         ;  -00000001-
           bne   LA2DE     
   LA2D8:  inx             
           inx             
           anda  #0xfe         ;  -11111110-
           bra   LA2E2     

   LA2DE:  ldaa  BitFlags_70
           oraa  #0x01         ;  -00000001-
   LA2E2:  staa  BitFlags_70
           bitb  #0x08         ;  -00001000-
           bne   LA2E9     
           inx             
   LA2E9:  orab  #0x08         ;  -00001000-
           ldaa  0x00, X      ;  -00000000-
           cmpa  CoolantTemp
           bcc   LA2F3     
   LA2F1:  andb  #0xf7         ;  -11110111-
   LA2F3:  stab  Z83_CPU_Port1_copy
           rts             

HandleBaroReadRequirement_MM:
           ldaa  BitFlags_6f
           bpl   LA301     
           ldaa  Z83_CPU_Port1_copy
           oraa  #0x01         ;  -00000001-
           staa  Z83_CPU_Port1_copy
           rts             

   LA301:  ldab  BitFlags_71
           bitb  #0x08         ;  -00001000-
           bne   LA313     
           ldaa  Counter_BaroReadTime
           tst   Counter_MainLoop
           bne   LA313     
           inca            
           beq   LA313     
           staa  Counter_BaroReadTime
   LA313:  ldaa  BitFlags_6e
           bpl   LA329     
           ldaa  Z83_CPU_Port1_copy
           oraa  #0x01         ;  -00000001-
           staa  Z83_CPU_Port1_copy
           clra            
           staa  BaroReadTimeEngineWithinReadRange
           ldaa  #0xf1         ;  -11110001-
           sei             
           anda  BitFlags_71
           staa  BitFlags_71
           cli             
           rts             

   LA329:  bitb  #0x08         ;  -00001000-
           bne   LA35A     
           ldx   EngineRpm_HB
           cpx   BRPMH2_BaroReadHighRPM66502
           bhi   LA38B     
           cpx   BRPML2_BaroReadLowRPM18002
           bcs   LA38B     
           ldaa  BaroReadTimeEngineWithinReadRange
           inca            
           beq   LA345     
           staa  BaroReadTimeEngineWithinReadRange
           cmpa  BRDLAY_BaroReadDelayAfterThrottleClosed2sec
           bcs   LA38B     
   LA345:  ldaa  Counter_BaroReadTime
           cmpa  BARTIM_BaroReadMinTimeBetweenReadings179sec
           bcs   LA38B     
           bitb  #0x02         ;  -00000010-
           bne   LA38B     
           ldaa  Z83_CPU_Port1_copy
           anda  #0xfe         ;  -11111110-
           staa  Z83_CPU_Port1_copy
           ldab  #0x08         ;  -00001000-
           bra   LA36A     

   LA35A:  inc   Counter_BaroReadTime
           bitb  #0x02         ;  -00000010-
           bne   LA36F     
           ldaa  Counter_BaroReadTime
           cmpa  BROPTM_BaroReadDelayAfterSolenoidOpenTenthSec
           bcs   LA38B     
           ldab  #0x06         ;  -00000110-
   LA36A:  sei             
           orab  BitFlags_71
           bra   LA385     

   LA36F:  bitb  #0x04         ;  -00000100-
           bne   LA388     
           ldaa  Z83_CPU_Port1_copy
           oraa  #0x01         ;  -00000001-
           staa  Z83_CPU_Port1_copy
           ldaa  Counter_BaroReadTime
           cmpa  BRCLTM_BaroReadDelayAfterSolenoidClosedTenthSec
           bcs   LA38B     
           ldab  #0xf7         ;  -11110111-
           sei             
           andb  BitFlags_71
   LA385:  stab  BitFlags_71
           cli             
   LA388:  clrb            
           stab  Counter_BaroReadTime
   LA38B:  rts             

CalculateInjectorPulsewidthForEngineRunning:
           clra
           clrb            
           std   Temp8     
           ldaa  MapValue  
           ldx   #WOTTBL_FuelFullThrottle
           jsr   Lookup5ByteTable
           std   FuelBaselineResult_HB
           ldaa  MapValue  
           ldx   #MAPIDL_FuelBaselineFromMap
           ldab  BitFlags_6e
           bpl   LA3DF     
           lsrb            
           bcs   LA3B4     
           ldab  Timer_OpenLoopFraction
           cmpb  LMTOLF2_LimitTimerOpenLoopFraction2
           bcs   LA3B9     
           ldaa  EngineRpm_HB
           cmpa  RPMLMT_RPMLimitForManyThings
           bcs   LA3B9     
   LA3B4:  clra            
           staa  Counter_PrimaryAndSecondaryRamp
           bra   LA3EC     

   LA3B9:  ldaa  MapValue  
           cmpa  OBCONST_OverboostConstant1
           bcs   LA3C3     
           tba             
           bra   LA3CD     

   LA3C3:  aba             
           bcc   LA3C8     
           ldaa  #0xff         ;  -11111111-
   LA3C8:  suba  OBCONST_OverboostConstant1
           bls   LA3DA     
   LA3CD:  clrb            
           stab  Counter_PrimaryAndSecondaryRamp
           staa  Temp5     
           ldd   PTPWOF_PartThrottlePulsewidthOffset
           jsr   mul16bit  
           std   Temp8     
   LA3DA:  ldaa  MapValue  
           ldx   #MAPTBL_FuelPartThrottle
   LA3DF:  jsr   Lookup5ByteTable
           addd  Temp8     
           std   Temp8     
           subd  FuelBaselineResult_HB
           ldd   Temp8     
           bcs   LA3EE     
   LA3EC:  ldd   FuelBaselineResult_HB
   LA3EE:  asld            
           rts             

CalculatePartThrottleEnrichmentFuel_MM:
           ldd   EngineRpm_HB
           asld
           ldx   #RPMMAP_SwitchPointForDownUp_FromRpm
           jsr   Lookup4ByteTable
           ldaa  Timer_OpenLoopFraction
           cmpa  LMTOLF2_LimitTimerOpenLoopFraction2
           bcs   LA406     
           subb  RPMPSB_RPMMAPSubtractor
           bcc   LA406     
           clrb            
   LA406:  ldaa  Counter_FallingEdgeEPP_MaxFF
           cmpb  MapValue  
           bcs   LA41B     
           cmpa  PTENR_EppPerAmountForIncreasing
           bcs   LA434     
           ldab  PTENR_EppPerAmountForIncreasing
           ldaa  Timer_OpenLoopFraction
           beq   LA42D     
           deca            
           bra   LA42B     

   LA41B:  cmpa  LMTOLF1_LimitTimerOpenLoopFraction1
           bcs   LA434     
           ldab  LMTOLF1_LimitTimerOpenLoopFraction1
           ldaa  Timer_OpenLoopFraction
           cmpa  LMTOLF2_LimitTimerOpenLoopFraction2
           bcc   LA42D     
           inca            
   LA42B:  staa  Timer_OpenLoopFraction
   LA42D:  sei             
           ldaa  Counter_FallingEdgeEPP_MaxFF
           sba             
           staa  Counter_FallingEdgeEPP_MaxFF
           cli             
   LA434:  rts             

SetFlagForPTE_MM:
           ldaa  PreviousMAP
           ldab  MapValue  
           stab  PreviousMAP
           sba             
           ldab  BitFlags_70
           andb  #0xdf         ;  -11011111-
           bcs   LA466     
           cmpa  MINDLM_MinDeltaMAPForPTE
           bcs   LA466     
           ldaa  BitFlags_6f
           bmi   LA466     
           ldaa  CoolantTemp
           cmpa  MINCTS_MinCoolantTempForPTE
           bcs   LA466     
           ldaa  KeyOnOrEngineRunningTime
           cmpa  MINERT_MinTimeForPTE
           bcs   LA466     
           ldaa  EngineRpm_HB
           cmpa  MINRPM_MinRPMforPTE
           bcs   LA466     
           ldaa  BitFlags_6e
           bmi   LA466     
           orab  #0x20         ;  -00100000-
   LA466:  stab  BitFlags_70
           rts             

ControlEngineCutout_MM:
           ldaa  BitFlags_6f
           bmi   LA4B8     
           ldaa  BaroPressure
           ldab  BitFlags_6d
           bitb  #0x10         ;  -00010000-
           beq   LA486     
           adda  LMPSHF_OverboostFuelShutoffDisablePointFromMap_Limp
           cmpa  MAPHIG_MapSensorUpperLimit
           bcs   LA480     
           ldaa  MAPHIG_MapSensorUpperLimit
   LA480:  cmpa  MapValue  
           bls   LA4A5     
           bra   LA4B8     

   LA486:  adda  MPSHFT_OverboostFuelShutoffEnablePointFromMap_Timer
           bcc   LA48D     
           ldaa  #0xff         ;  -11111111-
   LA48D:  cmpa  MapValue  
           bhi   LA4B3     
           adda  MPSHFA_OverboostFuelShutoffEnablePointFromMap_Absolute
           bcc   LA498     
           ldaa  #0xff         ;  -11111111-
   LA498:  cmpa  MapValue  
           bcs   LA4A5     
           ldab  Timer_FuelShutoff
           beq   LA4A5     
           decb            
           stab  Timer_FuelShutoff
           bra   LA4B8     

   LA4A5:  ldab  MapValue  
           cmpb  MAPHIG_MapSensorUpperLimit
           bcc   SetFuelShutoffFlag
           ldaa  #0x07         ;  -00000111-
           jsr   LAD18     
           bra   SetFuelShutoffFlag

   LA4B3:  ldaa  TRNTM_OverboostFuelShutoffDelay
           staa  Timer_FuelShutoff
   LA4B8:  ldaa  TimerOverflowsBetweenDistPulses
           bne   ClearFuelShutoffFlag
           ldx   #REVLMT_OverRevFuelShutoff
           ldaa  BitFlags_6d
           bpl   LA4CC     
           ldab  THRTHR_25PctThrValueFromShutoff
           addb  MINTHR_LowestSessionTPS
           cmpb  TpsVolts  
           bcs   Shutoff_CheckRPMAgainstLimiter
   LA4CC:  ldx   #REVLMT3_OverRevFuelShutoff
           bita  #0x40         ;  -01000000-
           beq   LA4DC     
           ldab  VehicleSpeed_HB
           cmpb  RVLSPD_CarSpeedForRevLimitWithTBOff
           bcc   LA4EA     
           bra   LA4E0     

   LA4DC:  ldab  BitFlags_6e
           bmi   LA4EA     
   LA4E0:  ldab  BaroPressure
           lsrb            
           tba             
           lsrb            
           aba             
           cmpa  MapValue  
           bcs   Shutoff_CheckRPMAgainstLimiter
   LA4EA:  ldx   #REVLMT5_OverRevFuelShutoff

;           ; ******************************************************************
;           ; new staging mod, RCL
;           ; this simply decides which rev limit to use for 'normal' operation
;           ; either the 'full' rev limit, or the staging limit
;           ; it uses the original code to turn off the fuel...
; 
;           ; first, check that the option is enabled (RCL)
;         
          ldab CONFIG_ConfigurationFlags
          bitb #cfg_StageLim
          beq  Shutoff_CheckRPMAgainstLimiter ; if not optioned, don't even run this code...

          ; here, check that the brake pedal is pushed  (RCL)
          ldaa RVLSWS_StagingLimiterSwitchSelect
          beq  checkspeed    ; no enable switch, so enabled by speed only
          anda Z83_PortCdata  ; comapre the switch state to the enable switch - if 2 switches are enabled, then they work as -OR- switches, not -AND-
          beq  clearflag     ; branch if not enabled or pedal just released

checkspeed:
           ldd  VehicleSpeed_HB ; load d (a&b) with memory contents
           asld                ; Vehicle speed reference is now 0-255mph
           asld                ;
           cmpa RVLSPS_Staging ; compare a with memory contents
           bcs  setflag       ; if the speed is below the speed limit, set the flag

clearflag:
           ldaa BitFlags_6d
           anda ~#flg_bit5    ;using this bit to tell that the limiter is NOT active - for the anti-lag retard
           staa BitFlags_6d
           bra  Shutoff_CheckRPMAgainstLimiter

setflag:
           ldaa BitFlags_6d
           oraa #flg_bit5      ; using this bit to tell that the limiter is active - for the anti-lag retard
           staa BitFlags_6d
           ; set the 2-step limit
           ldx #REVLMTX_StagingModFuelShutoff

        ; ******************************************************************


 Shutoff_CheckRPMAgainstLimiter:
            ldd   DistributorFallingEdgePulsewidth_HB
            subd  0x00, X      ;  -00000000-
            bcc   ClearFuelShutoffFlag
            ldd   DistributorFallingEdgePulsewidth_HB
            subd  0x02, X      ;  -00000010-
            bcs   SetFuelShutoffFlag
            ldab  BitFlags_70
            bitb  #0x08         ;  -00001000-
            beq   LA50B     
 SetFuelShutoffFlag:
            ldab  BitFlags_70
            orab  #0x08         ;  -00001000-
            bra   StoreFuelShutoffFlag

 ClearFuelShutoffFlag:
            ldab  BitFlags_70
            andb  #0xf7         ;  -11110111-
 StoreFuelShutoffFlag:
            stab  BitFlags_70
    LA50B:  rts             

    LA50C:  clra            
            ldab  AverageMAPValue
            subb  MapValue  
            bls   LA53F     
            stab  Temp5     
            ldab  EngineRpm_HB
            cmpb  MNDCRP_MinRPMforDecelLeanout
            bcs   LA53F     
            ldab  KeyOnOrEngineRunningTime
            cmpb  MNDCTM_MinTimeforDecelLeanout
            bcs   LA53F     
            ldab  Temp5     
            ldaa  Timer_Leanout
            beq   LA52C     
            addb  DMDCIC_DeltaMAPLeanoutIncrement
    LA52C:  clra            
            subb  DMDCDC_DeltaMAPLeanoutDecrement
            bcs   LA53F     
            ldaa  TMDCNT_TimerLeanoutInitial
            cmpb  DMLMT_DeltaMAPLeanoutLimit
            bcc   LA53F     
            ldaa  Timer_Leanout
            beq   LA541     
            inca            
    LA53F:  staa  Timer_Leanout
    LA541:  rts             

 SetTPSFlags_MM:
            clra            
            ldx   EngineRpm_HB
            cpx   TargetIdleSpeed_HB
            bls   LA54E     
            ldaa  Timer_CountdownFromStartRunForAisFeedback
            beq   LA550     
            deca            
    LA54E:  staa  Timer_CountdownFromStartRunForAisFeedback
    LA550:  ldaa  MPHREF_SwitchPointForDecelIdleAisControl
            ldab  BitFlags_70
            bitb  #0x40         ;  -01000000-
            bne   LA55B     
            adda  #0x03         ;  -00000011-
    LA55B:  orab  #0x40         ;  -01000000-
            tst   BitFlags_6e
            bmi   LA566     
            cmpa  VehicleSpeed_HB
            bcs   LA568     
    LA566:  andb  #0xbf         ;  -10111111-
    LA568:  stab  BitFlags_70
            rts             

 CalculateAisPosition_MM:
            ldaa  BitFlags_6f
            oraa  BitFlags_5D
            oraa  BitFlags_6e
            bmi   LA579     
            ldab  TimerOverflowsBetweenDistPulses
            orab  Timer_CountdownFromStartRunForAisFeedback
            beq   LA57A     
    LA579:  rts             

    LA57A:  ldaa  BitFlags_6d
            bpl   LA582     
            clra            
            jmp   LA684     

    LA582:  ldaa  Timer_DacalCountdown
            lsra            
            lsra            
            adda  DANOM_Base_nominalCal
            bcs   LA5BB     
            ldab  BitFlags_70
            bitb  #0x40         ;  -01000000-
            beq   LA5BD     
            staa  Temp1     
            ldx   #TIMEDC_AISDecelBaseAirflowCurveOffset
            ldaa  KeyOnOrEngineRunningTime
            jsr   Lookup4ByteTable
            ldaa  Temp1     
            aba             
            bcs   LA5BB     
            staa  Temp1     
            ldx   #TEMPDC_DecelAis_FromTemp
            ldaa  CoolantTemp
            jsr   Lookup4ByteTable
            ldab  Temp1     
            aba             
            bcs   LA5BB
            ldab  Z83_PortCdata
            bitb  #0x04         ;  -00000100-
            bne   LA5BD     
            adda  DAACF_ACFactorDeltaFromBase
            bcc   LA5BD     
    LA5BB:  ldaa  #0xff         ;  -11111111-
    LA5BD:  ldab  DistributorFallingEdgePulsewidth_HB
            mul             
            asld            
            bcs   LA5F7     
            staa  Temp0     
            ldx   #MAPFLR_AdditionToControlMap_FromRpm
            ldd   EngineRpm_HB
            asld            
            jsr   Lookup4ByteTable
            staa  Temp1     
            ldx   #MPTEMP_TempTermForMapOffset_FromTemp
            ldaa  CoolantTemp
            jsr   Lookup4ByteTable
            ldab  Temp1     
            mul             
            adca  #0x00         ;  -00000000-
            staa  Temp1     
            ldx   #BARFLR_OffsetCorrectionTo_MAPFLR_FromBaro
            ldaa  BaroPressure
            jsr   Lookup4ByteTable
            ldab  Temp1     
            mul             
            asld            
            bcs   LA5F7     
            tstb            
            bpl   LA5F3     
            inca            
            beq   LA5F7     
    LA5F3:  adda  Temp0     
            bcc   LA5F9     
    LA5F7:  ldaa  #0xff         ;  -11111111-

    LA5F9:  ldab  BitFlags_70
            bitb  #0x40         ;  -01000000-
            bne   LA672     

;### changed this code to look at the config flags instead of the whole byte

            ldab CONFIG_ConfigurationFlags
            bpl  LA60E ;branch if bit 7 is NOT set, IE manual trans

;           ldab Manual00_AutomaticFF    ; load b with memory contents (data is 00)
;           beq  LA60E          ; branch if equal (zero)

            ldab  Z83_PortCdata
            bitb  #0x08         ;  -00001000-
            beq   LA671     
    LA60E:  ldab  KeyOnOrEngineRunningTime
            cmpb  DCALTM_DacalInhibitTimeAfterStartup
            bcs   LA671     
            ldab  Z83_PortCdata
            andb  #0x04         ;  -00000100-
            beq   LA671     
            ldab  CoolantTemp
            cmpb  DATHOT_EngineTempToStartCalibratingDacal
            bls   LA671     
            ldab  Counter_MainLoop
            bitb  DCALRT_DacalUpdateRate01_03_07_0f_1f_3f_7f_ff
            bne   LA645     
            ldab  TargetIdleSpeed_HB
            subb  EngineRpm_HB
            bcc   LA631     
            negb            
    LA631:  cmpb  DADRPM_DeltaRpmFromIdleSpeedForDacalUpdate
            bhi   LA645     
            ldab  Timer_DacalCountdown
            cmpa  MapValue  
            bhi   LA63F     
            incb            
            bne   LA643     
    LA63F:  tstb            
            beq   LA645     
            decb            
    LA643:  stab  Timer_DacalCountdown
    LA645:  ldd   EngineRpm_HB
            subd  TargetIdleSpeed_HB
            bcc   LA650     
            coma            
            comb            
            addd  #CPU_Port2_DataDirection
    LA650:  asld            
            asld            
            bcs   LA671     
            asld            
            bcs   LA671     
            cmpa  #0x0a         ;  -00001010-
            bcc   LA671     
            ldaa  CurrentAisPosition
            cmpa  DesiredNewAisPosition
            bne   LA671     
            ldaa  DesiredNewAisPosition
            cmpa  CALPOS_PositionAisMotorIsAtIdle
            beq   LA671     
            bhi   LA66C     
            inca            
            inca            
    LA66C:  deca            
            staa  DesiredNewAisPosition
            staa  CurrentAisPosition
    LA671:  rts             

    LA672:  ldab  CoolantTemp
            cmpb  DATHT2_EngineTempToStartCalibratingDacal2
            bcs   LA684     
            ldab  EngineRpm_HB
            subb  TargetIdleSpeed_HB
            bcs   LA684     
            cmpb  DDRPM2_AisDeltaRpmFromIdle2
            bcs   LA6B1     
    LA684:  ldab  Timer_AisChanges
            cmpb  DCLRFQ_TimeBetweenAisPulsesForDecelAis
            bcs   LA6B1     
            ldab  BitFlags_AIS
            andb  #0xf7         ;  -11110111-
            stab  BitFlags_AIS
            cmpa  DCLMIN_MinLimitOnDecelAisControlledMap
            bcc   LA699     
            ldaa  DCLMIN_MinLimitOnDecelAisControlledMap
    LA699:  ldx   #DAISOP_DecelAisOpenStepsFromNeg_FromDeltaMap
            suba  MapValue  
            bcc   LA6A4     
            nega            
            ldx   #DAISCL_DecelAisOpenStepsFromPos_FromDeltaMap
    LA6A4:  jsr   Lookup4ByteTable
            jsr   StoreAndLimitDesiredAisPosition
            cmpa  CurrentAisPosition
            beq   LA6B1     
            clra            
            staa  Timer_AisChanges
    LA6B1:  rts             

 KickUpAisBy2DuringDecel_MM:
            ldaa  BitFlags_70
            bita  #0x40         ;  -01000000-
            bne   LA6E7     
            ldaa  BitFlags_6d
            bmi   LA6E7     
            ldaa  DesiredNewAisPosition
            oraa  CurrentAisPosition
            bne   LA6E7     
            ldab  Counter_MainLoop
            bitb  #0x7e         ;  -01111110-
            bne   LA6E7     
            adda  #0x02         ;  -00000010-
            staa  DesiredNewAisPosition
            staa  CurrentAisPosition
            ldaa  BitFlags_AIS
            bita  #0x10         ;  -00010000-
            bne   LA6E7     
            oraa  #0x02         ;  -00000010-
            staa  BitFlags_AIS
            ldaa  #0x3f         ;  -00111111-
            staa  Temp4     
            jsr   ThrowCriticalError
            bcc   LA6E7     
            ldaa  BitFlags_AIS
            oraa  #0x10         ;  -00010000-
            staa  BitFlags_AIS
    LA6E7:  rts             

 ResetStartup:
            ldd   #0x83df   
            staa  BitFlags_6f
            stab  Z83_PortAdata
            stab  Z83_CPU_Port1_copy
            ldd   #0x7963   
            std   CPU_TimerControl1
            ldaa  CPU_Port1_ControlRegister
            oraa  #0x80         ;  -10000000-
            anda  #0xfb         ;  -11111011-
            staa  CPU_Port1_ControlRegister
            ldaa  CPU_TimerStatus
            ldd   CPU_Counter_HB
            inca            
            std   CPU_OCR3_HB
            cli             
            ldd   #0x060a   
            std   CPU_SCI_ModeControlReg
            ldaa  CPU_SCI_TxRxCntrlReg
            ldaa  #0x88         ;  -10001000-
            staa  CPU_SCI_TxDataReg
            ldx   #UCHPID_UpperChipIDCode
            clrb            
 ChecksumLoop:
            addb  0x00, X      ;  -00000000-
            inx             
            bne   ChecksumLoop
            subb  UCHPID_UpperChipIDCode+1
            bne   LA730     
            ldx   #LCHPID_LowerChipIDCode
    LA723:  addb  0x00, X      ;  -00000000-
            inx             
            cpx   #0xb000   
            bcs   LA723     
            subb  LCHPID_LowerChipIDCode+1
            beq   ChecksumFinished
    LA730:  ldx   #ErrorBitRegister0
            ldab  #0x02         ;  -00000010-
            jsr   ThrowNonCriticalError
 ChecksumFinished:
            ldd   ErrorCodeBitMask0
            anda  ErrorBitRegisterStored0
            andb  ErrorBitRegisterStored1
            std   ErrorBitRegisterStored0
            ldd   ErrorCodeBitMask2
            anda  ErrorBitRegisterStored2
            andb  ErrorBitRegisterStored3
            std   ErrorBitRegisterStored2
            ldx   #AutoCalCell12
            ldd   #0x5500   
            psha            
            deca            
            sec             
    LA753:  rolb
            inx             
            cpx   #ErrorBitRegisterStored0
            beq   LA76D     
    LA75A:  bitb  0x04, X      ;  -00000100-
            bne   LA760     
            bra   LA761     

    LA760:  psha            
    LA761:  deca            
            bita  #0x0f         ;  -00001111-
            bne   LA768     
            suba  #0x09         ;  -00001001-
    LA768:  aslb            
            bcs   LA753     
            bra   LA75A     

    LA76D:  tsx             
            stx   Temp5     
            dex             
    LA771:  inx             
            ldaa  LastDistributorFallingEdgeTime_LB
            adda  #0xfa         ;  -11111010-
            bsr   LA7B6     
            ldaa  0x00, X      ;  -00000000-
            lsra            
            lsra            
            lsra            
            lsra            
            bsr   LA79D     
            ldaa  LastDistributorFallingEdgeTime_LB
            adda  #0x7d         ;  -01111101-
            bsr   LA7B6     
            ldaa  0x00, X      ;  -00000000-
            anda  #0x0f         ;  -00001111-
            bsr   LA79D     
            ldaa  0x00, X      ;  -00000000-
            cmpa  #0x55         ;  -01010101-
            bne   LA771     
    LA792:  sei             
            ldaa  BitFlags_6e
            oraa  #0x40         ;  -01000000-
            staa  BitFlags_6e
            cli             
    LA79A:  wai             
            bra   LA79A     

    LA79D:  staa  FuelBaselineResult_HB
    LA79F:  clrb            
            jsr   LA828     
            bsr   LA7B2     
            ldab  #0x20         ;  -00100000-
            jsr   LA828     
            bsr   LA7B2     
            dec   FuelBaselineResult_HB
            bne   LA79F     
            rts             

    LA7B2:  ldaa  LastDistributorFallingEdgeTime_LB
            adda  #0x1f         ;  -00011111-
    LA7B6:  cmpa  LastDistributorFallingEdgeTime_LB
            beq   LA7C5     
            ldab  BitFlags_6e
            bitb  #0x20         ;  -00100000-
            beq   LA7B6     
            lds   #0x00ff   
            bra   LA792     

    LA7C5:  rts             

    LA7C6:  ldd   CPU_SCI_TxRxCntrlReg
            bpl   LA7CE     
            cmpb  #0xf0         ;  -11110000-
            beq   LA7EB     
    LA7CE:  ldaa  BitFlags_6e
            bmi   LA7EB     
            ldx   Temp5     
            ldab  0x00, X      ;  -00000000-
            stab  CPU_SCI_TxDataReg
            cmpb  #0x55         ;  -01010101-
            bne   LA7E8     
            oraa  #0x80         ;  -10000000-
            ldab  Z83_PortCdata
            andb  #0xfc         ;  -11111100-
            stab  Temp2     
            staa  BitFlags_6e
            rts             

    LA7E8:  inx             
            stx   Temp5     
    LA7EB:  rts             

 IncrementSlowCounter_MM:
            ldaa  Counter_MainLoop
            bne   LA808     
            ldx   #ClearTheErrorTimer_0
            ldd   ClearTheErrorTimer_0
    LA7F5:  tsta            
            beq   LA801     
            suba  #0x20         ;  -00100000-
            bita  #0xe0         ;  -11100000-
            bne   LA7FF     
            clra            
    LA7FF:  staa  0x00, X      ;  -00000000-
    LA801:  inx             
            tba             
            cpx   #VehicleSpeed_HB
            bne   LA7F5     
    LA808:  rts

    LA809:  ldx   #AutoCalCell12
            ldab  SlowCounter
            cmpb  #0x14         ;  -00010100-
            bcs   LA824     
            ldx   #ErrorBitRegister0
            clrb            
    LA816:  ldaa  0x00, X      ;  -00000000-
            anda  0x04, X      ;  -00000100-
            staa  0x04, X      ;  -00000100-
            stab  0x00, X      ;  -00000000-
            inx             
            cpx   #ErrorBitRegisterStored0
            bne   LA816     
    LA824:  incb            
            stab  SlowCounter
            rts             

    LA828:  ldaa  #0xdf         ;  -11011111-
            anda  Z83_CPU_Port1_copy
            aba             
            staa  Z83_CPU_Port1_copy
            rts             

 Injector34Off:
            ldaa  CPU_Port1_ControlRegister
            anda  #0xfb         ;  -11111011-
            staa  CPU_Port1_ControlRegister
            ldaa  CPU_TimerControl2
            anda  #0xef         ;  -11101111-
            staa  CPU_TimerControl2
            ldaa  CPU_OCR2_HB
            staa  CPU_OCR2_HB
            rts             

 CheckVoltageforAIS:
            ldaa  BatteryVolts
            cmpa  BTVAIS_MinVoltageForAis
            bcs   LA889     
    LA848:  ldab  CurrentAisPosition
            ldaa  BitFlags_AIS
            bita  #0x40         ;  -01000000-
            beq   Operate_AIS_Motor
            ldaa  #0xff         ;  -11111111-
            tstb            
            bne   LA86A     
            ldaa  BitFlags_AIS
            anda  #0xbf         ;  -10111111-
            staa  BitFlags_AIS
            bra   LA889


	;.org	0xa85d
AISTEP_BitPatternForAisControl:
	.byte	0x06,0x0a,0x09,0x05
Operate_AIS_Motor:
           ldaa  #0x01         ;  -00000001-
           cmpb  DesiredNewAisPosition
           beq   LA889     
           bcs   LA86A     
           nega            
   LA86A:  staa  Temp0     
           ldx   #AISTEP_BitPatternForAisControl
           ldab  AISMotorBits
           addb  Temp0     
           andb  #0x03         ;  -00000011-
           stab  AISMotorBits
           abx             
           ldab  CurrentAisPosition
           addb  Temp0     
           stab  CurrentAisPosition
           sei             
           ldaa  Z83_PortBdata
           anda  #0xf0         ;  -11110000-
           oraa  0x00, X      ;  -00000000-
           staa  Z83_PortBdata
   LA889:  ldaa  CPU_Counter_HB
           staa  Counter_A2DScan2
           ldd   #0xff6f   
           std   Z83_PortADataDirection
           ldaa  Z83_PortBdata
           staa  Temp3     
           ldaa  Z83_CPU_Port1_copy
           ldab  BitFlags_6f
           bitb  #0x01         ;  -00000001-
           bne   LA8A8     
           anda  #0xfb         ;  -11111011-
           ldab  Z83_PortAdata
           andb  #0x04         ;  -00000100-
           aba             
   LA8A8:  staa  Z83_PortAdata
           clra            
           ldab  BatteryVolts
           cmpb  #0xa2         ;  -10100010-
           bhi   LA8C2     
           cmpb  #0x61         ;  -01100001-
           bcc   LA8BC     
           cmpb  #0x51         ;  -01010001-
           bcs   LA8C2     
           ldab  #0x61         ;  -01100001-
   LA8BC:  ldaa  #0x2d         ;  -00101101-
           mul             
           nega            
           adda  #0x1d         ;  -00011101-
   LA8C2:  staa  Temp4     
           clra            
           ldab  BatteryVolts
           cmpb  #0xa2         ;  -10100010-
           bcc   LA8CC     
           deca
   LA8CC:  ldab  #0x60         ;  -01100000-
           std   Z83_PortADataDirection
           abx             
           ldab  Temp4     
           ldx   #LA8DA    
           abx             
           jmp   0x00, X      ;  -00000000-


	;.org	0xa8da
LA8DA:
	.byte	0x01,0x01,0x01,0x01
	.byte	0x01,0x01,0x01,0x01
	.byte	0x01,0x01,0x01,0x01

AbandonedCode1:
           ldab  Temp3     
           tba             
           eorb  Z83_PortBdata
           andb  #0x0f         ;  -00001111-
           beq   LA90E     
           cli             
           ldaa  BatteryVolts
           cmpa  #0xba         ;  -10111010-
           bcs   LA961     
           ldaa  #0x15         ;  -00010101-
           jsr   LAD18     
           bra   LA916


	;.org	0xa8fe
LA8FE:
	.byte	0x80,0x40,0x00,0x10,0x08,0x04,0x02,0x01
	.byte	0x0f,0x12,0x11,0x10,0x0e,0x0d,0x0a,0x0c
   LA90E:  anda  #0x6f         ;  -01101111-
           oraa  #0x60         ;  -01100000-
           staa  Z83_PortBDataDirection
           cli             
   LA916:  ldaa  BitFlags_6f
           lsra            
           bcs   LA961     
           ldx   #LA8FE    
           ldab  Counter_MainLoop
           andb  #0x07         ;  -00000111-
           abx             
           sei             
           ldaa  BitFlags_72
           anda  #0x04         ;  -00000100-
           ldab  Z83_CPU_Port1_copy
           andb  #0xfb         ;  -11111011-
           aba             
           eora  Z83_PortAdata
           cli             
           bita  0x00, X      ;  -00000000-
           beq   LA961     
           ldaa  0x08, X      ;  -00001000-
           cmpa  #0x0d         ;  -00001101-
           bne   LA94B     
           staa  Temp4     
           jsr   ThrowCriticalError
           bcc   LA961     
           ldab  #0x10         ;  -00010000-
           sei             
           orab  BitFlags_6d
           stab  BitFlags_6d
           cli             
           rts             

   LA94B:  cmpa  #0x0e         ;  -00001110-
           bne   LA95E     
           ldab  BitFlags_6f
           bmi   LA961     
           ldab  Z83_PortCdata
           bitb  #0x04         ;  -00000100-
           beq   LA961     
           ldab  KeyOnOrEngineRunningTime
           beq   LA961     
   LA95E:  jsr   LAD18     
   LA961:  rts             

CheckThrottleRoutine_MM:
           ldab  BitFlags_6d
           bitb  #0x40         ;  -01000000-
           bne   CheckThrottle_ErrorAlreadyFlagged
           ldaa  TPSVolts_11msUpdate
           cmpa  THRLOW_ThrottleLowerLimit
           bcs   CheckThrottle_BadTpsSignal
           cmpa  THRHIG_ThrottleUpperLimit
           bcs   CheckThrottle_GotTpsValue
CheckThrottle_BadTpsSignal:
           ldaa  Counter_MainLoop
           bita  #0x06         ;  -00000110-
           bne   CheckThrottle_AtFullThrottle
           ldaa  #0x16         ;  -00010110-
           staa  Temp4     
           jsr   ThrowCriticalError
           bcc   CheckThrottle_AtFullThrottle
           ldab  #0x40         ;  -01000000-
           sei             
           orab  BitFlags_6d
           stab  BitFlags_6d
           cli             
CheckThrottle_ErrorAlreadyFlagged:
           ldaa  #0x40         ;  -01000000-
           staa  MINTHR_LowestSessionTPS
           ldab  BitFlags_6f
           bmi   CheckThrottle_GotTpsValue
           ldab  MapValue  
           cmpb  MPTHR_MapSwitchPointForFullThrottleOrIdle
           bcs   CheckThrottle_GotTpsValue
           adda  WOTDLT_DeltaThrottleFrom_MINTHR_ToDetermineFullThrottle
CheckThrottle_GotTpsValue:
           staa  TpsVolts  
CheckThrottle_AtFullThrottle:
           ldab  BitFlags_6e
           bmi   LA9D2     
           ldab  Timer_CountdownFromStartRunForAisFeedback
           bne   LA9D2     
           ldab  BitFlags_6f
           bpl   LA9B3     
           ldab  BatteryVolts
           cmpb  #0xb2         ;  -10110010-
           bcs   LA9D2     
           bra   LA9B7     

   LA9B3:  ldab  KeyOnOrEngineRunningTime
           beq   LA9D2     
   LA9B7:  cmpa  MINTHR_LowestSessionTPS
           bcc   LA9D2     
           ldaa  Timer_DelayBeforeUpdating_MINTHR
           deca            
           bne   LA9D5     
           ldab  MINTHR_LowestSessionTPS
           cmpb  #0x10         ;  -00010000-
           bcc   LA9C9     
           ldab  MTHRMX_ValueOf_MINTHR_WhenBatteryDisconnected
   LA9C9:  decb            
           stab  MINTHR_LowestSessionTPS
           ldaa  BitFlags_6e
           anda  #0xbf         ;  -10111111-
           staa  BitFlags_6e
   LA9D2:  ldaa  MAXCNT_ProgramLoopsWithThrottleBelow_MINTHR_ToDecrement_MINTHR
   LA9D5:  staa  Timer_DelayBeforeUpdating_MINTHR
           rts             

IRQ1strobe3:
           ldaa  L200E     
           bita  #0x04         ;  -00000100-
           beq   LAA00     
           bsr   LAA01     
           beq   LA9EC     
           ldaa  #0x0b         ;  -00001011-
   LA9E5:  deca            
           bne   LA9E5     
           bsr   LAA01     
           bne   LA9FD     
   LA9EC:  eorb  #0x10         ;  -00010000-
           stab  Z83_PortAcontrol
           ldd   VehicleSpeed_HB
           addd  #0x014d   
           bcc   LA9FB     
           ldd   #0xffff   
   LA9FB:  std   VehicleSpeed_HB
   LA9FD:  ldaa  L2001     
   LAA00:  rti             

   LAA01:  ldaa  Z83_PortAcontrol
           tab             
           asla            
           eora  Z83_PortCdata
           anda  #0x20         ;  -00100000-
           rts             

ControlAirConditioning_MM:
           ldaa  ACLRPM_DisableAcBelowThisRPM_500
           sei             
           staa  Temp5     
           ldd   TargetIdleSpeed_HB
           jsr   mul16bit  
           cli             
           std   Temp0     
           ldaa  Z83_CPU_Port1_copy
           ldab  KeyOnOrEngineRunningTime
           cmpb  ACCTIM_AcDelayFromStartRunTransfer
           bcs   LAA4B     
           ldab  BitFlags_AIS
           bitb  #0x01         ;  -00000001-
           bne   LAA4B     
           ldab  TpsVolts  
           bita  #0x10         ;  -00010000-
           beq   LAA31     
           addb  #0x03         ;  -00000011-
   LAA31:  anda  #0xef         ;  -11101111-
           subb  MINTHR_LowestSessionTPS
           bcs   LAA3C     
           cmpb  ACOUT_DeltaAboveMinThrottleToCutOutAc
           bcc   LAA4B
   LAA3C:  ldx   EngineRpm_HB
           cpx   ACCRPM_DoNotAllowAcToEngageAboveThisRPM_4000
           bhi   LAA4F     
           cpx   TargetIdleSpeed_HB
           bcc   LAA4D     
           cpx   Temp0     
           bcc   LAA4F     
   LAA4B:  oraa  #0x10         ;  -00010000-
   LAA4D:  staa  Z83_CPU_Port1_copy
   LAA4F:  rts             

DealWithColdLoadEnrichment_MM:
           ldab  BitFlags_70
           bitb  #0x02         ;  -00000010-
           bne   LAA81     
           ldab  BitFlags_6e
           bitb  #0x10         ;  -00010000-
           bne   LAA77     
           ldab  HOTHLD_CurveAHotHoldTime
           ldaa  CoolantTemp
           cmpa  TMPHLD_TempSwitchPointForCurveAHoldDecay
           bcs   LAA69     
           ldab  CLDHLD_CurveAColdHoldTime
   LAA69:  stab  Temp0     
           ldd   KeyOnOrEngineRunningTime
           bita  #0xc0         ;  -11000000-
           bne   LAA77     
           asld            
           asld            
           cmpa  Temp0     
           bcs   LAA90     
   LAA77:  ldaa  #0xff         ;  -11111111-
           staa  Factor_ACVDCY_CurveACurveCDecayAfterRunModeReached
           ldaa  BitFlags_70
           oraa  #0x02         ;  -00000010-
           staa  BitFlags_70
   LAA81:  ldab  DCYTMH_CurveAHotDecayTime
           ldaa  CoolantTemp
           cmpa  TMPHLD_TempSwitchPointForCurveAHoldDecay
           bcs   LAA98     
           ldab  DCYTMC_CurveAColdDecayTime
           bra   LAA98     

   LAA90:  cmpa  CCURV_HoldTimeForCurveC
           bcs   LAAAA     
           ldab  DCYCC_DecayRateForCurveC
   LAA98:  ldaa  TimerOverflowsBetweenDistPulses
           bne   LAAAA     
           ldaa  Counter_MainLoop
           bita  #0x1f         ;  -00011111-
           bne   LAAAA     
           ldaa  Factor_ACVDCY_CurveACurveCDecayAfterRunModeReached
           sba             
           bcc   LAAA8
           clra            
   LAAA8:  staa  Factor_ACVDCY_CurveACurveCDecayAfterRunModeReached
   LAAAA:  rts             

Lookup4ByteTable:
           psha            
           tpa             
           ldab  0x00, X      ;  -00000000-
           std   Temp2     
           pula            
           inx             
           ldab  #0x04         ;  -00000100-
           cmpa  0x00, X      ;  -00000000-
           bhi   NextTableEntry
ReturnTableValue:
           ldaa  0x01, X      ;  -00000001-
           tab             
           rts             

NextTableEntry:
           dec   Temp3     
           beq   ReturnTableValue
           cmpa  0x04, X      ;  -00000100-
           bcs   FoundTableEntry
           abx             
           bra   NextTableEntry

FoundTableEntry:
           suba  0x00, X      ;  -00000000-
           sei             
           staa  Temp5     
           ldd   0x02, X      ;  -00000010-
           bsr   mul16bit  
           ldaa  Temp2     
           tap             
           addb  0x01, X      ;  -00000001-
           tba             
           rts             

mul16bit:
           pshb            
           ldab  Temp5     
           mul             
           std   Temp6     
           ldaa  Temp5     
           pulb            
           mul             
           adca  #0x00         ;  -00000000-
           tab             
           clra            
           addd  Temp6     
           rts             

ProcessMapOrTpsBlockData:
           ldaa  0x03, X      ;  -00000011-
           bne   LAAF3     
           clrb            
           ldaa  0x02, X      ;  -00000010-
           bra   LAB02     

   LAAF3:  staa  Temp5     
           ldd   0x00, X      ;  -00000000-
           bsr   mul16bit  
           std   Temp7     
           ldd   0x02, X      ;  -00000010-
           mul             
           subd  Temp7     
           addd  0x00, X      ;  -00000000-
   LAB02:  std   0x00, X      ;  -00000000-
           rts             

Lookup5ByteTable:
           ldab  #0x05         ;  -00000101-
           cmpa  0x00, X      ;  -00000000-
           bhi   LAB0F     
           ldd   0x01, X      ;  -00000001-
           rts             

   LAB0E:  abx             
   LAB0F:  cmpa  0x05, X      ;  -00000101-
           bhi   LAB0E     
           suba  0x00, X      ;  -00000000-
           staa  Temp5     
           ldd   0x03, X      ;  -00000011-
           bsr   mul16bit  
           addd  0x01, X      ;  -00000001-
           rts             

ScaleXbySignedB_ReturnD:
           pshb            
           lsra            
           ldd   0x00, X      ;  -00000000-
           bcs   LAB26     
           clra            
           clrb            
   LAB26:  std   0x02, X      ;  -00000010-
           ldaa  0x01, X      ;  -00000001-
           pulb            
           pshb            
           mul             
           adca  0x03, X      ;  -00000011-
           bcc   LAB33     
           inc   0x02, X      ;  -00000010-
   LAB33:  staa  0x03, X      ;  -00000011-
           pulb            
           ldaa  0x00, X      ;  -00000000-
           mul             
           addd  0x02, X      ;  -00000010-
           bcc   LAB40     
           ldd   #0xffff   
   LAB40:  rts             

DetermineNumberOfOverflowsBetweenDistributorPulses_MM:
           subd  LastDistributorFallingEdgeTime_HB
           staa  Temp5     
           ldaa  Counter_TimerPastHalfwayBetweenDistPulses
           lsrd            
           eorb  Temp5     
           bpl   LAB53     
           ldaa  Counter_TimerPastHalfwayBetweenDistPulses
           inca            
           beq   LAB53     
           staa  Counter_TimerPastHalfwayBetweenDistPulses
   LAB53:  ldaa  Counter_TimerPastHalfwayBetweenDistPulses
           lsra            
           cmpa  TimerOverflowsBetweenDistPulses
           bcs   LAB5C     
           staa  TimerOverflowsBetweenDistPulses
   LAB5C:  rts             

CalculateEngineRpm_MM:
           ldx   DistributorFallingEdgePulsewidth_HB
           ldaa  #0x0c         ;  -00001100-
           ldab  TimerOverflowsBetweenDistPulses
           beq   LAB69     
           ldx   TimerOverflowsBetweenDistPulses
           ldaa  #0x04         ;  -00000100-
   LAB69:  stx   Temp2     
           staa  Temp4     
           ldx   #Temp0    
           ldd   0x02, X      ;  -00000010-
           bne   LAB78     
           coma            
           comb            
           bra   LABA0     

   LAB78:  bmi   LAB81     
   LAB7A:  inc   0x04, X      ;  -00000100-
           asld            
           bpl   LAB7A     
           std   0x02, X      ;  -00000010-
   LAB81:  ldd   #0xe4e2   
           clr   0x00, X      ;  -00000000-
           clr   0x01, X      ;  -00000001-
   LAB88:  subd  0x02, X      ;  -00000010-
           bcc   LAB91     
           addd  0x02, X      ;  -00000010-
           clc             
           bra   LAB92     

   LAB91:  sec             
   LAB92:  rol   0x01, X      ;  -00000001-
           rol   0x00, X      ;  -00000000-
           lsr   0x02, X      ;  -00000010-
           ror   0x03, X      ;  -00000011-
           dec   0x04, X      ;  -00000100-
           bne   LAB88
           ldd   0x00, X      ;  -00000000-
   LABA0:  std   EngineRpm_HB
           rts             

SimulateMapReadingFromTps:
           ldab  EngineRpm_HB
           cmpb  #0x3f         ;  -00111111-
           ldaa  #0x00         ;  -00000000-
           bcc   LABC1     
           subb  #0x08         ;  -00001000-
           bcc   LABB0     
           clrb            
   LABB0:  ldaa  #0x29         ;  -00101001-
           mul             
           asld            
           asld            
           aslb            
           adca  MINTHR_LowestSessionTPS
           tab             
           ldaa  TpsVolts  
           adda  #0x0b         ;  -00001011-
           sba             
           bcc   LABC1     
           clra            
   LABC1:  ldx   #LMPINN_LimpinTableForMapFromThrottle
           jsr   Lookup5ByteTable
           tba             
           adda  MPLMOF_OffsetForCalcMapInMapLimpin
           rts             

CheckAndFilterChargeTempSensor_MM:
           ldab  DEFCHG_DefaultChargeTemp_Limpin
           ldaa  BitFlags_6d
           bita  #0x01         ;  -00000001-
           bne   LABF6     
           ldaa  Counter_MainLoop
           anda  #0x07         ;  -00000111-
           cmpa  #0x06         ;  -00000110-
           bne   LABF8     
           ldaa  LastChargeTempVolts
           ldab  ChargeTempVolts
           cmpa  CHGLOW_ChargeTempOutOfRangeLow
           bcs   InvalidChargeTemp
           cmpa  CHGHIG_ChargeTempOutOfRangeHigh
           bcc   InvalidChargeTemp
           sba             
           bcc   LABF1     
           decb            
           bra   LABF6

   LABF1:  cmpa  #0x03         ;  -00000011-
           bcs   LABF8     
           incb            
   LABF6:  stab  ChargeTempVolts
   LABF8:  rts             

InvalidChargeTemp:
           stab  ChargeTempVolts
           ldaa  #0x17         ;  -00010111-
           staa  Temp4     
           jsr   ThrowCriticalError
           bcc   LAC0C     
           ldaa  #0x01         ;  -00000001-
           sei             
           oraa  BitFlags_6d
           staa  BitFlags_6d
           cli             
   LAC0C:  rts             

CheckAndFilterCoolantTempSensor_MM:
           ldab  DEFTMP_DefaultEngineTemp
           ldaa  BitFlags_6d
           anda  #0x03         ;  -00000011-
           cmpa  #0x03         ;  -00000011-
           beq   SaveCoolantTemp
           cmpa  #0x02         ;  -00000010-
           bne   CoolantTempValueGood
           ldaa  LastChargeTempVolts
           ldx   #CHGTL1_TempForChargeTempA2D
           jsr   Lookup4ByteTable
           bra   SaveCoolantTemp

CoolantTempValueGood:
           ldaa  Counter_MainLoop
           anda  #0x07         ;  -00000111-
           cmpa  #0x02         ;  -00000010-
           bne   LAC69     
           ldaa  LastCoolantTempVolts
           cmpa  TMPLOW_OutOfRangeHotTooLowA2D
           bcs   LAC6A     
           cmpa  TMPHIG_OutOfRangeColdTooHighA2D
           bcc   LAC6A     
   LAC3A:  ldx   #TMPTL2_TempForHotScaleA2D
           ldab  CPU_Port1_ControlRegister
           bitb  #0x08         ;  -00001000-
           beq   LAC53     
           ldx   #TMPTL1_TempForColdScaleFromA2D
           cmpa  #0x40         ;  -01000000-
           bcc   LAC57     
   LAC4A:  sei             
           ldaa  CPU_Port1_ControlRegister
           eora  #0x08         ;  -00001000-
           staa  CPU_Port1_ControlRegister
           cli             
           rts             

   LAC53:  cmpa  #0xdc         ;  -11011100-
           bcc   LAC4A     
   LAC57:  jsr   Lookup4ByteTable
           ldab  CoolantTemp
           sba             
           bcc   LAC62     
           decb            
           bra   SaveCoolantTemp

   LAC62:  cmpa  #0x03         ;  -00000011-
           bcs   LAC69     
           incb            
SaveCoolantTemp:
           stab  CoolantTemp
   LAC69:  rts             

   LAC6A:  ldaa  #0x18         ;  -00011000-
           staa  Temp4     
           jsr   ThrowCriticalError
           bcc   LAC69     
           ldaa  #0x02         ;  -00000010-
           sei             
           oraa  BitFlags_6d
           staa  BitFlags_6d
           cli             
           rts             

VerifyOperationOfBatteryVoltage_MM:
           ldaa  BatteryVolts
           cmpa  #0x41         ;  -01000001-
           bcs   LAC8A     
           cmpa  #0x7c         ;  -01111100-
           bcs   LACAD     
           cmpa  #0x8d         ;  -10001101-
           bcc   LACAD     
   LAC8A:  ldaa  BitFlags_6f
           bmi   LACAD     
           ldaa  BitFlags_5D
           bita  #0x20         ;  -00100000-
           bne   LACAD     
           ldd   KeyOnOrEngineRunningTime
           cmpa  #0x15         ;  -00010101-
           bcs   LACAD     
           bitb  #0x7c         ;  -01111100-
           bne   LACAD     
           ldaa  #0x1b         ;  -00011011-
           staa  Temp4     
           jsr   ThrowCriticalError
           bcc   LACAD     
           ldaa  BitFlags_5D
           oraa  #0x20         ;  -00100000-
           staa  BitFlags_5D
   LACAD:  rts             

VerifyOperationOfO2SensorAnd:
           ldaa  Counter_MainLoop
           anda  #0x3f         ;  -00111111-
           cmpa  #0x38         ;  -00111000-
           beq   VerifyOperationOfO2Sensor
           cmpa  #0x18         ;  -00011000-
           beq   DetermineBattTemp
           cmpa  #0x08         ;  -00001000-
           bne   LACDE     
           ldaa  BitFlags_6d
           asla            
           oraa  BitFlags_6e
           bmi   LACDE     
           ldaa  KeyOnOrEngineRunningTime
           cmpa  ERRKON_KeyOnTimeLimitforErrorCodeSetting
           bcs   LACDE     
           ldaa  TargetIdleSpeed_HB
           adda  ERRRPM_RPMLimitforErrorCodeSetting
           cmpa  EngineRpm_HB
           bcc   LACDE     
           ldaa  VehicleSpeed_HB
           cmpa  ERRMPH_MPHLimitforErrorCodeSetting
           ldaa  #0x1c         ;  -00011100-
           bcs   LAD18     
   LACDE:  rts             

VerifyOperationOfO2Sensor:
           ldaa  CoolantTemp
           cmpa  CTLRPM_LowBatteryVoltageAtThisCoolantTemp
           bcs   LACDE     
           ldaa  EngineRpm_HB
           cmpa  BTLRPM_LowBatteryVoltageAtThisRpm1500
           bcs   LACDE     
           ldaa  KeyOnOrEngineRunningTime
           cmpa  O2MNRT_MiniumRunTimeForO2SensorDiag
           bcs   LACDE     
           ldaa  Counter_MainLoop
           bita  #0x40         ;  -01000000-
           beq   JumpToVerifyOperationOfO2SensorMore
           ldaa  #0x05         ;  -00000101-
           ldab  TargetBatteryVolts
           subb  BatteryVolts
           bcs   LACDE     
           cmpb  #0x10         ;  -00010000-
           bcc   LAD18     
           rts             

JumpToVerifyOperationOfO2SensorMore:
           jmp   VerifyOperationOfO2SensorMore

DetermineBattTemp:
           ldaa  #0x08         ;  -00001000-
           ldab  AmbientAirTempVolts
           cmpb  AMBLOW_BattTempLowWhenHot
           bls   LAD18     
           cmpb  AMBHIG_BattTempHighWhenCold
           bls   LACDE     
   LAD18:  staa  Temp4     
           bsr   SetErrorFlags
           ldab  0x00, X      ;  -00000000-
   LAD1E:  lsrb            
           deca            
           bne   LAD1E     
           bcs   LAD47     
ThrowCriticalError:
           ldx   #ClearTheErrorTimer_0
           ldd   0x00, X      ;  -00000000-
           anda  #0x1f         ;  -00011111-
           cmpa  Temp4     
           beq   LAD3D     
           inx             
           andb  #0x1f         ;  -00011111-
           cmpb  Temp4     
           beq   LAD3D     
           tstb            
           beq   LAD3D     
           dex             
           tsta            
           bne   LAD47     
   LAD3D:  ldab  0x00, X      ;  -00000000-
           addb  #0x20         ;  -00100000-
           bcs   LAD49     
           orab  Temp4     
           stab  0x00, X      ;  -00000000-
   LAD47:  clc             
           rts             

   LAD49:  clr   0x00, X      ;  -00000000-
           bsr   SetErrorFlags
           ldab  Temp4     
           cmpb  #0x1f         ;  -00011111-
           bhi   LAD61     
           clrb            
           sec             
   LAD55:  rolb            
           deca            
           bne   LAD55     
ThrowNonCriticalError:
           orab  0x00, X      ;  -00000000-
           stab  0x00, X      ;  -00000000-
           orab  0x04, X      ;  -00000100-
           stab  0x04, X      ;  -00000100-
   LAD61:  sec             
           rts             

SetErrorFlags:
           ldx   #AutoCalCell12
           ldaa  Temp4     
   LAD68:  inx             
           suba  #0x08         ;  -00001000-
           bhi   LAD68     
           adda  #0x08         ;  -00001000-
           rts             

DetermineTargetIdleSpeed_MM:
           ldab  BitFlags_AIS
           bitb  #0x80         ;  -10000000-
           bne   LADAC     
           ldaa  #0xbc         ;  -10111100-
           ldab  BitFlags_70
           bitb  #0x04         ;  -00000100-
           bne   LADA6     
           ldaa  #0x7d         ;  -01111101-
           ldab  BitFlags_6d
           bitb  #0x02         ;  -00000010-
           bne   LADA6     
           ldx   #AISCLD_IdleSpeedDrive_FromTemp
           ldab  Z83_PortCdata
           bitb  #0x08         ;  -00001000-
           bne   LAD93     
           ldx   #AISPN_IdleSpeedParkNeutral_FromTemp
   LAD93:  ldaa  CoolantTemp
           jsr   Lookup4ByteTable
           ldab  STTIME_AdditionalStartupIdleTime
           cmpb  KeyOnOrEngineRunningTime
           bcs   LADA6     
           adda  DRIDHT_AdditionalStartupIdle
           bcc   LADA6     
           ldaa  #0xff         ;  -11111111-
   LADA6:  clrb            
           lsrd            
           lsrd            
           lsrd            
           std   TargetIdleSpeed_HB
   LADAC:  rts             

CalculateBaseFuelModifier_MM:
           clra            
           staa  Temp0     
           ldab  BitFlags_6e
           lsrb            
           bcs   LADEF     
           ldab  Timer_OpenLoopFraction
           cmpb  LMTOLF2_LimitTimerOpenLoopFraction2
           bcc   LADEF     
           jsr   AllowForHeatSoakAfterStall
           staa  Temp1     
           ldab  BitFlags_70
           bitb  #0x02         ;  -00000010-
           bne   LADD4     
           ldx   #CURVEC_FuelColdEnrichmentCurveC
           jsr   Lookup4ByteTable
           ldab  Factor_ACVDCY_CurveACurveCDecayAfterRunModeReached
           mul             
           adca  #0x00         ;  -00000000-
           staa  Temp0     
   LADD4:  ldaa  Temp1     
           ldx   #CURVEA_FuelColdEnrichmentCurveA
           jsr   Lookup4ByteTable
           ldab  BitFlags_70
           bitb  #0x02         ;  -00000010-
           beq   LADE7     
           ldab  Factor_ACVDCY_CurveACurveCDecayAfterRunModeReached
           mul             
           adca  #0x00         ;  -00000000-
   LADE7:  adda  Temp0     
           bcc   LADED     
           ldaa  #0xff         ;  -11111111-
   LADED:  staa  Temp0     
   LADEF:  ldaa  CoolantTemp
           ldx   #CURVEB_FuelColdEnrichmentCurveB
           jsr   Lookup4ByteTable
           clra            
           addb  Temp0     
           rola            
           asld            
           std   Temp0     
           ldaa  BitFlags_6e
           lsra            
           bcs   LAE26     
           ldaa  Timer_OpenLoopFraction
           suba  LMTOLF2_LimitTimerOpenLoopFraction2
           bcc   LAE26     
           ldx   #HMPMUL_ColdLoadFromMAP
           ldaa  MapValue  
           jsr   Lookup4ByteTable
           psha            
           ldx   #HIGHMP_ColdLoadFromCoolantTemp
           ldaa  CoolantTemp
           jsr   Lookup4ByteTable
           pula            
           mul             
           lsrd            
           lsrd            
           lsrd            
           lsrd            
           lsrd            
           addd  Temp0     
           std   Temp0     
   LAE26:  ldaa  BaroPressure
           ldx   #BAROCP_BaroCompensationOfWarmupFactor_FromBaro
           jsr   Lookup4ByteTable
           clra
           ldx   #Temp0    
           jsr   ScaleXbySignedB_ReturnD
           inca            
           std   Temp0     
           deca            
           lsrd            
           lsrd            
           lsrd            
           stab  BaseFuelModifier
           rts             

CalculateOtherFuelModifiers_MM:
           ldx   #AIRTMP_FuelEnrichmentFromChargeTemp
           ldaa  ChargeTempVolts
           jsr   Lookup4ByteTable
           psha            
           ldx   #PEFTBL_PumpingEfficiency_FromRpm
           ldd   EngineRpm_HB
           asld            
           jsr   Lookup4ByteTable
           ldx   #Temp0    
           clra            
           jsr   ScaleXbySignedB_ReturnD
           std   Temp0     
           ldab  Timer_Leanout
           beq   LAE64     
           clra            
           jsr   ScaleXbySignedB_ReturnD
           std   Temp0     
   LAE64:  ldaa  #0x01         ;  -00000001-
           pulb            
           jsr   ScaleXbySignedB_ReturnD
           std   Temp0     
           ldab  PointerIntoAdaptiveMemory
           ldx   #AutoCalCell0
           abx             
           ldab  0x00, X      ;  -00000000-
           ldaa  BitFlags_6e
           lsra            
           bcs   LAE80     
           ldaa  Timer_OpenLoopFraction
           cmpa  LMTOLF2_LimitTimerOpenLoopFraction2
           bcs   LAE88     
   LAE80:  cmpb  ADMEMA_ValueFromAdaptivememoryAdder1
           bgt   LAE88     
           ldab  ADMEMA_ValueFromAdaptivememoryAdder1
   LAE88:  clra            
           tstb            
           bmi   LAE8D     
           inca            
   LAE8D:  asrb            
           ldx   #Temp0    
           jsr   ScaleXbySignedB_ReturnD
           std   Temp0
           clra            
           ldab  Counter_PrimaryAndSecondaryRamp
           bmi   LAE9C     
           inca            
   LAE9C:  asrb            
           jsr   ScaleXbySignedB_ReturnD
           std   SumOfFuelModifiers_HB
           rts             

IncrementLoopCounters_MM:
           ldaa  Timer_AisChanges
           inca            
           beq   LAEAA     
           staa  Timer_AisChanges
   LAEAA:  ldaa  TimerOverflowsBetweenDistPulses
           cmpa  #0x04         ;  -00000100-
           bcs   LAECA     
           sei             
           ldaa  BitFlags_6f
           oraa  #0x82         ;  -10000010-
           bita  #0x20         ;  -00100000-
           beq   LAEBE     
           anda  #0xdf         ;  -11011111-
           clr   Counter_FallingEdgeEPP_MaxFF
   LAEBE:  staa  BitFlags_6f
           cli             
           ldaa  BitFlags_6e
           anda  #0xef         ;  -11101111-
           staa  BitFlags_6e
           clr   CurrentWastegateDutyCycle
   LAECA:  inc   Counter_MainLoop
           bne   LAEE9     
           ldab  BitFlags_5D
           andb  #0xfc         ;  -11111100-
           stab  BitFlags_5D
           sei             
           ldaa  KeyOnOrEngineRunningTime
           inca            
           beq   LAEDD     
           staa  KeyOnOrEngineRunningTime
   LAEDD:  cli             
           ldaa  BitFlags_6f
           bmi   LAEE9     
           ldaa  VerySlowCounter2point6seconds
           inca            
           beq   LAEE9     
           staa  VerySlowCounter2point6seconds
   LAEE9:  rts             

IncludePWModifier:
           ldx   #Temp7    
           ldd   SumOfFuelModifiers_HB
           std   Temp7     
           ldab  Temp6
           clra            
           jsr   ScaleXbySignedB_ReturnD
           std   Temp7     
           ldaa  Temp5     
           ldab  SumOfFuelModifiers_LB
           mul             
           addd  Temp7     
           std   Temp7     
           ldab  SumOfFuelModifiers_HB
           ldaa  Temp5     
           mul             
           tsta            
           bne   LAF0E     
           addb  Temp7     
           bcc   LAF10     
   LAF0E:  ldab  #0xff         ;  -11111111-
   LAF10:  tba             
           ldab  Temp8     
           rts             

AllowForHeatSoakAfterStall:
           ldaa  CoolantTemp
           cmpa  RUNLMT_MaxAllowableTempFor_RUNTMP
           bcc   LAF2F     
           ldaa  VerySlowCounter2point6seconds
           ldx   #RUNTMP_ModifierOf_ENGTMP_FromStalltime
           jsr   Lookup4ByteTable
           ldaa  CoolantTemp
           aba             
           ldab  RUNLMT_MaxAllowableTempFor_RUNTMP
           bcs   LAF2E     
           cba             
           bcs   LAF2F     
   LAF2E:  tba             
   LAF2F:  rts             

DRB_SendROMSerial_MM:
           ldaa  BitFlags_70
           bpl   LAF4D     
           ldd   CPU_SCI_TxRxCntrlReg
           ldx   #CPU_Port1_DataDirection
           abx             
           ldab  0x00, X      ;  -00000000-
           ldaa  BitFlags_70
           anda  #0xfb         ;  -11111011-
           cpx   #0x00fe   
           bne   LAF49     
           ldab  EngineRpm_HB
           oraa  #0x04         ;  -00000100-
   LAF49:  staa  BitFlags_70
           bra   LAF95     

   LAF4D:  ldaa  Counter_MainLoop
           lsra
           bcc   LAF97     
           ldaa  BitFlags_70
           anda  #0xfb         ;  -11111011-
           ldab  CPU_SCI_TxRxCntrlReg
           bpl   LAF6C     
           ldab  CPU_SCI_RxDataReg
           cmpb  #0x12         ;  -00010010-
           bne   LAF66     
           ldab  #0x05         ;  -00000101-
           stab  CPU_SCI_ModeControlReg
           oraa  #0x80         ;  -10000000-
   LAF66:  cmpb  #0xf0         ;  -11110000-
           bne   LAF6C     
           oraa  #0x04         ;  -00000100-
   LAF6C:  staa  BitFlags_70
           ldaa  CPU_SCI_RxDataReg
           ldaa  O2SensorVolts
           ldab  #0xff         ;  -11111111-
           cmpa  O2MIDH_HighLimitForInMiddleDetermination
           bhi   LAF80     
           cmpa  O2MIDL_LowLimitForInMiddleDetermination
           bhi   LAF82     
           andb  #0xa0         ;  -10100000-
   LAF80:  andb  #0xb1         ;  -10110001-
   LAF82:  ldx   #ADScanIndex
   LAF85:  inx             
           cpx   #MaxRetardFromMAP
           beq   LAF95     
           ldaa  0x00, X      ;  -00000000-
           anda  #0x3f         ;  -00111111-
           beq   LAF85     
           andb  #0x0f         ;  -00001111-
           orab  #0x80         ;  -10000000-
   LAF95:  stab  CPU_SCI_TxDataReg
   LAF97:  rts             

KnockDetect_MM:
           clra            
           ldab  EngineRpm_HB
           cmpb  KNKRPM_MinRpmforKnockRetard
           bcs   LAFC6     
           ldx   #RETMAX_MaxKnockRetardFromMap
           deca            
           ldab  BitFlags_6d
           andb  #0xc0         ;  -11000000-
           bne   LAFC3     
           ldaa  MapValue  
           ldab  TpsVolts  
           subb  MINTHR_LowestSessionTPS
           bcs   LAFC3     
           cmpb  THRKNK_DeltaAbove_MINTHR
           bcs   LAFC3     
           ldab  EngineRpm_HB
           cmpb  KLMRPM_MinKnockDetectRpm
           bcc   LAFC3     
           ldaa  KNKLIM_MaxKnockRetard
           bra   LAFC6     

   LAFC3:  jsr   Lookup4ByteTable
   LAFC6:  staa  MaxRetardFromMAP
           ldaa  EngineRpm_HB
           ldx   #DLTKNK_KnockFromRpms
           jsr   Lookup4ByteTable
           staa  KnockLookup
           rts             

WorkWithPowerLossLight_MM:
           ldaa  BitFlags_6f
           bpl   LAFE2     
           ldaa  KeyOnOrEngineRunningTime
           bne   LAFF9     
   LAFDB:  clrb            
   LAFDC:  sei             
           jsr   LA828     
           cli             
           rts             

   LAFE2:  ldaa  BitFlags_70
           bita  #0x08         ;  -00001000-
           beq   LAFEC     
           ldaa  BitFlags_6e
           bmi   LAFDB     
   LAFEC:  ldaa  BitFlags_6d
           bita  PLMASK_PowerLossLightMask
           bne   LAFDB     
           ldaa  BitFlags_5D
           bita  #0x20         ;  -00100000-
           bne   LAFDB     
   LAFF9:  ldab  #0x20         ;  -00100000-
           bra   LAFDC

;  ______________________
; |                      \
; |   Modifications      |
; \______________________|


UseCELForKnockIndication_MM:
           ; first, need to check that the option is enabled...
           ; added 11/07, RCL
           ; modifed to eliminate use of CHEMReserved

           ldaa CONFIG_ConfigurationFlags
           bita #cfg_FlashCE   ; check the bit for the CE Flash mod
           beq  CEReturn        ; branch if the bit is not set, ie not enabled

           ldaa BitFlags_6f
           bmi  CEReturn        ; don't do this if Engine Not Running
           ldaa CoolantTemp
           cmpa KNKMIN_FlashCEMinTemp
           bcs  CEReturn        ; don't do this if cold motor (otherwise a LOT of false positives)

           ldab CPU_Port1_ControlRegister
           ldaa Cylinder4Retard
           anda #0x3f
           bne  CELightOn     ; not zero, turn on power loss light
           ldaa Cylinder2Retard
           anda #0x3f
           bne  CELightOn     ; not zero, turn on power loss light
           ldaa Cylinder1Retard
           anda #0x3f
           bne  CELightOn     ; not zero, turn on power loss light
           ldaa Cylinder3Retard
           anda #0x3f
           bne  CELightOn     ; not zero, turn on power loss light
CELightOff:
           andb ~#0x20 ; clear the CE Light bit
           bra  CEStore
CELightOn:
           orab #0x20 ; set the CE Light bit
CEStore:
           stab CPU_Port1_ControlRegister
CEReturn:
           rts

CalculateAntiLagRetard_Routine_MM:
        ldaa 0x00                   ; load 0x00 into A, default anti-lag retard
; check that the option is enabled...
        ldab CONFIG_ConfigurationFlags
        bitb #cfg_AntiLag
        beq  AntiLag_return       ;return if not enabled ; anti-lag retard = 0
; check the conditions for anti-lag - 1st check for the staging limiter, then for WOT, then for negative MAP
        ldab BitFlags_72
        bitb #flg_bit5            ;using this bit to tell that the limiter is active - for the anti-lag retard
        bne  L3000                ;branch if the bit is set; if set, ignore the WOT requirement, otherwise check for WOT
        ldab BitFlags_6e
        lsrb ;bitb #flg_FullThrottle
        bcc  AntiLag_return       ; return if not WOT ; anti-lag retard = 0
L3000:  ldab BoostTarget            ; load the target boost
        subb MapValue             ; subtract the actual MAP value
        bcs  AntiLag_return	  ; branch if greater or equal - no need for antilag ; anti-lag retard = 0
        tba                       ; move DeltaMAP to A for the lookup
        ldx  #ANTLAG_AntiLagRetardfromBoostTargetDelta   ; load index with value
        jsr  Lookup4ByteTable          ; call:
        lsra                      ; divide result by 2
        lsra                      ; divide result by 2
        lsra                      ; divide result by 2 - total dived by 8

AntiLag_return:
        staa AntiLagRetard        ; store the antilag retard
        rts


           .org	0xbf00
BoostButtonCopyrightNoticeLower:
           .str   "Turbonator mods and brand Copr. 2012 Rob Lloyd"
           .byte  0x00, 0x00
           .str   "Turbonator GLHS v1"
           .byte  0x00, 0x00


           .org	0xbfa0
ChryslerCopyrightNoticeLower:
	   .str   "COPR. 1985 CHRYSLER CORP."
           .byte  0x00, 0x00

           .msg "Lower Assembly Complete."

           .org DataOrg

; *****************************************************************************
; load cal data
; *****************************************************************************

        .include /CalDataFile/

; *****************************************************************************
; begin code - upper chip
; *****************************************************************************

        .org UpperChipCodeOrg
        .msg "Assembling Upper Code..."

CalculateTargetIdleSpeedAndAisPosition_MM:
           ldaa  BitFlags_AIS
           bita  #0x08         ;  -00001000-
           bne   LE5DD     
           ldab  Counter_MainLoop
           andb  #0x7e         ;  -01111110-
           bne   LE5DD     
           anda  #0xfb         ;  -11111011-
           staa  BitFlags_AIS
   LE5DD:  ldab  BitFlags_5D
           orab  BitFlags_6f
           bpl   LE600     
           ldaa  DesiredNewAisPosition
           cmpa  CurrentAisPosition
           bne   LE5F5     
           ldab  BitFlags_AIS
           bitb  #0x40         ;  -01000000-
           bne   LE5F5     
           ldab  BitFlags_5D
           andb  #0x7f         ;  -01111111-
           stab  BitFlags_5D
   LE5F5:  ldaa  CoolantTemp
           ldx   #AISTRT_AisStartupPosition_FromTemp
           jsr   Lookup4ByteTable
           jmp   LE7C6     

   LE600:  ldab  BitFlags_6d
           bpl   LE610     
           ldaa  DEFAIS_DefaultAISStartPosition
           staa  DesiredNewAisPosition
           ldaa  BitFlags_AIS
           anda  #0xfe         ;  -11111110-
           staa  BitFlags_AIS
           rts             

   LE610:  clra            
           staa  Temp1     
           ldaa  Z83_PortCdata
           anda  #0x04         ;  -00000100-
           staa  Temp0     
           ldab  BitFlags_5D
           andb  #0x04         ;  -00000100-
           eorb  Temp0     
           beq   LE676     
           ldaa  KeyOnOrEngineRunningTime
           cmpa  ACCTIM_AcDelayFromStartRunTransfer
           bcs   LE670     
           eorb  BitFlags_5D
           stab  BitFlags_5D
           bitb  #0x04         ;  -00000100-
           beq   LE657     
           ldaa  BitFlags_6e
           bpl   LE64C     
           ldx   #ACCTBL_ACOffIdleDelta_FromSpeed
           ldaa  VehicleSpeed_HB
           jsr   Lookup4ByteTable
           ldab  OFFPER2_AisInstantlyClosesWhenAcDisengages2
           mul             
           tab             
           ldaa  DesiredNewAisPosition
           sba             
           bcc   LE648     
           clra            
   LE648:  staa  DesiredNewAisPosition
           bra   LE652     

   LE64C:  ldaa  IAISOP_IdleAISOpenStepsNegative
           jsr   LE7FA     
   LE652:  clra            
           staa  Timer_AisOrO2Sensor
           bra   LE66D     

   LE657:  ldaa  ACTIME_TimeBeforeAcEnabledAndFullDeltaUsed
           staa  Timer_AisOrO2Sensor
           ldaa  BitFlags_6e
           bmi   LE666     
           ldaa  ACOFFK_ClosedThrottleAcOffKick
           jsr   LE7FA     
   LE666:  ldaa  Timer_AisOrO2Sensor
           beq   LE66B     
   LE66A:  deca            
   LE66B:  staa  Timer_AisOrO2Sensor
   LE66D:  clra            
           staa  Timer_AisChanges
   LE670:  ldaa  BitFlags_AIS
           oraa  #0x01         ;  -00000001-
           bra   LE694     

   LE676:  tsta            
           bne   LE670     
           ldaa  Timer_AisOrO2Sensor
           cmpa  #0x01         ;  -00000001-
           bcs   LE690     
           bne   LE66A     
           ldaa  BitFlags_6e
           bmi   LE68B     
           ldaa  AC2KCK_AcClutchKickOpenAfterAcEnabled
           jsr   LE821     
   LE68B:  clra            
           staa  Timer_AisOrO2Sensor
           staa  Timer_AisChanges
   LE690:  ldaa  BitFlags_AIS
           anda  #0xfe         ;  -11111110-
   LE694:  staa  BitFlags_AIS
           ldaa  Temp1     
           beq   LE69B     
   LE69A:  rts             

   LE69B:  ldab  BitFlags_6e
           bpl   LE6BD     
           ldaa  BitFlags_AIS
           anda  #0x7f         ;  -01111111-
           staa  BitFlags_AIS
           ldab  Z83_PortCdata
           bitb  #0x10         ;  -00010000-
           beq   LE6BA     
           ldx   #BRKRPM_BrakeOverrideForAis_FromDeltaThrottle
           ldaa  TpsVolts  
           suba  MINTHR_LowestSessionTPS
           jsr   Lookup4ByteTable
           cmpb  EngineRpm_HB
           bcs   LE6BD     
   LE6BA:  jmp   LE749     

   LE6BD:  ldab  BitFlags_AIS
           bitb  #0x20         ;  -00100000-
           bne   LE6BA     
           ldaa  BitFlags_70
           anda  #0x40         ;  -01000000-
           oraa  Timer_CountdownFromStartRunForAisFeedback
           bne   LE69A     
           ldaa  DesiredNewAisPosition
           cmpa  #0x04         ;  -00000100-
           bcs   LE6D5     
           andb  #0xfd         ;  -11111101-
           stab  BitFlags_AIS
   LE6D5:  ldaa  BitFlags_5D
           andb  #0x80         ;  -10000000-
           beq   LE706     
           ldx   #DRPNK_DriveToParkNeutralKicks_FromTemp
           bita  #0x08         ;  -00001000-
           beq   LE6EB     
           ldx   #PNDRK_ParkNeutralToDriveKicks_FromTemp
           ldd   TargetIdleSpeed_HB
           subd  EngineRpm_HB
           bra   LE6EF     

   LE6EB:  ldd   EngineRpm_HB
           subd  TargetIdleSpeed_HB
   LE6EF:  bcs   LE706     
           subd  PNDLTN_DeltaRpmChangeToUse_DRPNK_or_PNDRK
           bcs   LE706     
           ldaa  CoolantTemp
           jsr   Lookup4ByteTable
           jsr   StoreAndLimitDesiredAisPosition
           ldaa  BitFlags_AIS
           anda  #0x7f         ;  -01111111-
           staa  BitFlags_AIS
           bra   LE745     

   LE706:  ldab  DCLRF2_TimeBetweenAisPulsesForDecelAis2
           cmpb  Timer_AisChanges
           bcc   LE748
           ldaa  BitFlags_AIS
           anda  #0xf7         ;  -11110111-
           staa  BitFlags_AIS
           ldx   #FWDAIS_ForwardAisSteps_NoSlope
           ldd   TargetIdleSpeed_HB
           subd  EngineRpm_HB
           bcc   LE723     
           ldx   #REVAIS_ReverseAisSteps_NoSlope
           ldd   EngineRpm_HB
           subd  TargetIdleSpeed_HB
   LE723:  lsrd            
           lsrd            

;### changed this code to look at the config flags instead of the whole byte

           tst  CONFIG_ConfigurationFlags
           bpl  LE732 ;branch if bit 7 is NOT set, IE manual trans

;          tst  Manual00_AutomaticFF    ;  (data is 00)
;          beq  LE732          ; branch if equal (zero)

           psha
           ldaa  BitFlags_5D
           bita  #0x08         ;  -00001000-
           pula            
           bne   LE733     
   LE732:  lsrd            
   LE733:  tsta            
           beq   LE738     
           ldab  #0xff         ;  -11111111-
   LE738:  tba             
           cmpa  0x01, X      ;  -00000001-
           bcs   LE748     
           jsr   Lookup4ByteTable
           beq   LE748     
           jsr   StoreAndLimitDesiredAisPosition
   LE745:  clra            
           staa  Timer_AisChanges
   LE748:  rts             

   LE749:  ldaa  BitFlags_AIS
           oraa  #0x08         ;  -00001000-
           staa  BitFlags_AIS
           ldaa  CoolantTemp
           ldx   #CLDPOS_AisColdPosition_FromTemp
           jsr   Lookup4ByteTable
           staa  Temp0     
           ldaa  BaroPressure
           ldx   #BARAIS_BaroCompensation_FromBaro
           jsr   Lookup4ByteTable
           ldaa  Temp0     
           mul             
           asld            
           bcs   LE7DA     
           asld            
           bcs   LE7DA     
           staa  Temp0     
           ldaa  EngineRpm_HB
           ldx   #RPMPOS_AisPosition_FromRpm
           jsr   Lookup4ByteTable
           cmpa  Temp0
           bcs   LE77A     
           staa  Temp0     
   LE77A:  ldaa  TpsVolts  
           suba  MINTHR_LowestSessionTPS
           bcc   LE781     
           clra            
   LE781:  ldx   #THRPOS_AisPosition_FromThrottle
           jsr   Lookup4ByteTable
           cmpa  Temp0     
           bcs   LE78D     
           staa  Temp0     
   LE78D:  clra            
           ldab  BitFlags_5D
           bitb  #0x04         ;  -00000100-
           bne   LE7B6     
           ldaa  ACPOS_ACPositionWhenTempToCold
           bitb  #0x20         ;  -00100000-
           bne   LE7B6     
           ldab  CoolantTemp
           cmpb  ACTMP_AisTempSwap
           bcs   LE7B6     
           ldx   #ACCTBL_ACOffIdleDelta_FromSpeed
           ldaa  VehicleSpeed_HB
           jsr   Lookup4ByteTable
           ldab  BitFlags_AIS
           bitb  #0x01         ;  -00000001-
           beq   LE7B6     
           ldab  OFFPER_AisInstantlyClosesWhenAcDisengages
           mul             
           adca  #0x00         ;  -00000000-
   LE7B6:  ldab  Temp0     
           aba             
           bcs   LE7DA     
           ldab  BitFlags_5D
           bitb  #0x08         ;  -00001000-
           bne   LE7C6     
           adda  PNPOS_ParkNeutralPosition
           bcs   LE7DA     
   LE7C6:  ldab  BitFlags_AIS
           bitb  #0x10         ;  -00010000-
           bne   LE7D5     
           bitb  #0x02         ;  -00000010-
           bne   LE7D5     
           adda  CALPOS_PositionAisMotorIsAtIdle
           bcs   LE7DA     
   LE7D5:  cmpa  AISHLM_AisHighLimitMaxOpenSteps
           bcs   LE7DD     
   LE7DA:  ldaa  AISHLM_AisHighLimitMaxOpenSteps
   LE7DD:  ldab  BitFlags_AIS
           bitb  #0x20         ;  -00100000-
           beq   LE7E9     
           andb  #0xdf         ;  -11011111-
           stab  BitFlags_AIS
           bra   LE7F7

   LE7E9:  cmpa  DesiredNewAisPosition
           bcc   LE7F7     
           ldab  Counter_MainLoop
           bitb  CALRAT_AisAdjustRate
           bne   LE7F9     
           ldaa  DesiredNewAisPosition
           deca            
   LE7F7:  staa  DesiredNewAisPosition
   LE7F9:  rts             

   LE7FA:  ldab  BitFlags_AIS
           bitb  #0x04         ;  -00000100-
           beq   LE81D     
           andb  #0xfb         ;  -11111011-
           stab  BitFlags_AIS
           ldaa  IAISOP_IdleAISOpenStepsNegative
           ldab  BitFlags_5D
           bitb  #0x04         ;  -00000100-
           beq   LE817     
           ldaa  ACOFFK_ClosedThrottleAcOffKick
           ldab  Timer_AisOrO2Sensor
           bne   LE817     
           adda  AC2KCK_AcClutchKickOpenAfterAcEnabled
   LE817:  nega            
           clrb            
           stab  Timer_AisOrO2Sensor
           bra   LE821     

   LE81D:  orab  #0x0c         ;  -00001100-
           stab  BitFlags_AIS
   LE821:  ldab  #0xff         ;  -11111111-
           stab  Temp1     
StoreAndLimitDesiredAisPosition:
           tsta            
           bmi   LE835     
           ldab  AISHLM_AisHighLimitMaxOpenSteps
           adda  DesiredNewAisPosition
           bcs   LE832     
           cba             
           bcs   LE83A     
   LE832:  tba             
           bra   LE83A     

   LE835:  adda  DesiredNewAisPosition
           bcs   LE83A     
           clra            
   LE83A:  staa  DesiredNewAisPosition
           rts             

MM_L1597:
           ldab  BitFlags_5D
           andb  #0x08         ;  -00001000-
           stab  Temp0
           ldab  Z83_PortCdata
           andb  #0x08         ;  -00001000-
           eorb  Temp0     
           beq   LE85D     
           eorb  BitFlags_5D
           stab  BitFlags_5D
           ldaa  BitFlags_70
           asla            
           oraa  BitFlags_6d
           bmi   LE85D     
           ldab  BitFlags_AIS
           orab  #0x80         ;  -10000000-
           stab  BitFlags_AIS
   LE85D:  rts             

DetermineTargetBatteryVoltage_MM:
           ldab  AmbientAirTempVolts
           ldaa  #0xe3         ;  -11100011-
           cmpb  AMBLOW_BattTempLowWhenHot
           bcs   LE87D     
           cmpb  AMBHIG_BattTempHighWhenCold
           bhi   LE87D     
           ldaa  #0x20         ;  -00100000-
           mul             
           adca  #0xd1         ;  -11010001-
           cmpa  #0xec         ;  -11101100-
           bcs   LE877     
           ldaa  #0xec         ;  -11101100-
   LE877:  cmpa  #0xd8         ;  -11011000-
           bcc   LE87D     
           ldaa  #0xd8         ;  -11011000-
   LE87D:  staa  TargetBatteryVolts
           ldaa  Timer_VoltageRegSignal
           cmpa  #0xf0         ;  -11110000-
           bcs   LE89A     
           ldab  Counter_MainLoop
           bitb  #0x7c         ;  -01111100-
           bne   LE89A     
           suba  #0x60         ;  -01100000-
           staa  Timer_VoltageRegSignal
           ldaa  KeyOnOrEngineRunningTime
           cmpa  #0x10         ;  -00010000-
           bcs   LE89A     
           ldaa  #0x0b         ;  -00001011-
           jsr   LAD18     
   LE89A:  ldab  BitFlags_6f
           bmi   LE8CC     
           clrb            
           ldaa  BatteryVolts
           suba  TargetBatteryVolts
           bcs   LE8BF     
           cmpa  #0x10         ;  -00010000-
           bcs   LE8BF     
           ldaa  BitFlags_6d
           bita  #0x08         ;  -00001000-
           bne   LE8CC     
           ldaa  Counter_MainLoop
           bita  #0x7c         ;  -01111100-
           bne   LE8CC     
           ldaa  #0x06         ;  -00000110-
           staa  Temp4     
           jsr   ThrowCriticalError
           bcc   LE8CC     
           rorb            
   LE8BF:  sei             
           ldaa  BitFlags_6d
           oraa  #0x08         ;  -00001000-
           tstb            
           bmi   LE8C9     
           anda  #0xf7         ;  -11110111-
   LE8C9:  staa  BitFlags_6d
           cli             
   LE8CC:  rts             

DetermineIfWindowedBladeInSyncSensorOnDistributor_MM:
           ldaa  BitFlags_5D
           ldab  BitFlags_6f
           bpl   LE8ED     
           bitb  #0x04         ;  -00000100-
           bne   LE8ED     
           ldab  CPU_Port2_ControlRegister
           lsrb            
           bcs   LE8EF     
           ldab  Z83_PortCdata
           bmi   LE8E5     
           oraa  #0x40         ;  -01000000-
           bra   LE8F1     

   LE8E5:  bita  #0x40         ;  -01000000-
           beq   LE8F3     
           oraa  #0x10         ;  -00010000-
           bra   LE8F1     

   LE8ED:  anda  #0xef         ;  -11101111-
   LE8EF:  anda  #0xbf         ;  -10111111-
   LE8F1:  staa  BitFlags_5D
   LE8F3:  rts             

ResetRoutine:
           sei
           ldd   #0xff00   
           std   Z83_PortAdata
           ldaa  Z85_ADConverter5
           lds   #0x00ff   
           ldd   #0xbe04   
           std   CPU_Port1_DataDirection
           ldd   #0xfd6f   
           std   Z83_PortADataDirection
           ldd   #0x080a
           staa  CPU_Port1_ControlRegister
   LE911:  jsr   LEC25     
           decb            
           bne   LE911     
           ldaa  Z85_ADConverter1
           cmpa  #0x0f         ;  -00001111-
           bls   LE929     
           clrb            
           cmpa  #0x40         ;  -01000000-
           bcc   LE925     
           stab  CPU_Port1_ControlRegister
   LE925:  ldaa  CPU_RAM_ControlReg
           bmi   LE986     
   LE929:  ldd   #0x150a   
           std   CPU_SCI_ModeControlReg
           ldaa  #0x55         ;  -01010101-
           staa  CPU_OCR_HB
   LE932:  ldd   CPU_SCI_TxRxCntrlReg
           ldaa  CPU_OCR_HB
           staa  CPU_SCI_TxDataReg
           ldx   #0x01aa   
   LE93B:  cpx   #CPU_TimerControlStatReg
           bne   LE943     
           ldab  Z85_ADConverter5
   LE943:  dex             
           bne   LE93B     
           ldab  Z85_ADConverter1
           cmpb  #0x40         ;  -01000000-
           bcc   LE950     
           clr   CPU_Port1_ControlRegister
   LE950:  tst   CPU_RAM_ControlReg
           bpl   LE958     
           tstb            
           bpl   LE986     
   LE958:  ldab  CPU_SCI_TxRxCntrlReg
           bpl   LE986     
           ldab  CPU_SCI_RxDataReg
           cba             
           bne   LE932     
           ldx   #CPU_Port1_DataDirection
           ldab  #0xfe         ;  -11111110-
   LE966:  tba             
   LE967:  ldab  CPU_SCI_TxRxCntrlReg
           bpl   LE967     
           ldab  CPU_SCI_RxDataReg
           stab  CPU_SCI_TxDataReg
           cmpa  #0xfe         ;  -11111110-
           bne   LE978     
           abx             
           stx   CPU_OCR_HB
           inca            
           tab             
   LE978:  cmpa  #0xff         ;  -11111111-
           beq   LE966
           stab  0x00, X      ;  -00000000-
           inx             
           deca            
           bne   LE967     
           ldx   CPU_OCR_HB
           jmp   0x00, X      ;  -00000000-

   LE986:  ldaa  #0x40         ;  -01000000-
           staa  BitFlags_AIS
           ldx   #BitFlags_AIS
           ldaa  MINTHR_LowestSessionTPS
           cmpa  LowestHistoricalTPS
           bne   LE997     
           ldaa  CPU_RAM_ControlReg
           bmi   LE9A9     
   LE997:  ldaa  MTHRMX_ValueOf_MINTHR_WhenBatteryDisconnected
           ldab  #0x80         ;  -10000000-
           std   MINTHR_LowestSessionTPS
           stab  DCCOR1_AdaptiveWastegateCellBelowMAPPT
           stab  DCCOR2_AdaptiveWastegateCellAboveMAPPT
           ldaa  #0xdf         ;  -11011111-
           staa  CurrentAisPosition
           ldx   #DCCOR2_AdaptiveWastegateCellAboveMAPPT
   LE9A9:  jsr   LEC25     
           clrb            
   LE9AD:  inx             
           stab  0x00, X      ;  -00000000-
           cpx   #0x00ff   
           bne   LE9AD     
           stab  Z83_PortCDataDirection
           ldaa  #0x08         ;  -00001000-
           std   Z83_PortAcontrol
           ldaa  Z83_PortAdata
           bita  #0x02         ;  -00000010-
           bne   LE9CA     
           ldaa  BitFlags_71
           oraa  #0x01         ;  -00000001-
           staa  BitFlags_71
   LE9CA:  ldab  #0xff         ;  -11111111-
           stab  Z83_PortADataDirection
           stab  Z83_CPU_Port1_copy
           jsr   LEC25     
           jsr   VerifyOperationOfMapSensor_MM
           staa  BaroPressure
           staa  MapValue  
           staa  MapVolts  
           staa  AverageMAPValue
           staa  StackPtrTemp_HB
           ldaa  CPU_RAM_ControlReg
           bmi   LE9EB     
           ldaa  ErrorBitRegisterStored3
           oraa  #0xc0         ;  -11000000-
           staa  ErrorBitRegisterStored3
   LE9EB:  ldaa  #0x40         ;  -01000000-
           staa  Cylinder2Retard
           ldaa  BitFlags_AIS
           eora  #0x40         ;  -01000000-
           staa  BitFlags_AIS
           ldab  AISMotorBits
           ldx   #AISTEP_BitPatternForAisControl
           abx             
           ldaa  0x00, X      ;  -00000000-
           staa  Z83_PortBdata
           ldd   #0x8210   
           std   BitFlags_6f
           ldd   #0x20f9   
           staa  Z83_PortCcontrol
           stab  CPU_TimerControl1
           ldd   CPU_Counter_HB
           addd  #CPU_PortX_ControlStatReg
           std   CPU_OCR_HB
           std   CPU_OCR2_HB
           std   CPU_OCR3_HB
           ldd   #0x0373   
           stab  CPU_TimerControl2
           ldab  #0xf6         ;  -11110110-
           stab  CPU_Port2_DataDirection
           anda  BitFlags_5D
           cmpa  #0x02         ;  -00000010-
           bne   LEA2A     
           jmp   ResetStartup

   LEA2A:  inca            
           staa  BitFlags_5D
   LEA2D:  ldaa  Z85_ADConverter2
           ldd   #0x04ff   
           staa  BitFlags_6e
           staa  Timer_DelayBeforeUpdating_MINTHR
           ldaa  #0x80         ;  -10000000-
           staa  BitFlags_6d
           ldaa  #0x84         ;  -10000100-
           oraa  BitFlags_5D
           anda  #0x87         ;  -10000111-
           staa  BitFlags_5D
           stab  Counter_TimerPastHalfwayBetweenDistPulses
           stab  TimerOverflowsBetweenDistPulses
           stab  Factor_ACVDCY_CurveACurveCDecayAfterRunModeReached
           stab  Timer_Over5PSIBoost
           stab  BoostTarget
   LEA4D:  decb            
           bne   LEA4D     
           ldaa  Z85_ADConverterCoolantTemp
           staa  AmbientAirTempVolts
   LEA55:  decb            
           bne   LEA55     
           ldaa  Z85_ADConverter4
           staa  TpsVolts  
           staa  AverageTPSVolts
           ldab  MINTHR_LowestSessionTPS
           addb  MININC_Amount_MINTHR_IsIncreasedAtKeyOnOnly
           cmpb  MTHRMX_ValueOf_MINTHR_WhenBatteryDisconnected
           bcs   LEA72     
           adda  #0x06         ;  -00000110-
           ldab  MTHRMX_ValueOf_MINTHR_WhenBatteryDisconnected
           cba             
           bcc   LEA72     
           tab             
   LEA72:  stab  MINTHR_LowestSessionTPS
           clrb            
   LEA75:  decb            
           bne   LEA75     
           ldaa  Z85_ADConverter5
           staa  ChargeTempVolts
           ldab  #0x19         ;  -00011001-
   LEA7F:  decb            
           bne   LEA7F     
           ldaa  Z85_ADConverterCoolantTemp
           staa  LastCoolantTempVolts
           ldx   #TMPTL1_TempForColdScaleFromA2D
           ldab  CPU_Port1_ControlRegister
           bitb  #0x08         ;  -00001000-
           bne   LEA93     
           ldx   #TMPTL2_TempForHotScaleA2D
   LEA93:  jsr   Lookup4ByteTable
           staa  CoolantTemp
           cmpa  #0xa6         ;  -10100110-
           bcc   LEAA6     
           ldab  AmbientAirTempVolts
           cmpb  #0x99         ;  -10011001-
           bcs   LEAA6     
           ldab  #0x40         ;  -01000000-
           stab  Timer_RadSteamingCountdown
   LEAA6:  ldaa  CoolantTemp
           cmpa  TTEMPL_TstatDiagnosticsMinTempToArmDiagnosticsAtStartup
           bcs   LEAB5     
           cmpa  TTEMPH_TstatDiagnosticsMaxTempToArmDiagnosticsAtStartup
           bcc   LEAB5     
           inc   Timer_ThermostatDiagnostics
   LEAB5:  jsr   LA809     
           ldd   #0x060a   
           std   CPU_SCI_ModeControlReg
           ldd   #0x135d   
           staa  CPU_TimerControlStatReg
           stab  Z83_PortAdata
           stab  Z83_CPU_Port1_copy
           ldaa  CPU_TimerStatus
           staa  CPU_OCR_HB
           staa  CPU_OCR3_HB
           staa  CPU_OCR2_HB
           ldaa  CPU_TimerControlStatReg
           ldaa  CPU_ICR_HB
           ldaa  CPU_Counter_HB
           tab             
           jmp   LED7D     

IRQtOut:
           ldaa  CPU_TimerStatus
           bita  #0x08         ;  -00001000-
           bne   HandleDwellTimer
           ldab  BitFlags_6f
           lsrb            
           bcc   LEAF0     
           bita  #0x20         ;  -00100000-
           beq   SelectWhichRoutineToRun
           jsr   HandleOtherTimerInterrupts
           rti             

SelectWhichRoutineToRun:
           jsr   Injector34Off
           rti             

   LEAF0:  bita  #0x10         ;  -00010000-
           beq   LEAF7     
           bsr   ControlWGOutput
           rti             

   LEAF7:  ldx   #CPU_OCR3_HB
           ldab  #0xfb         ;  -11111011-
           jsr   LEBCE     
           rti             

HandleDwellTimer:
           ldaa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           bne   LEB2A     
           bita  #0x04         ;  -00000100-
           beq   LEB2A     
           ldab  TimerOverflowsBetweenDistPulses
           bne   LEB2A     
           ldaa  CPU_TimerControlStatReg
           eora  #0x01         ;  -00000001-
           staa  CPU_TimerControlStatReg
           lsra            
           bcs   LEB1B     
           ldd   DwellTime_HB
           bra   IgnitionCoil_OnTimeLoad

   LEB1B:  lsra            
           bcs   IgnitionCoil_OffTimeLoad
           ldaa  CPU_TimerControlStatReg
           anda  #0xfe         ;  -11111110-
           staa  CPU_TimerControlStatReg
IgnitionCoil_OffTimeLoad:
           ldd   DistributorFallingEdgePulsewidth_HB
           subd  DwellTime_HB
           bra   IgnitionCoil_OnTimeLoad

   LEB2A:  ldd   #0x7000   
IgnitionCoil_OnTimeLoad:
           addd  CPU_OCR_HB
           std   CPU_OCR_HB
           rti             

ControlWGOutput:
           ldaa  BitFlags_6f
           bmi   LEBB3     
           ldd   Timer16bitCopyB_HB
           subd  CPU_Counter_HB
           cmpa  #0xc9         ;  -11001001-
           bcc   LEB42     
           cmpa  #0x02         ;  -00000010-
           bcc   LEB7C     
   LEB42:  ldab  BitFlags_72
           ldaa  CurrentWastegateDutyCycle
           beq   LEB50     
           cmpa  #0xc8         ;  -11001000-
           bcc   LEB57     
           bitb  #0x04         ;  -00000100-
           bne   LEB59     
   LEB50:  orab  #0x04         ;  -00000100-
           nega            
           adda  #0xc8         ;  -11001000-
           bra   LEB5B     

   LEB57:  ldaa  #0x64         ;  -01100100-
   LEB59:  andb  #0xfb         ;  -11111011-
   LEB5B:  stab  BitFlags_72
           ldab  Z83_PortADataDirection
           orab  #0x04         ;  -00000100-
           stab  Z83_PortADataDirection
           clrb            
           addd  CPU_Counter_HB
           std   Timer16bitCopyB_HB
           ldaa  Z83_PortAdata
           anda  #0xfb         ;  -11111011-
           ldab  BitFlags_72
           andb  #0x04         ;  -00000100-
           aba             
           staa  Z83_PortAdata
           ldab  #0x0b         ;  -00001011-
   LEB79:  decb            
           bne   LEB79     
   LEB7C:  ldd   Timer16bitCopyB_HB
           subd  CPU_Counter_HB
           std   Temp5     
           ldd   Timer16bitCopyA_HB
           subd  CPU_Counter_HB
           subd  Temp5     
           bcs   LEB8E     
           cmpa  #0x02         ;  -00000010-
           bcc   LEBA0     
   LEB8E:  ldaa  CPU_Port1_ControlRegister
           bita  #0x02         ;  -00000010-
           beq   LEBA0     
           ldd   Timer16bitCopyA_HB
           std   CPU_OCR2_HB
           ldaa  CPU_TimerControl1
           anda  #0xfd         ;  -11111101-
           staa  CPU_TimerControl1
           bra   LEBA4     

   LEBA0:  ldd   Timer16bitCopyB_HB
           std   CPU_OCR2_HB
   LEBA4:  ldab  BatteryVolts
           cmpb  #0xa2         ;  -10100010-
           bcs   LEBB2     
           ldab  Z83_PortADataDirection
           andb  #0xfb         ;  -11111011-
           stab  Z83_PortADataDirection
   LEBB2:  rts             

   LEBB3:  ldaa  Z83_PortADataDirection
           oraa  #0x04         ;  -00000100-
           staa  Z83_PortADataDirection
           ldaa  BitFlags_72
           oraa  #0x04         ;  -00000100-
           staa  BitFlags_72
           ldaa  Z83_PortAdata
           oraa  #0x04         ;  -00000100-
           staa  Z83_PortAdata
           ldx   #CPU_OCR2_HB
           ldab  #0xfd         ;  -11111101-
   LEBCE:  ldaa  0x01, X      ;  -00000001-
           staa  0x01, X      ;  -00000001-
           ldaa  BitFlags_72
           bita  #0x02         ;  -00000010-
           beq   LEBDC     
           anda  #0xfd         ;  -11111101-
           bra   LEBE2     

   LEBDC:  bita  #0x01         ;  -00000001-
           beq   LEBE8     
           anda  #0xfe         ;  -11111110-
   LEBE2:  staa  BitFlags_72
           bita  #0x03         ;  -00000011-
           bne   LEBEC     
   LEBE8:  andb  CPU_TimerControl1
           stab  CPU_TimerControl1
   LEBEC:  rts             

NMIInterrupt:
           sts   StackPtrTemp_HB
           lds   #0x6000   
           ldaa  MINTHR_LowestSessionTPS
           staa  LowestHistoricalTPS
           ldaa  #0x83         ;  -10000011-
           staa  CPU_RAM_ControlReg
           ldd   #0x060a   
           std   CPU_SCI_ModeControlReg
           ldd   #0xff32   
           staa  Z83_PortAdata
           staa  Z83_PortADataDirection
   LEC08:  decb            
           beq   LEC11     
           jmp   LEC08     

   LEC11:  ldaa  #0xc3         ;  -11000011-
           staa  CPU_RAM_ControlReg
           ldaa  Z83_CPU_Port1_copy
           staa  Z83_PortAdata
           lds   StackPtrTemp_HB
           tst   StackPtrTemp_HB
           bne   LEC22     
           rti             

   LEC22:  jmp   ResetRoutine     

   LEC25:  ldaa  CPU_Port2_ControlRegister
           eora  #0x04         ;  -00000100-
           staa  CPU_Port2_ControlRegister
           rts             

ElevenMillisecondLoop:
           jsr   DRB_SendROMSerial_MM
           jsr   DetermineIfWindowedBladeInSyncSensorOnDistributor_MM
           jsr   Throttle_MM
           jsr   A2DScan_MM
           bsr   LEC25     
           sei             
           ldd   VehicleSpeed_HB
           lsrd            
           lsrd            
           lsrd            
           lsrd            
           lsrd            
           std   Temp0     
           ldd   VehicleSpeed_HB
           subd  Temp0     
           std   VehicleSpeed_HB
           cli             
           ldaa  Counter_MainLoop
           lsra            
           bcc   First44msLoop
           jmp   TwentyTwoMillisecondLoop

First44msLoop:
           lsra            
           bcc   Second44msLoop
           jsr   CheckAndFilterCoolantTempSensor_MM
           jsr   A2DScan_MM
           jsr   CheckAndFilterChargeTempSensor_MM
           jsr   A2DScan_MM
           jsr   CalculateSparkAdvance_MM
           jsr   A2DScan_MM
           jsr   CalculateBaseFuelModifier_MM
           jsr   CalculateOtherFuelModifiers_MM
           jsr   A2DScan_MM
           jsr   ModifyO2FeedbackCountVarToMaintainStoich_MM
           jsr   A2DScan_MM
           jsr   DetermineTargetBatteryVoltage_MM
           jsr   VerifyOperationOfThermostat_MM
           jsr   A2DScan_MM
           jsr   VerifyOperationOfBatteryVoltage_MM
           jsr   CalculateInjectorPulsewidthForStarting_MM
           jsr   A2DScan_MM
           jsr   MM_L1597  
           jmp   BackTo11msLoop

Second44msLoop:
           jsr   A2DScan_MM
           jsr   HandleBaroReadRequirement_MM
           jsr   HandleAmTimer_MM
           jsr   CalculatePTEFactors_MM
           jsr   A2DScan_MM
           jsr   HandleO2Processing_MM
           jsr   VerifyOperationOfO2SensorAnd
           ldaa  BitFlags_6f
           bmi   LECAB     
           jsr   DealWithColdLoadEnrichment_MM
   LECAB:  jsr   A2DScan_MM
           jsr   IncrementSlowCounter_MM
           jsr   DetermineFuelTweaks_MM
           jsr   A2DScan_MM
           jsr   DetermineTargetIdleSpeed_MM
           jsr   ConfirmO2GoodAndAdjustKnockRetard_MM
           jsr   KnockDetect_MM
           jsr   CalculateAntiLagRetard_Routine_MM
           jsr   ControlFan2_MM
           jsr   A2DScan_MM
           jsr   ControlAsdRelay_MM
           jsr   ControlPurgeSolenoid_MM
           jsr   AdaptiveMemory_DetermineWhichCellApplies_MM
           jsr   A2DScan_MM
           jsr   SetMapErrorCode_MM
           jsr   WorkWithPowerLossLight_MM
           jsr   A2DScan_MM
           jsr   UseCELForKnockIndication_MM
           jsr   CalcTargetBoost_MM
           jsr   ControlAirConditioning_MM
           jsr   SetFlagForPTE_MM
           tst   BitFlags_6f
           bmi   LECEC     
           jsr   CalculatePartThrottleEnrichmentFuel_MM
   LECEC:  bra   BackTo11msLoop

TwentyTwoMillisecondLoop:
           jsr   KickUpAisBy2DuringDecel_MM
           jsr   A2DScan_MM
           jsr   CalculateTargetIdleSpeedAndAisPosition_MM
           jsr   CalculateAisPosition_MM
           jsr   A2DScan_MM
           ldaa  BitFlags_6f
           bmi   LED13     
           jsr   CalculateTransientFuelAddition_MM
           asld            
           bcs   LED0D     
           asld            
           bcs   LED0D     
           asld            
           bcc   LED10     
   LED0D:  ldd   #0xffff   
   LED10:  sei             
           std   Pulsewidth_PartThrottleEnrichment_HB
   LED13:  ldd   Pulsewidth_PartThrottleEnrichment_HB
           cli             
           lsrd            
           lsrd            
           lsrd            
           lsrd            
           lsrd            
           tsta            
           beq   LED20     
           ldab  #0xff         ;  -11111111-
   LED20:  stab  BitFlags_D3
           jsr   A2DScan_MM
           jsr   LEEA4_MM  
           jsr   CalculateEngineRpm_MM
           jsr   A2DScan_MM
           jsr   ControlEngineCutout_MM
           jsr   A2DScan_MM
           jsr   CheckThrottleRoutine_MM
           jsr   ThrottleCheckPart2_MM
           jsr   SetTPSFlags_MM
           jsr   A2DScan_MM
           jsr   CalcWGDutyCycle_MM
           jsr   A2DScan_MM
           sei             
           ldd   CPU_Counter_HB
           jsr   DetermineNumberOfOverflowsBetweenDistributorPulses_MM
           cli             
BackTo11msLoop:
           jsr   A2DScan_MM
           jsr   IncrementLoopCounters_MM
           ldaa  MinimumTimerCountBeforeMainloopCanContinue
           suba  #0x15         ;  -00010101-
   LED57:  cmpa  CPU_Counter_HB
           bpl   LED57     
           jsr   A2DScan_MM
           ldaa  MinimumTimerCountBeforeMainloopCanContinue
           suba  #0x10         ;  -00010000-
   LED62:  cmpa  CPU_Counter_HB
           bpl   LED62     
           jsr   A2DScan_MM
           ldaa  MinimumTimerCountBeforeMainloopCanContinue
           suba  #0x08         ;  -00001000-
   LED6D:  cmpa  CPU_Counter_HB
           bpl   LED6D     
           jsr   A2DScan_MM
           sei             
           ldaa  MinimumTimerCountBeforeMainloopCanContinue
           ldab  CPU_Counter_HB
           cba             
           bmi   LED7D     
           tab             
   LED7D:  addb  #0x2b         ;  -00101011-
           stab  MinimumTimerCountBeforeMainloopCanContinue
           cli             
   LED82:  cmpa  CPU_Counter_HB
           bpl   LED82     
           jmp   ElevenMillisecondLoop

InterruptFromDistributorSyncAndSpeedSensor:
           ldaa  CPU_TimerStatus
           bmi   LEDC7     
           ldab  Z83_PortCdata
           andb  #0x80         ;  -10000000-
           stab  Temp6     
           ldaa  BitFlags_6f
           bmi   LEDB7     
           ldab  CPU_Port1_ControlRegister
           bitb  #0x02         ;  -00000010-
           beq   LEDB7     
           ldd   Timer16bitCopyA_HB
           subd  CPU_Counter_HB
           bmi   LEDB7     
           subd  #0x09c4   
           bcc   LEDB7     
           ldx   Timer16bitCopyA_HB
           cpx   CPU_OCR2_HB
           beq   LEDB7     
           stx   CPU_OCR2_HB
           ldaa  CPU_TimerControl1
           anda  #0xfd         ;  -11111101-
           staa  CPU_TimerControl1
   LEDB7:  ldaa  CPU_TimerControlStatReg
           ldd   CPU_ICR_HB
           jsr   DetermineNumberOfOverflowsBetweenDistributorPulses_MM
           ldaa  CPU_TimerControlStatReg
           tab             
           lsra            
           eora  CPU_Port2_ControlRegister
           lsra
           bcc   LEDCA     
   LEDC7:  ldab  CPU_ICR2_HB
           rti             

   LEDCA:  orab  #0x18         ;  -00011000-
           stab  CPU_TimerControlStatReg
           ldaa  ErrorBitRegisterStored3
           anda  #0x7f         ;  -01111111-
           staa  ErrorBitRegisterStored3
           bitb  #0x02         ;  -00000010-
           bne   LEDE9     
           ldab  Z85_ADConverter1
           ldab  Z85_ADConverter1
           ldab  Z83_PortBdata
           andb  #0xdf         ;  -11011111-
           stab  Z83_PortBdata
           jmp   LF0DD     

   LEDE9:  ldaa  EngineRpm_HB
           cmpa  #0x47         ;  -01000111-
           bcs   LEE0A     
           ldaa  BitFlags_6f
           bita  #0x04         ;  -00000100-
           beq   LEE10     
           ldaa  CPU_ICR_HB
           suba  LastDistributorFallingEdgeTime_HB
           ldab  #0x03         ;  -00000011-
           mul             
           ldaa  BitFlags_6f
           cmpb  DistributorFallingEdgePulsewidth_HB
           bcc   LEE06     
           oraa  #0x40         ;  -01000000-
           bra   LEE3B     

   LEE06:  anda  #0xbf         ;  -10111111-
           bra   LEE55     

   LEE0A:  ldaa  BitFlags_6f
           bita  #0x04         ;  -00000100-
           bne   LEE2A     
   LEE10:  andb  #0xfd         ;  -11111101-
           stab  CPU_TimerControlStatReg
           ldab  BitFlags_5D
           bitb  #0x10         ;  -00010000-
           beq   LEE2A     
           oraa  #0x04         ;  -00000100-
           staa  BitFlags_6f
           ldd   Cylinder2Retard
           oraa  #0xc0         ;  -11000000-
           orab  #0x40         ;  -01000000-
           andb  #0x7f         ;  -01111111-
           std   Cylinder2Retard
           bra   LEE5F     

   LEE2A:  ldab  Temp6     
           lsrb            
           staa  Temp5     
           anda  #0xbf         ;  -10111111-
           aba             
           eorb  Temp5     
           aslb            
           bpl   LEE93     
           ldab  Temp6     
           bpl   LEE55     
   LEE3B:  oraa  #0x04         ;  -00000100-
           staa  BitFlags_6f
           ldd   Cylinder2Retard
           anda  #0x3f         ;  -00111111-
           andb  #0x3f         ;  -00111111-
           orab  #0x80         ;  -10000000-
           std   Cylinder2Retard
           ldaa  BitFlags_6f
           lsra            
           bcs   LEE7F     
           ldab  CPU_TimerControlStatReg
           orab  #0x02         ;  -00000010-
           stab  CPU_TimerControlStatReg
   LEE54:  rti             

   LEE55:  staa  BitFlags_6f
           ldd   Cylinder2Retard
           adda  #0x40         ;  -01000000-
           addb  #0x40         ;  -01000000-
           std   Cylinder2Retard
   LEE5F:  ldaa  BitFlags_6f
           lsra            
           bcs   LEE7F     
           bita  #0x02         ;  -00000010-
           beq   LEE54     
           ldaa  CPU_Port1_ControlRegister
           anda  #0x7f         ;  -01111111-
           staa  CPU_Port1_ControlRegister
           ldab  Z85_ADConverter1
           ldab  Z85_ADConverter1
           ldaa  Z83_PortBdata
           oraa  #0x20         ;  -00100000-
           staa  Z83_PortBdata
           jmp   LF2B0     

   LEE7F:  asla            
           staa  BitFlags_6f
           ldaa  #0xe9         ;  -11101001-
           staa  CPU_TimerControl1
           ldd   CPU_Counter_HB
           addd  #CPU_PortX_ControlStatReg
           std   CPU_OCR3_HB
           lds   #0x00ff
           jmp   LEA2D

   LEE93:  ldab  Cylinder2Retard
           bitb  #0xc0         ;  -11000000-
           bne   LEE55     
           anda  #0xfb         ;  -11111011-
           staa  BitFlags_6f
           ldaa  BitFlags_72
           oraa  #0x08         ;  -00001000-
           staa  BitFlags_72
           rti             

LEEA4_MM:
           ldd   #0x060a   
           tst   BitFlags_70
           bpl   LEEAD     
           deca            
   LEEAD:  std   CPU_SCI_ModeControlReg
           ldd   #0xbef6   
           std   CPU_Port1_DataDirection
           ldaa  #0x10         ;  -00010000-
           sei             
           oraa  CPU_TimerControlStatReg
           anda  #0xfb         ;  -11111011-
           staa  CPU_TimerControlStatReg
           ldd   CPU_TimerControl1
           oraa  #0xe0         ;  -11100000-
           andb  #0x7f         ;  -01111111-
           orab  #0x50         ;  -01010000-
           std   CPU_TimerControl1
           ldaa  Z83_PortAcontrol
           anda  #0x18         ;  -00011000-
           oraa  #0x08         ;  -00001000-
           staa  Z83_PortAcontrol
           cli             
           clra            
           staa  Z83_PortCDataDirection
           ldd   #0x0020   
           std   Z83_PortBcontrol
           rts             

HandleOtherTimerInterrupts:
           ldd   #0x4268   
           addd  CPU_OCR3_HB
           std   CPU_OCR3_HB
           jsr   LEC25     
           cli             
           ldx   LastDistributorFallingEdgeTime_HB
           inx             
           beq   LEEF7     
           stx   LastDistributorFallingEdgeTime_HB
           ldaa  Z83_PortBdata
           eora  #0x60         ;  -01100000-
           staa  Z83_PortBdata
   LEEF7:  ldab  #0xdf         ;  -11011111-
           orab  Z83_CPU_Port1_copy
           stab  Z83_CPU_Port1_copy
           ldaa  LastDistributorFallingEdgeTime_LB
           bmi   LEF07     
           ldaa  CPU_Port1_ControlRegister
           anda  #0xef         ;  -11101111-
           staa  CPU_Port1_ControlRegister
   LEF07:  cpx   #0x003f   
           bcs   LEF61     
           cpx   #DwellTime_HB
           bne   LEF16     
           ldab  #0x20         ;  -00100000-
           jsr   LA828     
   LEF16:  ldaa  LastDistributorFallingEdgeTime_LB
           cmpa  #0x03         ;  -00000011-
           bne   LEF1F     
           jmp   LA7C6     

   LEF1F:  ldab  BitFlags_71
           andb  #0x01         ;  -00000001-
           bne   LEF61     
           ldab  BitFlags_6e
           bpl   LEF61     
           bita  #0x3f         ;  -00111111-
           bne   LEF5D     
           ldab  Z83_PortAdata
           orab  #0x02         ;  -00000010-
           stab  Z83_PortAdata
           ldab  #0xff         ;  -11111111-
           stab  Z83_PortADataDirection
           ldab  #0x08         ;  -00001000-
   LEF3C:  decb            
           bne   LEF3C     
           stab  Z83_PortADataDirection
           ldab  #0x08         ;  -00001000-
   LEF44:  decb            
           bne   LEF44     
           ldab  Z83_PortAdata
           bitb  #0x02         ;  -00000010-
           bne   LEF5D     
           ldaa  BitFlags_D3
           inca            
           cmpa  #0x0c         ;  -00001100-
           bcs   LEF57     
           ldaa  #0x01         ;  -00000001-
   LEF57:  staa  BitFlags_D3
           ldab  #0x02         ;  -00000010-
           stab  LastDistributorFallingEdgeTime_HB
   LEF5D:  ldaa  BitFlags_D3
           bne   LEF8C     
   LEF61:  jsr   LF068     
           ldaa  BitFlags_6e
           bpl   LEF8B     
           ldaa  Z83_PortCdata
           anda  #0xfc         ;  -11111100-
           cmpa  Temp2     
           beq   LEF8B     
           staa  Temp2     
           cmpa  CPU_SCI_TxRxCntrlReg
           clra            
           clrb            
           tst   BaseFuelModifier
           bne   LEF7F     
           ldd   #0x8820   
   LEF7F:  staa  CPU_SCI_TxDataReg
           staa  BaseFuelModifier
           ldaa  BitFlags_6e
           asla            
           bpl   LEF8B     
           jsr   LA828     
   LEF8B:  rts             

   LEF8C:  ldab  BitFlags_6e
           orab  #0x20         ;  -00100000-
           stab  BitFlags_6e
           cpx   #0x4b00   
           bcc   LEF61     
           ldab  CPU_SCI_TxRxCntrlReg
           bitb  #0xc0         ;  -11000000-
           beq   LEFA6     
           ldab  CPU_SCI_RxDataReg
           cmpb  #0xf0         ;  -11110000-
           bne   LEFA6     
           jmp   LF06B     

   LEFA6:  tab             
           cmpb  #0x0a         ;  -00001010-
           bcs   LEFB2     
           ldaa  #0x10         ;  -00010000-
           cmpb  #0x0b         ;  -00001011-
           bne   LEFB2     
           inca            
   LEFB2:  staa  CPU_SCI_TxDataReg
           tba             
           ldab  #0xfd         ;  -11111101-
           cmpa  #0x06         ;  -00000110-
           beq   LF02E     
           cmpa  #0x02         ;  -00000010-
           bhi   LEFC3     
           andb  Z83_CPU_Port1_copy
           stab  Z83_CPU_Port1_copy
   LEFC3:  ldab  LastDistributorFallingEdgeTime_LB
           cmpa  #0x03         ;  -00000011-
           beq   LF042     
           cmpa  #0x04         ;  -00000100-
           beq   LF03B     
           ldab  #0xef         ;  -11101111-
           cmpa  #0x05         ;  -00000101-
           beq   LF02E     
           ldab  #0xbf         ;  -10111111-
           cmpa  #0x07         ;  -00000111-
           beq   LF02E     
           ldab  #0x7f         ;  -01111111-
           cmpa  #0x08         ;  -00001000-
           beq   LF02E     
           ldab  #0xfb         ;  -11111011-
           cmpa  #0x09         ;  -00001001-
           beq   LF02E     
           ldab  #0xfe         ;  -11111110-
           cmpa  #0x0a         ;  -00001010-
           beq   LF02E     
           cmpa  #0x0b         ;  -00001011-
           bne   LEFFB     
           ldaa  LastDistributorFallingEdgeTime_LB
           bpl   LF068     
           ldaa  CPU_Port1_ControlRegister
           oraa  #0x10         ;  -00010000-
           staa  CPU_Port1_ControlRegister
           bra   LF068     

   LEFFB:  ldab  LastDistributorFallingEdgeTime_LB
           aslb            
           bne   LF068     
           cmpa  #0x01         ;  -00000001-
           beq   LF053     
           ldaa  #0x02         ;  -00000010-
           oraa  CPU_TimerControl1
           staa  CPU_TimerControl1
           ldd   CPU_Counter_HB
           addd  #CPU_Counter_LB
           std   CPU_OCR2_HB
           ldaa  CPU_Port1_ControlRegister
           oraa  #0x04         ;  -00000100-
           staa  CPU_Port1_ControlRegister
           ldaa  CPU_TimerStatus
           ldd   CPU_OCR2_HB
           std   CPU_OCR2_HB
           ldd   CPU_TimerControl1
           anda  #0xfd         ;  -11111101-
           orab  #0x10         ;  -00010000-
           std   CPU_TimerControl1
           ldd   DFTOC2_SomeKindOfDefaultValueForOCR2
           addd  CPU_OCR2_HB
           std   CPU_OCR2_HB
           bra   LF068     

   LF02E:  clra            
           staa  Cylinder1Retard
           ldaa  LastDistributorFallingEdgeTime_LB
           bmi   LF068     
   LF035:  andb  Z83_CPU_Port1_copy
           stab  Z83_CPU_Port1_copy
           bra   LF068     

   LF03B:  aslb            
           bne   LF068     
           ldab  #0xf7         ;  -11110111-
           bra   LF035     

   LF042:  ldaa  #0x20         ;  -00100000-
           cmpb  #0x20         ;  -00100000-
           beq   LF064     
           cmpb  #0x45         ;  -01000101-
           beq   LF063     
           bra   LF068     

   LF04E:  addd  #CPU_PortX_ControlStatReg
           std   CPU_OCR_HB
   LF053:  ldaa  CPU_TimerControlStatReg
           eora  #0x01         ;  -00000001-
           staa  CPU_TimerControlStatReg
           lsra            
           ldd   CPU_Counter_HB
           bcc   LF04E     
           addd  #0x1b60   
           std   CPU_OCR_HB
   LF063:  nega            
   LF064:  adda  CurrentAisPosition
           staa  DesiredNewAisPosition
   LF068:  jmp   LA848     

   LF06B:  tab             
           cmpa  #0x08         ;  -00001000-
           bcs   LF075     
           clrb            
           cmpa  #0x08         ;  -00001000-
           bhi   LF0D9     
   LF075:  ldx   #Z85_ADConverter1
           abx             
           ldaa  0x00, X      ;  -00000000-
           cmpb  #0x04         ;  -00000100-
           bne   LF08F     
           clr   CoolantTemp
           jsr   LAC3A     
           ldab  #0x2e         ;  -00101110-
           mul             
           adca  #0xec         ;  -11101100-
           bcs   LF0CC     
           clra            
           bra   LF0CC     

   LF08F:  cmpb  #0x07         ;  -00000111-
           bne   LF0A0     
           ldab  #0xfd         ;  -11111101-
           mul             
           adca  #0x00         ;  -00000000-
           lsra            
           lsra            
           lsra            
           lsra            
           adca  #0x00         ;  -00000000-
           bra   LF0CC     

   LF0A0:  cmpb  #0x06         ;  -00000110-
           bne   LF0C4     
           ldab  Cylinder1Retard
           bne   LF0AC     
           incb            
           stab  Cylinder1Retard
           tba             
   LF0AC:  ldab  #0x12         ;  -00010010-
   LF0AE:  decb            
           bne   LF0AE     
           ldab  CPU_Port1_ControlRegister
           orab  #0x80         ;  -10000000-
           stab  CPU_Port1_ControlRegister
           andb  #0x7f         ;  -01111111-
           stab  CPU_Port1_ControlRegister
           ldab  Cylinder1Retard
           cba             
           bcc   LF0C1     
           tba             
   LF0C1:  tab             
           bra   LF0C5     

   LF0C4:  clrb            
   LF0C5:  stab  Cylinder1Retard
           ldab  #0x32         ;  -00110010-
           mul             
           adca  #0x00         ;  -00000000-
   LF0CC:  staa  Temp5     
           ldd   #0x199a   
           jsr   mul16bit  
           ldab  #0x06         ;  -00000110-
           mul             
           addb  Temp5     
   LF0D9:  stab  CPU_SCI_TxDataReg
           bra   LF068     

   LF0DD:  ldaa  Counter_TimerPastHalfwayBetweenDistPulses
           lsra            
           staa  TimerOverflowsBetweenDistPulses
           ldd   CPU_ICR_HB
           subd  LastDistributorFallingEdgeTime_HB
           std   DistributorFallingEdgePulsewidth_HB
           ldd   CPU_ICR_HB
           std   LastDistributorFallingEdgeTime_HB
           clra            
           staa  Counter_TimerPastHalfwayBetweenDistPulses
           ldaa  BitFlags_6f
           bita  #0x04         ;  -00000100-
           bne   LF0FC     
           ldab  CPU_TimerControlStatReg
           orab  #0x02         ;  -00000010-
           stab  CPU_TimerControlStatReg
           rti             

   LF0FC:  ldaa  #0xff         ;  -11111111-
           ldx   TimerOverflowsBetweenDistPulses
           cpx   SKAPRD_SparkImmediateSwitchToRunAboveThisRpm
           bcs   ENGINE_IDLING_FASTERTHAN_813RPM
           ldx   #STRNTR_SparkStartRunTransferPointRpm
           ldaa  CoolantTemp
           jsr   Lookup5ByteTable
           subd  TimerOverflowsBetweenDistPulses
           bcc   ENGINE_IDLING_BETWEEN598_813RPM
           ldaa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           beq   LF11A     
           clra            
           staa  Timer_NormalDwell
   LF11A:  ldx   #RNSTTR_SparkRunStartTransferPointRpm
           ldaa  CoolantTemp
           jsr   Lookup5ByteTable
           subd  TimerOverflowsBetweenDistPulses
           bcc   LF14C     
   LF126:  ldaa  BitFlags_6f
           oraa  #0x02         ;  -00000010-
           bra   LF14A     

ENGINE_IDLING_BETWEEN598_813RPM:
           ldaa  Timer_NormalDwell
           inca            
           beq   LF142     
ENGINE_IDLING_FASTERTHAN_813RPM:
           staa  Timer_NormalDwell
           ldx   #SRTIME_SparkEPPsNeededToBeAboveSR_Hot
           ldab  SRTMTP_SparkTempSwitchPointFor_SRTIME
           cmpb  CoolantTemp
           bcs   SETTOLOOKFOR_RISINGEDGE_AND_CALCULATE_DWELL
           inx             
SETTOLOOKFOR_RISINGEDGE_AND_CALCULATE_DWELL:
           cmpa  0x00, X      ;  -00000000-
           bcs   LF126     
   LF142:  ldaa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           beq   LF14C     
           anda  #0xfd         ;  -11111101-
   LF14A:  staa  BitFlags_6f
   LF14C:  ldaa  #0x1a         ;  -00011010-
           staa  CPU_TimerControlStatReg
           jsr   VerifyOperationOfMapSensor_MM
           ldab  BitFlags_71
           andb  #0x08         ;  -00001000-
           bne   LF15B     
           staa  MapVolts  
   LF15B:  ldaa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           beq   LF172     
           ldab  ADScanIndex
           jsr   ADLookup  
           ldd   #0x1b00   
           addd  CPU_ICR_HB
           std   Temp6     
           ldaa  #0x1a         ;  -00011010-
           jmp   LF213     

   LF172:  ldd   DistributorFallingEdgePulsewidth_HB
           cmpa  #0x2a         ;  -00101010-
           bcc   UseMinAntiDwell
           lsrd            
           lsrd            
           lsrd            
           coma            
           comb            
           addd  DistributorFallingEdgePulsewidth_HB
           lsrd            
           std   DwellTime_HB
           lsrd            
           cmpa  #0x06         ;  -00000110-
           bcs   StoreDwell
           addd  DwellTime_HB
           suba  #0x0c         ;  -00001100-
           bra   StoreDwell

UseMinAntiDwell:
           suba  #0x1c         ;  -00011100-
StoreDwell:
           std   DwellTime_HB
           ldx   #Cylinder2Retard
           ldab  0x00, X      ;  -00000000-
           rolb            
           rolb            
           rolb            
           andb  #0x03         ;  -00000011-
           abx             
           ldaa  0x00, X      ;  -00000000-
           anda  #0x3f         ;  -00111111-
           adda  CalculatedSparkAdvance
           ldab  BitFlags_6d
           bitb  #0x02         ;  -00000010-
           beq   LF1B6     
           ldab  BitFlags_6e
           bmi   LF1B6     
           ldab  VehicleSpeed_HB
           cmpb  MPHREF_SwitchPointForDecelIdleAisControl
           bcc   LF1B6     
           ldaa  MXSPK1_MaxSparkAdvanceUknown1
   LF1B6:  staa  Temp5     
           ldaa  Z85_ADConverterKnockSensor
           staa  KnockVolts
           ldab  BitFlags_72
           andb  #0x7f         ;  -01111111-
           cmpa  KnockLookup
           bcs   LF1C7     
           orab  #0x80         ;  -10000000-
   LF1C7:  stab  BitFlags_72
           ldaa  BitFlags_6f
           oraa  BitFlags_6e
           bmi   LF1DA     
           ldab  BitFlags_70
           andb  #0x40         ;  -01000000-
           orab  Timer_CountdownFromStartRunForAisFeedback
           bne   LF1DA     
           jsr   LA1F4     
   LF1DA:  ldaa  #0x76         ;  -01110110-
           cmpa  Temp5     
           bhi   LF1E2     
           staa  Temp5     
   LF1E2:  ldd   DistributorFallingEdgePulsewidth_HB
           tst   TimerOverflowsBetweenDistPulses
           beq   LF1F7     
           lsrd            
           oraa  #0x80         ;  -10000000-
           jsr   mul16bit  
           asld            
           bcc   LF1FA     
           ldd   #0xffff   
           bra   LF1FA     

   LF1F7:  jsr   mul16bit  
   LF1FA:  addd  LastDistributorFallingEdgeTime_HB
           std   Temp6     
           addd  DwellTime_HB
           subd  DistributorFallingEdgePulsewidth_HB
           tst   TimerOverflowsBetweenDistPulses
           bne   LF211     
           cmpa  CPU_TimerControlStatReg
           std   CPU_OCR_HB
           ldab  CPU_Counter_HB
           incb            
           sba             
           bpl   LF227     
   LF211:  ldaa  #0x1b         ;  -00011011-
   LF213:  staa  Temp8     
           ldd   #CPU_Counter_LB
           addd  CPU_Counter_HB
           std   CPU_OCR_HB
           mul             
           ldd   Temp6     
           cmpa  CPU_TimerControlStatReg
           std   CPU_OCR_HB
           ldaa  Temp8     
           staa  CPU_TimerControlStatReg
   LF227:  ldaa  CPU_Port1_ControlRegister
           oraa  #0x80         ;  -10000000-
           staa  CPU_Port1_ControlRegister
           ldaa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           bne   LF23E     
           ldab  ADScanIndex
           jsr   ADLookup  
           ldx   #BatteryVolts
           jsr   RegulateVoltage
   LF23E:  ldx   TimerOverflowsBetweenDistPulses
           cpx   RNFPRD_FuelStartRunTransferPointRpm
           bcs   LF252     
           cpx   STFPRD_FuelRunStartTransferPointRpm
           bcs   LF29A     
           ldaa  BitFlags_6f
           oraa  #0x80         ;  -10000000-
           staa  BitFlags_6f
           bra   LF29A     

   LF252:  ldaa  BitFlags_6f
           asla            
           bcc   LF29A     
           lsra            
           oraa  #0x20         ;  -00100000-
           staa  BitFlags_6f
           ldd   CPU_Counter_HB
           std   Timer16bitCopyA_HB
           std   Timer16bitCopyB_HB
           ldd   CPU_TimerControl1
           anda  #0xf9         ;  -11111001-
           andb  #0xdf         ;  -11011111-
           std   CPU_TimerControl1
           ldx   KeyOnOrEngineRunningTime
           clra            
           clrb            
           staa  Counter_FallingEdgeEPP_MaxFF
           std   Pulsewidth_PartThrottleEnrichment_HB
           std   KeyOnOrEngineRunningTime
           cpx   #CPU_RAM_ControlReg
           ldab  BitFlags_6d
           bcc   LF27F     
           andb  #0x7f         ;  -01111111-
           stab  BitFlags_6d
   LF27F:  bpl   LF289     
           ldab  #0x20         ;  -00100000-
           ldx   #ErrorBitRegister3
           jsr   ThrowNonCriticalError
   LF289:  ldaa  BaroPressure
           cmpa  BAROHI_BaroReadValidHighLimit
           bcc   LF295     
           cmpa  BAROLO_BaroReadValidLowLimit
           bcc   LF29A     
   LF295:  ldaa  BARDFT_BaroReadDefaultValue
           staa  BaroPressure
   LF29A:  ldaa  MapValue  
           cmpa  AverageMAPValue
           bcs   LF2A6     
           ldx   #AverageMAPValue
           jsr   ProcessMapOrTpsBlockData
   LF2A6:  jsr   LA50C     
           ldx   #AverageTPSVolts
           jsr   ProcessMapOrTpsBlockData
           rti             

   LF2B0:  ldaa  CPU_TimerControlStatReg
           anda  #0xfd         ;  -11111101-
           staa  CPU_TimerControlStatReg
           ldaa  CPU_ICR_HB
           ldaa  Counter_FallingEdgeEPP_MaxFF
           inca            
           beq   LF2BF     
           staa  Counter_FallingEdgeEPP_MaxFF
   LF2BF:  ldx   #Cylinder2Retard
           ldab  0x01, X      ;  -00000001-
           rolb            
           rolb            
           rolb            
           andb  #0x03         ;  -00000011-
           abx             
           ldaa  0x00, X      ;  -00000000-
           tab             
           anda  #0xc0         ;  -11000000-
           andb  #0x3f         ;  -00111111-
           staa  Temp9     
           ldaa  BitFlags_72
           bmi   LF2DA     
           clra            
           bra   LF2F6     

   LF2DA:  ldaa  BaroPressure
           adda  KNKOFS_DeltaAboveBaroFor_RTRDRT_and_KNKCNT_and_KNKCOR_incremented
           cmpa  MapValue  
           ldaa  RTRDRT_KnockRetardRateNoBoost
           bcc   LF2F6     
           ldaa  BitFlags_72
           oraa  #0x10         ;  -00010000-
           staa  BitFlags_72
           ldaa  Counter_Over5psiBoost
           inca            
           beq   LF2F3     
           staa  Counter_Over5psiBoost
   LF2F3:  ldaa  RTRDRT2_KnockRetardRateInBoost
   LF2F6:  aba             
           bcs   LF2FD     
           cmpa  #0x40         ;  -01000000-
           bcs   LF2FF     
   LF2FD:  ldaa  #0x3f         ;  -00111111-
   LF2FF:  ldab  MaxRetardFromMAP
           cba             
           bcs   LF305     
           tba             
   LF305:  oraa  Temp9     
           staa  0x00, X      ;  -00000000-
           jsr   VerifyOperationOfMapSensor_MM
           ldab  BitFlags_71
           andb  #0x08         ;  -00001000-
           bne   LF329     
           adda  MapVolts  
           rora            
           staa  MapValue  
           ldaa  BitFlags_6f
           bmi   LF32C     
           ldaa  BitFlags_6d
           bpl   LF32C     
           jsr   SimulateMapReadingFromTps
           jsr   ConvertMAPVoltsToValue
           staa  MapValue  
           bra   LF32C     

   LF329:  jsr   LA16E     
   LF32C:  inc   Timer_O2ToggleDuration
           ldaa  BitFlags_6f
           bpl   LF33A     
           ldab  ADScanIndex
           jsr   ADLookup  
           bra   LF373     

   LF33A:  ldaa  Z85_ADConverterKnockSensor
           ldaa  Cylinder2Retard
           bita  #0x40         ;  -01000000-
           bne   LF34A     
           ldab  #0x10         ;  -00010000-
   LF345:  decb            
           bne   LF345     
           bra   LF368     

   LF34A:  jsr   CalculateInjectorPulsewidthForEngineRunning
           std   Temp5     
           ldd   LeanoutFactor_HB
           addd  Temp5     
           bmi   LF357     
           std   Temp5     
   LF357:  jsr   IncludePWModifier
           std   Temp5

IncludeSelectiveBankEnrichment:
           ldaa CONFIG_ConfigurationFlags
           bita #cfg_BankEnrich
           beq  SkipSelectiveEnrichment          ; branch if bit is not set

           ldaa Cylinder2Retard    ; load a with memory contents
           anda #0xc0          ; AND a with value -11000000-
           cmpa SBNRBS_BankSelect ; this must be either 0x80 (for bank 1-2) or 0x40 (for bank 3-4)
           beq  SkipSelectiveEnrichment    ; branch if equal (zero)
           ldx  #Temp5         ; load index with value
           ldaa #0x01          ; load a with value -00000001-
           ldab BankEnrichmentFactor    ; load b with memory contents
           jsr  ScaleXbySignedB_ReturnD    ; call subroutine
           stD *Temp5          ; store D to RAM

SkipSelectiveEnrichment:
           std   InjectorPulsewidth_HB
           addd  Pulsewidth_PartThrottleEnrichment_HB
           lsrd            
           lsrd            
           addd  Timer_FuelMonitorOutputTimer_HB
           bcs   LF368     
           std   Timer_FuelMonitorOutputTimer_HB
   LF368:  ldab  ADScanIndex
           jsr   ADLookup  
           ldx   #BatteryVolts
           jsr   RegulateVoltage
   LF373:  bsr   LF3A8     
           ldab  AdaptiveCellUpdateTimer_IncrementedEveryDistRisingEdge
           incb            
           beq   LF37C     
           stab  AdaptiveCellUpdateTimer_IncrementedEveryDistRisingEdge
   LF37C:  ldaa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           beq   LF3A7     
           ldaa  #0x19         ;  -00011001-
           staa  CPU_TimerControlStatReg
           ldd   #CPU_Counter_LB
           addd  CPU_Counter_HB
           std   CPU_OCR_HB
           mul             
           ldab  CPU_Port1_ControlRegister
           bitb  #0x40         ;  -01000000-
           beq   LF39E     
           andb  #0x06         ;  -00000110-
           bne   LF39E     
           ldaa  BitFlags_71
           oraa  #0x80         ;  -10000000-
           staa  BitFlags_71
   LF39E:  ldd   #0x1b00   
           addd  CPU_ICR_HB
           cmpa  CPU_TimerControlStatReg
           std   CPU_OCR_HB
   LF3A7:  rti             

   LF3A8:  ldaa  Cylinder2Retard
           asla            
           bmi   LF3AE     
           rts             

   LF3AE:  ldx   #CPU_OCR3_HB
           ldaa  #0xfb         ;  -11111011-
           bcc   LF3D2     
           ldaa  MapValue  
           tab             
           subb  IncrementalMAP
           bcc   LF3C4     
           cmpb  #0x80         ;  -10000000-
           bcc   LF3CA     
           ldab  #0x80         ;  -10000000-
           bra   LF3CA     

   LF3C4:  cmpb  #0x7f         ;  -01111111-
           bcs   LF3CA     
           ldab  #0x7f         ;  -01111111-
   LF3CA:  stab  Delta_MAP 
           staa  IncrementalMAP
           dex             
           dex             
           ldaa  #0xfd         ;  -11111101-
   LF3D2:  staa  Temp7     
           anda  CPU_TimerControl1
           jsr   LF46D     
           ldaa  BitFlags_70
           bita  #0x28         ;  -00101000-
           bne   LF451     
           ldd   CPU_OCR_HB
           subd  CPU_Counter_HB
           cmpa  #0x02         ;  -00000010-
           bcs   LF3FC     
           ldaa  CPU_Port2_ControlRegister
           coma            
           oraa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           bne   LF3FC     
           ldaa  CPU_TimerControl1
           anda  #0xdf         ;  -11011111-
           ldab  CPU_Port2_ControlRegister
           andb  #0xfd         ;  -11111101-
           staa  CPU_TimerControl1
           stab  CPU_Port2_ControlRegister
   LF3FC:  ldaa  Temp7     
           coma            
           oraa  CPU_TimerControl1
           bsr   LF46D     
           ldaa  BatteryVolts
           cmpa  #0x91         ;  -10010001-
           bcs   LF41C     
           ldaa  CPU_Port1_ControlRegister
           bita  #0x40         ;  -01000000-
           beq   LF41C     
           ldaa  #0x20         ;  -00100000-
           ldab  Temp7     
           cmpb  #0xfd         ;  -11111101-
           beq   LF418     
           asla            
   LF418:  oraa  BitFlags_71
           staa  BitFlags_71
   LF41C:  ldaa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           bne   LF42E     
           ldab  CPU_Port2_ControlRegister
           orab  #0x02         ;  -00000010-
           stab  CPU_Port2_ControlRegister
           ldab  CPU_TimerControl1
           orab  #0x20         ;  -00100000-
           stab  CPU_TimerControl1
   LF42E:  tsta            
           bmi   LF477
           clra            
           ldab  InjectorLatency
           asld            
           asld            
           asld            
           addd  Temp5     
           addd  Pulsewidth_PartThrottleEnrichment_HB
           bcc   LF440     
           ldd   #0xffff   
   LF440:  tsta            
           bne   LF445     
           ldab  #0xff         ;  -11111111-
   LF445:  cpx   #CPU_OCR2_HB
           bne   LF462     
           addd  CPU_OCR2_HB
           std   Timer16bitCopyA_HB
           jmp   ControlWGOutput

   LF451:  clra            
           clrb            
           std   Timer_FuelMonitorOutputTimer_HB
           ldx   #CPU_OCR2_HB
           ldaa  #0xf9         ;  -11111001-
           anda  CPU_TimerControl1
           bsr   LF46D     
           inx             
           inx             
           bra   LF46F     

   LF462:  addd  CPU_OCR3_HB
           std   CPU_OCR3_HB
           ldaa  CPU_TimerControl1
           anda  #0xfb         ;  -11111011-
           staa  CPU_TimerControl1
           rts             

   LF46D:  staa  CPU_TimerControl1
   LF46F:  ldd   CPU_Counter_HB
           addd  #CPU_PortX_ControlStatReg
           std   0x00, X      ;  -00000000-
           rts             

   LF477:  ldd   InjectorPulsewidth_HB
           asld            
           bcc   LF485     
           asld            
           std   Pulsewidth_PartThrottleEnrichment_HB
           ldaa  BitFlags_72
           oraa  #0x03         ;  -00000011-
           bra   LF49F     

   LF485:  asld            
           std   Pulsewidth_PartThrottleEnrichment_HB
           bcs   LF499
           cmpa  #0x02         ;  -00000010-
           bcc   LF493     
           ldd   #0x0200   
           std   Pulsewidth_PartThrottleEnrichment_HB
   LF493:  ldaa  BitFlags_72
           anda  #0xfc         ;  -11111100-
           bra   LF49F     

   LF499:  ldaa  BitFlags_72
           oraa  #0x01         ;  -00000001-
           anda  #0xfd         ;  -11111101-
   LF49F:  staa  BitFlags_72
           ldaa  BitFlags_6f
           bita  #0x02         ;  -00000010-
           beq   LF4C5     
           ldaa  CPU_Port1_ControlRegister
           oraa  #0xf9         ;  -11111001-
           coma            
           beq   LF4C5     
           ldab  #0x05         ;  -00000101-
   LF4B0:  ldaa  CPU_Port1_ControlRegister
           asla            
           bmi   LF4C5     
           decb            
           bne   LF4B0     
           ldaa  #0x20         ;  -00100000-
           ldab  Temp7     
           cmpb  #0xfd         ;  -11111101-
           beq   LF4C1     
           asla            
   LF4C1:  oraa  BitFlags_71
           staa  BitFlags_71
   LF4C5:  ldaa  BitFlags_72
           bita  #0x03         ;  -00000011-
           bne   LF4D1     
           ldaa  Temp7     
           anda  CPU_TimerControl1
           staa  CPU_TimerControl1
   LF4D1:  ldaa  CPU_TimerStatus
           ldd   Pulsewidth_PartThrottleEnrichment_HB
           bmi   LF4E8     
           addd  0x00, X      ;  -00000000-
           std   0x00, X      ;  -00000000-
           subd  CPU_Counter_HB
           bpl   LF4EC     
           ldaa  CPU_TimerStatus
           ldab  Temp7     
           jsr   LEBCE     
           bra   LF4EC     

   LF4E8:  addd  0x00, X      ;  -00000000-
           std   0x00, X      ;  -00000000-
   LF4EC:  ldaa  #0x7b         ;  -01111011-
           staa  CPU_TimerControl2
           rts             

ADTableOffsets83:
           .byte  0x05,0x07,0x04,0x07
           .byte  0x01,0x07,0x02,0x07
           .byte  0x03,0x07,0x07,0x07

ADLookup:
           ldx   #ADTableOffsets83
           abx             
           ldab  0x00, X      ;  -00000000-
           ldx   #Z85_ADConverter1
           abx             
           tab             
           ldaa  0x00, X      ;  -00000000-
           rts             

A2DScan_MM:
           ldaa  Timer_NavigatorFuelPulsewidth
           adda  #0x08         ;  -00001000-
           cmpa  CPU_Counter_HB
           bpl   LF51E     
           sei             
           ldd   Timer_FuelMonitorOutputTimer_HB
           subd  FUELTR_FuelMonitorConversionFactor
           bcs   LF519     
           std   Timer_FuelMonitorOutputTimer_HB
           ldaa  Z83_PortBdata
           eora  #0x40         ;  -01000000-
           staa  Z83_PortBdata
   LF519:  cli             
           ldaa  CPU_Counter_HB
           staa  Timer_NavigatorFuelPulsewidth
   LF51E:  ldaa  #0x0f         ;  -00001111-
           ldab  BitFlags_AIS
           bitb  #0x40         ;  -01000000-
           bne   LF528     
           ldaa  #0x1e         ;  -00011110-
   LF528:  adda  Counter_A2DScan2
           cmpa  CPU_Counter_HB
           bpl   LF531     
           jsr   CheckVoltageforAIS
   LF531:  ldaa  Z83_PortBdata
           bpl   LF555     
           sei             
           ldab  ADScanIndex
           tba             
           incb            
           cmpb  #0x0b         ;  -00001011-
           bls   LF540     
           clrb            
   LF540:  stab  ADScanIndex
           bsr   ADLookup  
           cli             
           ldx   #ADTableOffsets83
           abx             
           ldab  0x00, X      ;  -00000000-
           ldx   #CoolantTemp
           abx
           cmpb  #0x07         ;  -00000111-
           beq   LF556     
           staa  0x00, X      ;  -00000000-
   LF555:  rts             

   LF556:  cmpa  #0x41         ;  -01000001-
           bcs   LF571     
           cmpa  #0x7c         ;  -01111100-
           bcs   LF562     
           cmpa  #0x8d         ;  -10001101-
           bcs   RegulateVoltage
   LF562:  ldab  BitFlags_5D
           andb  #0xdf         ;  -11011111-
           stab  BitFlags_5D
           bra   LF571     

RegulateVoltage:
           ldab  BitFlags_5D
           bitb  #0x20         ;  -00100000-
           beq   LF571     
           clra            
   LF571:  staa  0x00, X      ;  -00000000-
           ldab  BitFlags_6f
           bmi   LF5D0     
           cmpa  #0x41         ;  -01000001-
           bcc   LF581     
           ldab  Counter_MainLoop
           bitb  #0x06         ;  -00000110-
           bne   LF5D0     
   LF581:  ldab  CPU_Port1_ControlRegister
           bitb  #0x10         ;  -00010000-
           beq   LF58B     
           adda  #0x01         ;  -00000001-
           bcs   LF5D0     
   LF58B:  cmpa  TargetBatteryVolts
           bhi   LF5D0     
           ldab  #0x80         ;  -10000000-
           tpa             
           bita  #0x10         ;  -00010000-
           bne   LF5D4     
           ldaa  Timer_VoltageRegSignal
           cmpa  #0xf0         ;  -11110000-
           bcc   LF5D4     
           anda  #0x0f         ;  -00001111-
           cmpa  #0x01         ;  -00000001-
           bne   LF5A8     
           dec   Timer_VoltageRegSignal
           clrb            
           bra   LF5D4     

   LF5A8:  ldaa  CPU_Port1_ControlRegister
           bita  #0x10         ;  -00010000-
           beq   LF5D4     
           ldaa  Z83_PortBdata
           bita  #0x10         ;  -00010000-
           beq   LF5D1     
           ldaa  TargetBatteryVolts
           suba  BatteryVolts
           bcs   LF5D1     
           cmpa  #0x04         ;  -00000100-
           bcs   LF5D1     
           ldaa  Timer_VoltageRegSignal
           bita  #0x0f         ;  -00001111-
           bne   LF5CB     
           adda  #0x10         ;  -00010000-
           anda  #0xf0         ;  -11110000-
           oraa  #0x03         ;  -00000011-
   LF5CB:  deca            
           staa  Timer_VoltageRegSignal
           bra   LF5D4     

   LF5D0:  clrb            
   LF5D1:  clra            
           staa  Timer_VoltageRegSignal
   LF5D4:  tpa             
           sei             
           psha            
           ldaa  CPU_Port1_ControlRegister
           oraa  #0x10         ;  -00010000-
           tstb            
           bmi   LF5E0     
           anda  #0xef         ;  -11101111-
   LF5E0:  staa  CPU_Port1_ControlRegister
           pula            
           tap             
           rts             

SetDelayedFaultCode:
           staa  Temp4     
           jsr   ThrowCriticalError
           bcs   LF5F7     
           ldaa  TimerOverflowsBetweenDistPulses
           cmpa  #0x02         ;  -00000010-
           bcs   LF5FD     
           jsr   ThrowCriticalError
           bcc   LF5FD     
   LF5F7:  ldaa  BitFlags_6e
           oraa  #0x20         ;  -00100000-
           staa  BitFlags_6e
   LF5FD:  rts             

ConfirmO2GoodAndAdjustKnockRetard_MM:
           ldab  BitFlags_6e
           bitb  #0x20         ;  -00100000-
           bne   LF618     
           ldab  BitFlags_71
           bitb  #0x20         ;  -00100000-
           beq   LF60E
           ldaa  #0x14         ;  -00010100-
           bsr   SetDelayedFaultCode
   LF60E:  ldab  BitFlags_71
           bitb  #0x40         ;  -01000000-
           beq   LF618     
           ldaa  #0x13         ;  -00010011-
           bsr   SetDelayedFaultCode
   LF618:  ldab  BitFlags_71
           bitb  #0x80         ;  -10000000-
           beq   LF623     
           ldaa  #0x09         ;  -00001001-
           jsr   LAD18     
   LF623:  sei             
           ldaa  BitFlags_71
           anda  #0x1f         ;  -00011111-
           staa  BitFlags_71
           cli             
           ldaa  BitFlags_6f
           bita  #0x04         ;  -00000100-
           bne   LF644     
           ldaa  BitFlags_72
           bita  #0x08         ;  -00001000-
           beq   LF644     
           ldaa  #0x01         ;  -00000001-
           jsr   LAD18     
           ldaa  #0xf7         ;  -11110111-
           sei             
           anda  BitFlags_72
           staa  BitFlags_72
           cli             
   LF644:  ldaa  Counter_MainLoop
           bita  INCSRT_KnockRetardIncreaseRate
           bne   LF663     
           ldx   #Cylinder2Retard
   LF64E:  sei             
           ldaa  0x00, X      ;  -00000000-
           tab             
           anda  #0xc0         ;  -11000000-
           andb  #0x3f         ;  -00111111-
           beq   LF659     
           decb            
   LF659:  aba             
           staa  0x00, X      ;  -00000000-
           cli             
           inx             
           cpx   #Cylinder4Retard
           bls   LF64E     
   LF663:  rts             

ControlAsdRelay_MM:
           ldaa  Z83_CPU_Port1_copy
           ldab  BitFlags_6e
           bitb  #0x20         ;  -00100000-
           bne   LF6A3
           ldx   #0x002d   
           ldaa  CoolantTemp
           cmpa  #0x8f         ;  -10001111-
           bcc   LF678     
           ldx   #SlowCounter
   LF678:  ldab  #0x10         ;  -00010000-
           ldaa  BitFlags_6e
           bita  #0x02         ;  -00000010-
           bne   LF68F     
           ldaa  BatteryVolts
           cmpa  #0xb2         ;  -10110010-
           bcc   LF697     
           cpx   #SlowCounter
           bne   LF697     
           ldab  #0x2e         ;  -00101110-
           bra   LF697     

   LF68F:  ldaa  BatteryVolts
           cmpa  #0xb2         ;  -10110010-
           bcs   LF697     
           ldab  #0x0a         ;  -00001010-
   LF697:  ldaa  Z83_CPU_Port1_copy
           anda  #0xfd         ;  -11111101-
           cmpb  Counter_TimerPastHalfwayBetweenDistPulses
           bhi   LF6A5     
           cpx   KeyOnOrEngineRunningTime
           bhi   LF6A5     
   LF6A3:  oraa  #0x02         ;  -00000010-
   LF6A5:  staa  Z83_CPU_Port1_copy
           ldaa  BitFlags_6e
           ldab  BitFlags_6f
           bmi   LF6B7     
           ldab  KeyOnOrEngineRunningTime
           cmpb  #0x04         ;  -00000100-
           bcs   LF6B7     
           oraa  #0x02         ;  -00000010-
           staa  BitFlags_6e
   LF6B7:  rts             

VerifyOperationOfThermostat_MM:
           ldaa  BitFlags_6f
           bmi   LF6E5     
           ldaa  Timer_ThermostatDiagnostics
           beq   LF6E5     
           ldab  Counter_MainLoop
           andb  #0xfd         ;  -11111101-
           bne   LF6E5     
           ldab  CoolantTemp
           cmpb  TDAGTP_TstatDiagnosticsTemperatureGoalWithin_HOTIME
           bcc   LF6E2     
           ldab  KeyOnOrEngineRunningTime
           incb            
           bne   LF6E5     
           inca
           beq   LF6DA     
           cmpa  HOTIME_TstatDiagnosticsTimeToAchieveTemperatureGoal
           bcs   LF6E3     
   LF6DA:  ldx   #ErrorBitRegister3
           ldab  #0x02         ;  -00000010-
           jsr   ThrowNonCriticalError
   LF6E2:  clra            
   LF6E3:  staa  Timer_ThermostatDiagnostics
   LF6E5:  rts             

CalculateSparkAdvance_MM:
           clrb            
           clra            
           std   Temp0     
           ldaa  MapValue  
           ldab  CoolantTemp
           cmpb  TMPSWP_EngTempSwitchPointForSparkAdvance
           bcc   LF728     
           ldx   #CLDMAP_AdvanceFromMAPCold
           jsr   Lookup4ByteTable
           ldab  BitFlags_6e
           bmi   LF705     
           cmpa  CLDLMT_LimitForColdMapAtClosedThrottle
           bcs   LF705     
           ldaa  CLDLMT_LimitForColdMapAtClosedThrottle
   LF705:  staa  Temp0     
           ldab  BitFlags_6e
           bmi   LF725     
   LF70B:  ldaa  EngineRpm_HB
           cmpa  PNRPM_EngineSpeedBelowWhich_PNIDLE_Enabled
           bhi   LF725     
           ldaa  Z83_PortCdata
           bita  #0x08         ;  -00001000-
           bne   LF725     
           ldaa  CoolantTemp
           ldx   #PNIDLE_AdvanceRemovedIdleParkNeutral
           jsr   Lookup4ByteTable
           adda  Temp0     
           staa  Temp0     
   LF725:  jmp   LF7B0     

   LF728:  ldab  BitFlags_6e
           bpl   LF70B     
           ldx   #WOTMAP_AdvanceFromMAPWarmFull
           jsr   Lookup4ByteTable

           ; subtract anti-lag timing from the WOT table only
           suba AntiLagRetard

           staa  Temp0
           ldab  BitFlags_6e
           lsrb            
           bcs   LF77D     
           ldaa  Timer_OpenLoopFraction
           cmpa  LMTOLF2_LimitTimerOpenLoopFraction2
           bcs   LF747     
           ldab  EngineRpm_HB
           cmpb  RPMLMT_RPMLimitForManyThings
           bcc   LF77D     
   LF747:  ldab  MapValue  
           cmpb  OBCONST_OverboostConstant1
           bcc   LF758     
           aba             
           bcc   LF753     
           ldaa  #0xff         ;  -11111111-
   LF753:  suba  OBCONST_OverboostConstant1
           bls   LF760     
   LF758:  ldab  ARADVR_AdaptiveRetardAdvanceRatioFromMAP
           mul             
           adca  #0x00         ;  -00000000-
           staa  Temp1     
   LF760:  ldaa  MapValue  
           ldx   #HOTMAP_AdvanceFromMAPWarmPart
           jsr   Lookup4ByteTable
           ldab  FACALC_AdaptiveRetardEnable
           bmi   LF775     
           adda  Temp1     
           cmpa  Temp0     
           bge   LF77D     
           bra   LF77B     

   LF775:  suba  Temp1     
           cmpa  Temp0     
           ble   LF77D     
   LF77B:  staa  Temp0     
   LF77D:  ldx   #ABCBAS_AdvanceBaroCompensationBaseFromRPM
           ldd   EngineRpm_HB
           asld            
           jsr   Lookup4ByteTable
           staa  Temp1     
           ldx   #ABCFBR_AdvanceBaroCompensationFactorFromBaro
           ldaa  BaroPressure
           jsr   Lookup4ByteTable
           staa  Temp4     
           ldx   #ABCFRP_AdvanceBaroCompensationFactorFromRPM
           ldd   EngineRpm_HB
           asld            
           jsr   Lookup4ByteTable
           ldab  Temp4     
           mul             
           tab             
           ldaa  Temp1     
           sba             
           cmpa  MINADV_MinimumAdvance
           bpl   LF7AA     
           ldaa  MINADV_MinimumAdvance
   LF7AA:  cmpa  Temp0     
           bgt   LF7B0     
           staa  Temp0     
   LF7B0:  ldx   #GOVNER_AdvanceFromRPM2
           ldd   EngineRpm_HB
           asld
           jsr   Lookup4ByteTable
           addb  Temp0     
           bpl   CheckForTPSRetard
           clrb            
CheckForTPSRetard:
           stab  Temp0     
           ldaa  MapValue  
           cmpa  RTMAPE_RetardFromTPSEnableAboveThisMAP
           bls   LF7E8     
           ldaa  EngineRpm_HB
           cmpa  RTRPME_RetardFromTPSEnableAboveThisRPM
           bls   LF7E8     
           ldab  AverageTPSVolts
           cmpb  RTTPSE_RetardFromTPSEnableAboveThisTPS
           bls   LF7E8     
           ldaa  TpsVolts  
           sba             
           bcs   LF7E8     
           ldx   #RETTPS_RetardFromTPS
           jsr   Lookup4ByteTable
           ldaa  Temp0     
           sba             
           bpl   LF7E6     
           clra            
   LF7E6:  staa  Temp0     
   LF7E8:  ldx   #SPKLMT_AdvanceFromRpmMAX
           ldd   EngineRpm_HB
           asld            
           jsr   Lookup4ByteTable
           cmpb  Temp0     
           bcs   LF7F7     
           ldab  Temp0     
   LF7F7:  negb            
           addb  #0xa6         ;  -10100110-
           ldaa  #0x5b         ;  -01011011-
           mul             
           asld            
           tstb            
           bpl   LF802     
           inca            
   LF802:  staa  CalculatedSparkAdvance
           rts             

ThrottleCheckPart2_MM:
           ldab  BitFlags_6e
           ldaa  Z83_PortCdata
           bita  #0x40         ;  -01000000-
           beq   LF841     
           ldaa  MTHRCL_NumberOfBitsAbove_MINTHR_ToDetermineOnThrottleTransition
           tstb            
           bpl   LF817     
           ldaa  MTHROP_NumberOfBitsAbove_MINTHR_ToDetermineOffThrottleTransition
   LF817:  adda  MINTHR_LowestSessionTPS
           cmpa  TpsVolts
           bcc   LF841     
           tstb            
           bmi   LF83D     
           bitb  #0x40         ;  -01000000-
           bne   LF830     
           ldaa  MINTHR_LowestSessionTPS
           adda  #0x01         ;  -00000001-
           cmpa  TpsVolts  
           bcc   LF830     
           staa  MINTHR_LowestSessionTPS
           orab  #0x40         ;  -01000000-
   LF830:  clr   Timer_Leanout
           ldaa  MapValue  
           suba  TestedAgainstMAPPressureDuringTransientCalc
           bcc   LF83B     
           clra            
   LF83B:  staa  AverageMAPValue
   LF83D:  orab  #0x80         ;  -10000000-
           bra   LF86A     

   LF841:  tstb            
           bpl   LF868     
           ldaa  BitFlags_5D
           bita  #0x04         ;  -00000100-
           bne   LF852     
           ldaa  #0x20         ;  -00100000-
           sei             
           oraa  BitFlags_AIS
           staa  BitFlags_AIS
           cli             
   LF852:  ldx   #DLYTIM_AisDelayAfterThrottleClosesWhenMoving
           ldaa  VehicleSpeed_HB
           cmpa  MPHREF_SwitchPointForDecelIdleAisControl
           bcc   LF864     
           ldaa  Z83_PortCdata
           bita  #0x08         ;  -00001000-
           bne   LF864     
           inx             
   LF864:  ldaa  0x00, X      ;  -00000000-
           staa  Timer_CountdownFromStartRunForAisFeedback
   LF868:  andb  #0x7f         ;  -01111111-
   LF86A:  bitb  #0x08         ;  -00001000-
           bne   LF894     
           ldaa  Z83_PortCdata
           anda  #0x10         ;  -00010000-
           beq   LF894     
           ldaa  EngineRpm_HB
           cmpa  RPTHCK_RPMLimitforThrottleBelowHalfChecking
           bcs   LF894     
           ldaa  MapValue  
           cmpa  MPTHCK_MAPLimitforThrottleBelowHalfChecking
           bcc   LF894     
           ldaa  MINTHR_LowestSessionTPS
           adda  MININH_Amount_MINTHR_IsIncreasedAtKeyOnOnlyHalfThrottle
           cmpa  MTHRMX_ValueOf_MINTHR_WhenBatteryDisconnected
           bcs   LF890     
           ldaa  MTHRMX_ValueOf_MINTHR_WhenBatteryDisconnected
   LF890:  staa  MINTHR_LowestSessionTPS
           orab  #0x08         ;  -00001000-
   LF894:  ldaa  MINTHR_LowestSessionTPS
           adda  #0x30         ;  -00110000-
           cmpa  TpsVolts  
           bcc   LF89E     
           andb  #0xf7         ;  -11110111-
   LF89E:  stab  BitFlags_6e
           rts             

CalcTargetBoost_MM:
           ldx   #WSGRPM_AllowedBoost_FromRpm
           ldd   EngineRpm_HB
           asld            
           jsr   Lookup4ByteTable
           staa  Temp4     
           ldx   #WSGTIM_AllowedBoost_FromTime
           ldaa  Timer_BoostTimer
           jsr   LookupAndKeepSmallerBoostGoal
           ldx   #WSGCLT_AllowedBoost_FromTemp
           ldaa  CoolantTemp
           jsr   LookupAndKeepSmallerBoostGoal
           ldx   #WSGCHG_AllowedBoost_FromChargeTemp
           ldaa  ChargeTempVolts
           jsr   LookupAndKeepSmallerBoostGoal

           ; added code for switchable boost
           ; this works differently from the later code. More like the S60
           ; with a single constant for the "lo" boost setting.
           ldaa CONFIG_ConfigurationFlags
           bita #cfg_SwBoost      ; check the bit for the Switch Boost mod
           beq  NoLoBoost        ; branch if the bit is not set, ie not enabled
           ; now, look at the hi-boost switch and see if it's enabled ...

           ;Z83_PortCdata
           ;  Bit Function            LM Pin
           ;   7   dist sync           B17
           ;   6   cruise enable       B15
           ;   5                       B14
           ;   4   brake               B13
           ;   3   park/neutral        B12
           ;   2   ac clutch in        B11
           ;   1   cruise resume       B10
           ;   0   cruise set          B9

           ldab Z83_PortCdata ; load the switch state into B
           bita #cfg_BstSwPol
	   beq  Polarity_Lo

Polarity_Hi:
           andb BSTSWS_HighBoostSwitchSelect
           beq  NoLoBoost
           bra  LoadLoBoost

Polarity_Lo:
           andb BSTSWS_HighBoostSwitchSelect
           bne  NoLoBoost

LoadLoBoost:
           ldaa SWBSLO_SwitchableBoostLoSetpoint ; load the lo-boost limit constant
           jsr  StoreLowestInTemp4    ; call:

NoLoBoost:
           ; this is the stock code continued here...
           ldaa  BitFlags_6e
           lsra            
           bcs   LF8CF     
           ldaa  WSGPRT_AllowedBoostPartThrottle_FromThrottle
           jsr   StoreLowestInTemp4     
   LF8CF:  ldab  Z83_PortCdata
           andb  #0x08         ;  -00001000-
           beq   LF8DE     
           ldx   #MXSBST_AllowedBoostForAutomatics_FromSpeed
           ldaa  VehicleSpeed_HB
           jsr   LookupAndKeepSmallerBoostGoal
   LF8DE:  ldx   #WSGKNK_BoostTimeSinceLastKnock
           ldaa  Timer_Over5PSIBoost
           jsr   Lookup4ByteTable
           ldaa  Temp4     
           sba             
           bcc   LF8EC     
           clra            
   LF8EC:  adda  BaroPressure
           bcc   LF8F2     
           ldaa  #0xff         ;  -11111111-
   LF8F2:  staa  BoostTarget
           rts             

LookupAndKeepSmallerBoostGoal:
           jsr   Lookup4ByteTable
StoreLowestInTemp4:
           cmpa  Temp4
           bcc   LF8FE     
           staa  Temp4     
   LF8FE:  rts             

CalcWGDutyCycle_MM:
           ldab  Counter_MainLoop
           incb            
           ldaa  BitFlags_6f
           bmi   LF91B     
           tstb            
           bne   LF910     
           ldaa  Timer_Over5PSIBoost
           inca            
           beq   LF910     
           staa  Timer_Over5PSIBoost
   LF910:  ldaa  MapValue  
           suba  BaroPressure
           bcs   LF91B     
           cmpa  MAPOFS_BoostMapOffsetForDCWOT
           bcc   LF92E     
   LF91B:  clra            
           staa  CurrentWastegateDutyCycle
           staa  WastegateDutyCycleIncreaseFromKnock
           staa  Counter_Over5psiBoost
           bitb  #0x1f         ;  -00011111-
           bne   LF92D     
           ldaa  Timer_BoostTimer
           beq   LF92D     
           deca            
           staa  Timer_BoostTimer
   LF92D:  rts             

   LF92E:  cmpa  KNOKMP_BoostKNKCNTinc
           bcc   LF936     
           clra            
           staa  Counter_Over5psiBoost
   LF936:  ldaa  Counter_Over5psiBoost
           cmpa  KNKMAX_BoostMaxKNKBeforeReset
           bcs   LF940     
           clra            
           staa  Timer_Over5PSIBoost
   LF940:  tstb            
           bne   LF946     
           clra            
           staa  Counter_Over5psiBoost
   LF946:  bitb  #0x1f         ;  -00011111-
           bne   LF958     
           ldab  EngineRpm_HB
           cmpb  RPMBST_MinimumRpmToTrackBoostCreep
           bcs   LF958     
           ldaa  Timer_BoostTimer
           inca            
           beq   LF958     
           staa  Timer_BoostTimer
   LF958:  ldaa  Delta_MAP 
           staa  Temp1     
           bpl   LF95F     
           nega            
   LF95F:  staa  Temp0     
           tst   Temp1     
           bmi   ControlWastegate
           ldaa  EngineRpm_HB
           ldx   #RATLIM_BoostOverboostPrevention
           jsr   Lookup4ByteTable
           ldaa  Temp0     
           cba             
           bcs   ControlWastegate
           ldab  PRTMAX_MaxDCForPartThrottleInc
           stab  CurrentWastegateDutyCycle
           rts             

ControlWastegate:
           clrb            
           suba  MPDEL_HysteresisForBoostIncreasingCondition
           bls   LF9A6     
           staa  Temp4     
           ldaa  BoostTarget
           suba  MapValue  
           adda  #0x80         ;  -10000000-
           ldx   #RESFAC_BoostMapCorrectionResponseFactor
           jsr   Lookup4ByteTable
           ldaa  Temp4     
           mul             
           tsta            
           beq   LF995     
           ldab  #0xff         ;  -11111111-
   LF995:  tst   Temp1     
           bmi   LF99F     
           ldaa  UPRLIM_UpperLimitOnMPCORR
           bra   LF9A2     

   LF99F:  ldaa  LWRLIM_LowerLimitOnMPCORR
   LF9A2:  cba             
           bcc   LF9A6     
           tab             
   LF9A6:  ;stab  MapCorrectionForWasteGate
           ldaa  BoostTarget
           tst   Temp1     
           bpl   LF9B6     
           aba             
           bcc   LF9BA     
           ldaa  #0xff         ;  -11111111-
           bra   LF9BA     

   LF9B6:  sba             
           bcc   LF9BA     
           clra            
   LF9BA:  suba  BaroPressure
           bcc   LF9BF     
           clra            
   LF9BF:  ldx   #DCWOT_FullThrottleWastegateDutyCycle_C8is100Percent_FromMap
           jsr   Lookup4ByteTable
           staa  Temp4     
           sei             
           ldaa  BitFlags_72
           bita  #0x10         ;  -00010000-
           beq   LF9EB     
           anda  #0xef         ;  -11101111-
           staa  BitFlags_72
           cli             
           ldab  WastegateDutyCycleIncreaseFromKnock
           addb  KDCINC_WastegateDutyCycleIncreaseStepWhenKnocking
           bcc   LF9DC     
           ldab  #0xff         ;  -11111111-
   LF9DC:  ldaa  KDCMAX_WastegateDutyCycleIncreaseMaxWhenKnocking
           cba             
           bcs   LF9E8     
           ldaa  KDCMIN_WastegateDutyCycleIncreaseMinWhenKnocking
           cba             
           bcs   LFA0E     
   LF9E8:  tab             
           bra   LFA0E     

   LF9EB:  cli             
           ldx   #ADScanIndex
   LF9EF:  inx             
           cpx   #MaxRetardFromMAP
           beq   LFA0D     
           ldaa  0x00, X      ;  -00000000-
           anda  #0x3f         ;  -00111111-
           cmpa  BSOLCO_BoostSolenoidCutout
           bcs   LF9EF     
           ldab  Counter_MainLoop
           lsrb            
           bitb  DECTIM_TimeScaleFor_DCDECK
           bne   LFA10     
           ldab  WastegateDutyCycleIncreaseFromKnock
           subb  DCDECK_WastegateDutyCycleDecrementWhenSparkStillDerated
           bcc   LFA0E     
   LFA0D:  clrb            
   LFA0E:  stab  WastegateDutyCycleIncreaseFromKnock
   LFA10:  ldaa  BoostTarget
           ldab  BaroPressure
           addb  MAPPT_WastegateDutyCycleMapSwitchPoint
           bcc   LFA1B     
           ldab  #0xff         ;  -11111111-
   LFA1B:  ldx   #DCCOR1_AdaptiveWastegateCellBelowMAPPT
           cba             
           bcc   LFA22     
           inx             
   LFA22:  ldab  0x00, X      ;  -00000000-
           suba  MapValue  
           bhi   LFA59     
           nega            
           staa  Temp1     
           ldaa  BitFlags_71
           bita  #0x10         ;  -00010000-
           bne   LFA3B     
           ldaa  #0x10         ;  -00010000-
           sei             
           oraa  BitFlags_71
           staa  BitFlags_71
           cli             
           bra   LFA69     

   LFA3B:  ldaa  MPDEL1_IncCounterWhenDeltaMapBelowThis
           cmpa  Temp0     
           bcs   WGDC_ClearBoostErrTimer
           ldaa  Timer_BoostErrTimer
           inca            
           cmpa  INCPT_AdaptiveIncAfterThisTime
           bcs   WGDC_StoreBoostErrTimer
           ldaa  Temp1     
           cmpa  MPROOF_StopAdaptiveWGWhenMapIsThisCloseToBoostTarget
           bcs   WGDC_ClearBoostErrTimer
           cmpb  INCLM2_UpperLimitOnWastegateDutyCycleCorrection2
           bcc   WGDC_ClearBoostErrTimer
           incb            
           bra   WGDC_UpdateAdaptiveWGControlMemory

   LFA59:  staa  Temp1     
           ldaa  BitFlags_71
           bita  #0x10         ;  -00010000-
           beq   LFA6B     
           ldaa  #0xef         ;  -11101111-
           sei             
           anda  BitFlags_71
           staa  BitFlags_71
           cli             
   LFA69:  bra   WGDC_ClearBoostErrTimer

   LFA6B:  ldaa  WastegateDutyCycleIncreaseFromKnock
           bne   WGDC_ClearBoostErrTimer
           ldaa  BitFlags_6e
           lsra            
           bcc   WGDC_ClearBoostErrTimer
           ldaa  EngineRpm_HB
           cmpa  DCRPML_NoWastegateDutyCycleCorrectionBelowThisRpm
           bcs   WGDC_ClearBoostErrTimer
           ldaa  MPDEL2_IncCounterWhenDeltaMapBelowThis2
           cmpa  Temp0     
           bcs   WGDC_ClearBoostErrTimer
           ldaa  Timer_BoostErrTimer
           inca            
           cmpa  INCPT2_AdaptiveIncAfterThisTime2
           bcs   WGDC_StoreBoostErrTimer
           ldaa  Temp1     
           cmpa  MPDEL3_IncCounterWhenDeltaMapBelowThis3
           bcs   WGDC_ClearBoostErrTimer
           cmpb  INCLIM_UpperLimitOnWastegateDutyCycleCorrection
           bls   WGDC_ClearBoostErrTimer
           decb            
WGDC_UpdateAdaptiveWGControlMemory:
           stab  0x00, X      ;  -00000000-
WGDC_ClearBoostErrTimer:
           clra            
WGDC_StoreBoostErrTimer:
           staa  Timer_BoostErrTimer
           ldaa  Temp4     
           subb  #0x80         ;  -10000000-
           bmi   LFAA9     
           aba             
           bcc   LFAAE     
           ldaa  #0xff         ;  -11111111-
           bra   LFAAE     

   LFAA9:  negb            
           sba             
           bcc   LFAAE     
           clra            
   LFAAE:  adda  WastegateDutyCycleIncreaseFromKnock
           bcc   LFAB4     
           ldaa  #0xff         ;  -11111111-
   LFAB4:  staa  CurrentWastegateDutyCycle
           rts             

AdaptiveMemory_DetermineWhichCellApplies_MM:
           clra            
           staa  Temp0     
           ldab  PointerIntoAdaptiveMemory
           ldaa  BitFlags_6e
           bmi   LFAD4     
           ldaa  TargetIdleSpeed_HB
           adda  HYTRPM_HysteresisFor_IDLOFS
           cmpb  #0x0c         ;  -00001100-
           bne   LFACC     
           adda  IDLOFS_DeltaForIdleRPMForClosedThrottleCell
   LFACC:  cmpa  EngineRpm_HB
           bcs   LFAD4     
           ldab  #0x0c         ;  -00001100-
           bra   LFB00     

   LFAD4:  ldx   #MP1_AutoCalMapCellBoundary1
   LFAD7:  ldaa  0x00, X      ;  -00000000-
           cmpb  Temp0     
           bcc   LFAE0     
           adda  DLTMAP_MapHysteresisAtMapCellBoundaries
   LFAE0:  cmpa  MapValue  
           bcc   LFAF0     
           inx             
           inc   Temp0     
           inc   Temp0     
           cpx   #DLTMAP_MapHysteresisAtMapCellBoundaries
           bne   LFAD7     
   LFAF0:  ldaa  R1_RPMCellBoundaryInRPMover32
           lsrb            
           bcs   LFAF9     
           adda  DLTRPM_DeltaRPMAtRPMBoundariesInRPMOver32
   LFAF9:  ldab  Temp0     
           cmpa  EngineRpm_HB
           bcc   LFB00     
           incb            
   LFB00:  cmpb  PointerIntoAdaptiveMemory
           beq   LFB09     
           clra            
           staa  AdaptiveCellUpdateTimer_IncrementedEveryDistRisingEdge
           stab  PointerIntoAdaptiveMemory
   LFB09:  rts             

HandleO2Processing_MM:
           ldaa  BitFlags_6e
           ldab  WOTDLT_DeltaThrottleFrom_MINTHR_ToDetermineFullThrottle
           addb  MINTHR_LowestSessionTPS
           bcs   LFB17     
           cmpb  #0xd0         ;  -11010000-
           bcs   LFB19     
   LFB17:  ldab  #0xd0         ;  -11010000-
   LFB19:  lsra            
           bcc   LFB1F     
           subb  TPDLTF_TPSDeltaOverWOTDLTToDetermineWOT
   LFB1F:  cmpb  TpsVolts  
           bcc   LFB26     
           rola            
           bra   LFB6D     

   LFB26:  asla            
           staa  BitFlags_6e
           ldab  MapValue  
           cmpb  MAPDEC_NoCellUpdateAndO2CNTRHeldBelowThisMap
           bcc   LFB6F     
           ldab  Timer_OpenLoopFraction
           cmpb  LMTOLF2_LimitTimerOpenLoopFraction2
           bcc   LFB6F     
           bita  #0x10         ;  -00010000-
           bne   LFB73     
           ldaa  CoolantTemp
           cmpa  CLTEMP_TempToStartCLTIMETimer
           bcs   LFB6F     
           ldaa  Timer_CLTIME_ClosedLoopTimer
           cmpa  O2TIME_DelayTimeToClosedLoop
           bcc   CheckIfO2SensorDataIsValid
           ldab  BitFlags_6f
           bmi   LFB6F     
           ldab  Counter_MainLoop
           bitb  #0x1f         ;  -00011111-
           bne   LFB6F     
           inca            
           staa  Timer_CLTIME_ClosedLoopTimer
           bra   LFB6F     

CheckIfO2SensorDataIsValid:
           ldaa  O2SensorVolts
           cmpa  O2TLMH_HighLimitForDelayedSwitchToClosedLoop
           bcc   LFB64     
           cmpa  O2TLML_LowLimitForDelayedSwitchToClosedLoop
           bcc   LFB6F     
   LFB64:  clra            
           staa  Counter_AdaptiveMem_Erase
           staa  Timer_CLTIME_ClosedLoopTimer
           ldaa  BitFlags_6e
           oraa  #0x10         ;  -00010000-
   LFB6D:  staa  BitFlags_6e
   LFB6F:  clra            
           staa  Counter_PrimaryAndSecondaryRamp
           rts             

   LFB73:  clrb            
           ldaa  O2SensorVolts
           cmpa  O2MIDH_HighLimitForInMiddleDetermination
           bcc   LFB8A     
           cmpa  O2MIDL_LowLimitForInMiddleDetermination
           bcs   LFB8A     
           ldab  Timer_CLTIME_ClosedLoopTimer
           cmpb  #0x7f         ;  -01111111-
           bls   LFB89     
           jmp   Save_CLTIME_ToOtherTimers_O2InMiddle

   LFB89:  incb            
   LFB8A:  stab  Timer_CLTIME_ClosedLoopTimer
           clrb            
           cmpa  O2HSWP_HighLimitForO2RampSwitching
           bcc   O2Signal_AboveToggle
           cmpa  O2LSWP_LowLimitForO2RampSwitching
           bcs   O2Signal_BelowToggle
           rts             

O2Signal_AboveToggle:
           decb            
O2Signal_BelowToggle:
           ldaa  BitFlags_70
           bita  #0x10         ;  -00010000-
           bne   EraseAdaptiveMemory_possiblySetErrorBit
           clra            
           eorb  BitFlags_6e
           andb  #0x04         ;  -00000100-
           beq   LFBBB     
           eorb  BitFlags_6e
           stab  BitFlags_6e
           clrb            
           ldaa  Timer_OutOfClosedLoopMode
           stab  Timer_OutOfClosedLoopMode
           stab  Timer_O2ToggleDuration
           ldab  #0x3f         ;  -00111111-
           sei             
           andb  Cylinder3Retard
           stab  Cylinder3Retard
           cli             
           bra   LFBBF     

   LFBBB:  ldab  Timer_OutOfClosedLoopMode
           beq   EraseAdaptiveMemory_possiblySetErrorBit
   LFBBF:  staa  Temp0     
           ldx   #PRIRMP_PrimaryRamp
           jsr   DetermineRampCellFromRPMandMAP
           ldab  Timer_OutOfClosedLoopMode
           addb  0x00, X      ;  -00000000-
           sba             
           bcc   LFBD8     
           adda  0x00, X      ;  -00000000-
           bpl   LFBD3     
           clra            
   LFBD3:  clrb            
           stab  Timer_OutOfClosedLoopMode
           bra   LFBDF     

   LFBD8:  ldaa  0x00, X      ;  -00000000-
           tab             
           addb  Timer_OutOfClosedLoopMode
           stab  Timer_OutOfClosedLoopMode
   LFBDF:  ldab  Temp0     
           beq   LFBE7     
           cba             
           bcs   LFBE7     
           tba             
   LFBE7:  ldab  BitFlags_6e
           bitb  #0x04         ;  -00000100-
           beq   LFBEE     
           nega            
   LFBEE:  bsr   IncrementO2SensorFeedbackCount
           clra            
           staa  Counter_AdaptiveMem_Erase
   LFBF3:  ldaa  Counter_MainLoop
           bne   LFBFA     
           inc   Counter_AdaptiveMem_Erase
   LFBFA:  rts             

EraseAdaptiveMemory_possiblySetErrorBit:
           ldaa  Counter_AdaptiveMem_Erase
           cmpa  LTHTIM_IfNoO2SwitchForThisTimeThrowFault51or52
           bcs   LFBF3     
           ldaa  Cylinder3Retard
           anda  #0xc0         ;  -11000000-
           cmpa  #0xc0         ;  -11000000-
           bne   LFC13     
           ldaa  #0x20         ;  -00100000-
           sei             
           oraa  BitFlags_6d
           staa  BitFlags_6d
           bra   LFC1A     

   LFC13:  ldaa  #0x40         ;  -01000000-
           sei             
           adda  Cylinder3Retard
           staa  Cylinder3Retard
   LFC1A:  cli             
           ldx   #ErrorBitRegister0
           ldab  #0x08         ;  -00001000-
           ldaa  BitFlags_6e
           bita  #0x04         ;  -00000100-
           beq   LFC27     
           lsrb            
   LFC27:  jsr   ThrowNonCriticalError
           ldx   #AutoCalCell0
   LFC2D:  staa  0x00, X      ;  -00000000-
           inx             
           cpx   #ErrorBitRegister0
           bne   LFC2D     
Save_CLTIME_ToOtherTimers_O2InMiddle:
           clra            
           staa  Counter_AdaptiveMem_Erase
           staa  AdaptiveCellUpdateTimer_IncrementedEveryDistRisingEdge
           staa  Timer_CLTIME_ClosedLoopTimer
           ldab  BitFlags_6e
           andb  #0xef         ;  -11101111-
           stab  BitFlags_6e
           rts             

ModifyO2FeedbackCountVarToMaintainStoich_MM:
           ldaa  BitFlags_70
           bita  #0x10         ;  -00010000-
           beq   WorkWithSecondaryRamp
   LFC49:  clra            
           staa  Timer_O2ToggleDuration
           rts             

WorkWithSecondaryRamp:
           ldab  BitFlags_6e
           bitb  #0x10         ;  -00010000-
           beq   LFC49     
           ldx   #SECRMP_SecondaryRamp
           bsr   DetermineRampCellFromRPMandMAP
           sei             
           ldaa  Timer_O2ToggleDuration
           sba             
           bcs   DontUpdateO2FeedbackCount
           staa  Timer_O2ToggleDuration
           cli             
           ldaa  0x00, X      ;  -00000000-
IncrementO2SensorFeedbackCount:
           ldab  O2LIMH_O2RangeLimitHigh
           adda  Counter_PrimaryAndSecondaryRamp
           bvc   DIDNT_2SCOMPLEMENT_OVERFLOW_UNDERFLOW1
           ldaa  Counter_PrimaryAndSecondaryRamp
           bpl   SET_TO_MAX_OR_MIN_VALUE
           ldab  O2LIML_O2RangeLimitLow
           tba             
DIDNT_2SCOMPLEMENT_OVERFLOW_UNDERFLOW1:
           cba             
           bge   SET_TO_MAX_OR_MIN_VALUE
           ldab  O2LIML_O2RangeLimitLow
           cba             
           bge   LFC7C     
SET_TO_MAX_OR_MIN_VALUE:
           tba             
   LFC7C:  ldab  BitFlags_6d
           bitb  #0x20         ;  -00100000-
           beq   UpdateO2FeedbackCount
           tsta            
           bmi   DontUpdateO2FeedbackCount
UpdateO2FeedbackCount:
           staa  Counter_PrimaryAndSecondaryRamp
DontUpdateO2FeedbackCount:
           cli             
           rts             

DetermineRampCellFromRPMandMAP:
           ldaa  BitFlags_70
           bita  #0x40         ;  -01000000-
           bne   FindCruiseCell
           ldaa  BitFlags_6e
           bmi   FindCruiseCell
           ldab  #0x16         ;  -00010110-
           bra   DecideRichOrLeanValue

FindCruiseCell:
           clrb            
           ldaa  EngineRpm_HB
FindRPMCell:
           cmpa  0x00, X      ;  -00000000-
           bcs   CheckRPMCell
           incb            
           inx             
           cmpb  #0x02         ;  -00000010-
           bcs   FindRPMCell
           bra   LFCAB     

CheckRPMCell:
           tstb            
           bne   LFCAA     
           inx             
   LFCAA:  inx             
   LFCAB:  ldaa  MapValue  
FindMAPCell:
           cmpa  0x00, X      ;  -00000000-
           bcs   LFCBA     
           addb  #0x03         ;  -00000011-
           inx             
           cmpb  #0x06         ;  -00000110-
           bcs   FindMAPCell
           bra   LFCC0     

   LFCBA:  cmpb  #0x03         ;  -00000011-
           bcc   LFCBF     
           inx             
   LFCBF:  inx             
   LFCC0:  aslb            
           ldaa  BitFlags_6e
DecideRichOrLeanValue:
           bita  #0x04         ;  -00000100-
           beq   LoadCellValue
           incb            
LoadCellValue:
           abx             
           ldaa  0x14, X      ;  -00010100-
           tab             
           rts             

HandleAmTimer_MM:
           ldaa  CoolantTemp
           ldab  BitFlags_6f
           bpl   LFCE1     
           ldab  AMTML_SelectedAMTimerInitLow
           cmpa  AMTMH_SelectedAMTimerInitHi
           bcc   LFCDE     
           ldab  AMTPSW_TempPointToEnableSelectedAMTimer
   LFCDE:  stab  Timer_O2CNTR_CountdownFromAbove196FtoEnableClosedLoop
           rts             

   LFCE1:  cmpa  AMTEMP_StartTempToSelectHotOrColdAMTimer
           bcs   LFCF1     
           ldab  Timer_O2CNTR_CountdownFromAbove196FtoEnableClosedLoop
           beq   UpdateAdaptive_OffIdle
           ldaa  Counter_MainLoop
           bne   LFCF1     
           decb            
           stab  Timer_O2CNTR_CountdownFromAbove196FtoEnableClosedLoop
   LFCF1:  rts             

UpdateAdaptive_OffIdle:
           ldd   InjectorPulsewidth_HB
           addd  Pulsewidth_PartThrottleEnrichment_HB
           subd  PWMIN_NoCellUpdateBelow_PWMIN_Pulsewidth
           bcs   LFD69     
           ldaa  Timer_OpenLoopFraction
           cmpa  LMTOLF2_LimitTimerOpenLoopFraction2
           bcc   LFD69     
           ldaa  BitFlags_6e
           bita  #0x10         ;  -00010000-
           beq   LFD69     
           lsra            
           bcs   LFD69     
           clrb            
           anda  #0x02         ;  -00000010-
           beq   LFD11     
           decb            
   LFD11:  ldaa  CALTHR_O2ControllerDeadbandLimitForUpdatingCells
           stab  Temp0     
           bmi   LFD19     
           nega            
   LFD19:  adda  Counter_PrimaryAndSecondaryRamp
           bvs   LFD21     
           eora  Temp0     
           bmi   LFD69     
   LFD21:  ldab  Timer_Leanout
           bne   LFD69     
           ldab  MapValue  
           cmpb  MAPLIM_NoCellUpdateAboveThisMAP
           bhi   LFD69     
           ldab  EngineRpm_HB
           cmpb  RPMLIM_NoCellUpdateAboveThisRPMInRPMOver32
           bhi   LFD69     
           ldab  AdaptiveCellUpdateTimer_IncrementedEveryDistRisingEdge
           cmpb  AMUPDT_EPPsBetweenCalChangeUpdateOpenThrottle
           bcs   LFD69     
           ldab  Counter_PrimaryAndSecondaryRamp
           beq   LFD69     
           clra            
           staa  AdaptiveCellUpdateTimer_IncrementedEveryDistRisingEdge
           ldaa  CELCHG_BitsChangePerUpdateWithinACell
           tstb            
           bpl   AdaptiveMemory_UpdateCellIfRequired
           nega            
AdaptiveMemory_UpdateCellIfRequired:
           ldx   #AutoCalCell0
           ldab  PointerIntoAdaptiveMemory
           abx             
           ldab  AMLIMH_MaxMultiplierCannotBeAbove7F
           adda  0x00, X      ;  -00000000-
           bvc   Adaptive_Overflowed
           ldaa  0x00, X      ;  -00000000-
           bpl   Adaptive_SetCellToMaxOrMinValue
           ldab  AMLIML_MinMultiplierCannotBeBelow80
           tba             
Adaptive_Overflowed:
           cba             
           bge   Adaptive_SetCellToMaxOrMinValue
           ldab  AMLIML_MinMultiplierCannotBeBelow80
           cba             
           bge   LFD67     
Adaptive_SetCellToMaxOrMinValue:
           tba             
   LFD67:  staa  0x00, X      ;  -00000000-
   LFD69:  rts             

VerifyOperationOfO2SensorMore:
           ldaa  BitFlags_6e
           bita  #0x10         ;  -00010000-
           bne   LFD9D     
           ldaa  O2SensorVolts
           cmpa  O2MIDL_LowLimitForInMiddleDetermination
           bcs   LFD9D     
           cmpa  O2MIDH_HighLimitForInMiddleDetermination
           bcc   LFD9D     
           ldab  BitFlags_6d
           bitb  #0x20         ;  -00100000-
           bne   LFD9D     
           ldaa  FuelSubtractedFromStartToRun
           inca            
           beq   LFD9D     
           staa  FuelSubtractedFromStartToRun
           cmpa  #0x56         ;  -01010110-
           bcs   LFDA0     
           ldab  #0x01         ;  -00000001-
           ldx   #ErrorBitRegister3
           jsr   ThrowNonCriticalError
           ldaa  #0x20         ;  -00100000-
           sei             
           oraa  BitFlags_6d
           staa  BitFlags_6d
           cli             
   LFD9D:  clra            
           staa  FuelSubtractedFromStartToRun
   LFDA0:  rts


; ************************

        .org	0xff00
BoostButtonCopyrightNoticeUpper:
        .str   "Turbonator mods and brand Copr. 2012 Rob Lloyd"
        .byte  0x00, 0x00
        .str   "Turbonator GLHS v1"
        .byte  0x00, 0x00


        .org	0xffa0
ChryslerCopyrightNoticeUpper:
	.str   "COPR. 1985 CHRYSLER CORP."
        .byte  0x00, 0x00


	.org	0xfff0
IRQ2sioV:
	.word	ResetRoutine
IRQ2timerOverV:
	.word	ResetRoutine
IRQ2timerOutV:
	.word	IRQtOut
IRQ2timerInV:
	.word	InterruptFromDistributorSyncAndSpeedSensor
IRQ1strobe3V:
	.word	IRQ1strobe3
SWIVector:
	.word	ResetRoutine
NMIVector:
	.word	NMIInterrupt
ResetVector:
	.word	ResetRoutine

        .msg "Assembly Complete."

